import { AppShell } from '@/components/tms/app-shell'

export default function Page() {
  return <AppShell />
}
