import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'
import { LOAD_TYPE_OPTIONS, TERMINALS, type Load, type Terminal } from '@/lib/tms-data'

export const runtime = 'nodejs'

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function requiredString(value: unknown, field: string) {
  if (typeof value !== 'string') throw new Error(`Invalid ${field}: expected a string.`)
  return value
}

function mapTerminalToDatabaseCode(value: string): Terminal {
  const normalizedValue = value.trim().toLowerCase()
  const terminal = TERMINALS.find((option) =>
    [option.code, option.name, option.appointmentLabel].some((candidate) => candidate?.trim().toLowerCase() === normalizedValue),
  )

  if (terminal) return terminal.code
  if (normalizedValue.includes('husky')) return 'Husky'
  throw new Error(`Unsupported terminal value: ${value}`)
}

function mapOptionToDatabaseCode<T extends string>(value: string, options: { value: T; label: string }[]): T {
  const normalizedValue = value.trim().toLowerCase()
  const option = options.find((candidate) =>
    candidate.value.toLowerCase() === normalizedValue || candidate.label.trim().toLowerCase() === normalizedValue,
  )

  if (!option) throw new Error(`Unsupported option value: ${value}`)
  return option.value
}

function normalizeDateForDatabase(value: string): string | null {
  const normalizedValue = value.trim()
  if (!normalizedValue || /^m{1,2}\/d{1,2}\/y{2,4}$/i.test(normalizedValue)) return null

  const usDate = normalizedValue.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)
  const isoDate = normalizedValue.match(/^(\d{4})-(\d{2})-(\d{2})$/)
  const [, year, month, day] = usDate
    ? [usDate[0], usDate[3], usDate[1].padStart(2, '0'), usDate[2].padStart(2, '0')]
    : isoDate ?? []

  if (!year || !month || !day) return null

  const date = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)))
  if (date.getUTCFullYear() !== Number(year) || date.getUTCMonth() !== Number(month) - 1 || date.getUTCDate() !== Number(day)) {
    return null
  }

  return `${year}-${month}-${day}`
}

function toDatabaseRow(payload: Record<string, unknown>): Record<string, unknown> {
  const linehaulRate = payload.linehaulRate
  const weightLbs = payload.weightLbs
  if (typeof linehaulRate !== 'number' || !Number.isFinite(linehaulRate) || linehaulRate <= 0) {
    throw new Error('Invalid linehaulRate: expected a positive number.')
  }
  if (typeof weightLbs !== 'number' || !Number.isFinite(weightLbs) || weightLbs < 0) {
    throw new Error('Invalid weightLbs: expected a non-negative number.')
  }

  const containerSize = requiredString(payload.containerSize, 'containerSize')
  const validSizes: { value: Load['size']; label: string }[] = [
    { value: '20GP', label: "20'" },
    { value: '40GP', label: "40'" },
    { value: '40HC', label: "40' High Cube" },
    { value: '45HC', label: "45' High Cube" },
  ]

  return {
    container: requiredString(payload.container, 'container').trim().toUpperCase(),
    bill_of_lading: requiredString(payload.billOfLading, 'billOfLading').trim() || null,
    terminal: mapTerminalToDatabaseCode(requiredString(payload.terminal, 'terminal')),
    consignee: requiredString(payload.consignee, 'consignee').trim(),
    consignee_address: requiredString(payload.consigneeAddress, 'consigneeAddress').trim() || null,
    consignee_contact: requiredString(payload.consigneeContact, 'consigneeContact').trim() || null,
    linehaul_rate: linehaulRate,
    container_size: mapOptionToDatabaseCode(containerSize, validSizes),
    load_type: mapOptionToDatabaseCode(requiredString(payload.loadType, 'loadType'), LOAD_TYPE_OPTIONS),
    weight_lbs: weightLbs,
    seal: requiredString(payload.seal, 'seal').trim() || null,
    lfd: normalizeDateForDatabase(requiredString(payload.lfd, 'lfd')),
    order_date: normalizeDateForDatabase(requiredString(payload.orderDate, 'orderDate')),
    vessel_voyage: requiredString(payload.vesselVoyage, 'vesselVoyage').trim() || null,
  }
}

export async function POST(request: Request) {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!supabaseUrl || !supabaseAnonKey) {
    return NextResponse.json({
      data: null,
      error: {
        message: 'Supabase environment variables are missing.',
        details: null,
        hint: null,
        code: 'CONFIG_MISSING',
      },
    }, { status: 500 })
  }

  let payload: unknown
  try {
    payload = await request.json()
  } catch {
    return NextResponse.json({
      data: null,
      error: { message: 'Request body must be valid JSON.', details: null, hint: null, code: 'INVALID_JSON' },
    }, { status: 400 })
  }

  if (!isRecord(payload)) {
    return NextResponse.json({
      data: null,
      error: { message: 'Request body must be a JSON object.', details: null, hint: null, code: 'INVALID_BODY' },
    }, { status: 400 })
  }

  let databaseRow: Record<string, unknown>
  try {
    databaseRow = toDatabaseRow(payload)
  } catch (error) {
    return NextResponse.json({
      data: null,
      error: {
        message: error instanceof Error ? error.message : 'Invalid inbound order.',
        details: null,
        hint: null,
        code: 'INVALID_ORDER',
      },
    }, { status: 400 })
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseAnonKey)
    const { data, error } = await supabase
      .from('inbound_orders')
      .insert(databaseRow)
      .select()
      .single()

    if (error) {
      return NextResponse.json({
        data: null,
        error: {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code,
        },
      }, { status: 400 })
    }

    return NextResponse.json({ data, error: null }, { status: 201 })
  } catch (error) {
    return NextResponse.json({
      data: null,
      error: {
        message: error instanceof Error ? error.message : 'Unable to connect to Supabase.',
        details: null,
        hint: null,
        code: 'SUPABASE_REQUEST_FAILED',
      },
    }, { status: 502 })
  }
}
