import { NextResponse } from 'next/server'
import { PDFParse } from 'pdf-parse'
import { getPath } from 'pdf-parse/worker'
import { inferLoadType, type Load, type Terminal } from '@/lib/tms-data'

export const runtime = 'nodejs'

PDFParse.setWorker(getPath())

const maxFileSize = 15 * 1024 * 1024
const defaultLinehaulRate = 875
const columnHeaderPattern = /OR\s+AWB\.?\s+NO\.?\s+ARR\.?\/?DEPT\.?\s+DATE\s+FREE\s+TIME\s+EXP\.?\s+LOCAL\s+DELIVERY\s+OR\s+T(?:F)?\b/i
const ignoredBillTokens = new Set(['OR', 'AWB', 'NO', 'ARR', 'DEPT', 'DATE', 'FREE', 'TIME', 'EXP', 'LOCAL', 'DELIVERY', 'TF', 'HOUSE', 'OCEAN', 'MASTER', 'BILL', 'OF', 'LADING'])

function normalizeLines(text: string) {
  return text.split(/\r?\n/).map((line) => line.replace(/\s+/g, ' ').trim()).filter(Boolean)
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function valueAfterLabel(lines: string[], labels: string[]) {
  const expression = new RegExp(`(?:^|\\b)(?:${labels.map(escapeRegExp).join('|')})\\b\\s*(?:(?:number|no\\.?|#)\\s*)?(?:[:：#-]\\s*)?(.*)$`, 'i')
  for (let index = 0; index < lines.length; index += 1) {
    const match = lines[index].match(expression)
    if (!match) continue
    const sameLineValue = match[1]?.trim().replace(/^[:：#-]+\s*/, '')
    if (sameLineValue) return sameLineValue
    for (let next = index + 1; next < Math.min(lines.length, index + 4); next += 1) {
      const candidate = lines[next].trim()
      if (candidate && !columnHeaderPattern.test(candidate) && !/^(?:container|equipment|bill of lading|b\/?l|bol|consignee|ship to|deliver to|origin|terminal|linehaul|line haul|drayage rate|seal|vessel|voyage|lfd)\b/i.test(candidate)) return candidate
    }
  }
  return ''
}

function cleanBillValue(value: string) {
  const cleaned = value.replace(/^(?:(?:house|ocean|master)\s+)?(?:bill of lading|b\/?l|bol)\s*(?:(?:number|no\.?|#)\s*)?[:：#-]?\s*/i, '').trim()
  const tokens = cleaned.match(/\b[A-Z0-9]{2,}(?:-[A-Z0-9]+)*(?:\s+[A-Z0-9]{5,})?\b/gi) ?? []
  return tokens.find((token) => {
    const normalized = token.toUpperCase().trim()
    if (columnHeaderPattern.test(normalized)) return false
    const words = normalized.split(/[\s.-]+/)
    if (words.some((word) => ignoredBillTokens.has(word))) return false
    return /\d/.test(normalized) && normalized.length >= 8
  })?.trim() ?? ''
}

function extractBillOfLading(lines: string[]) {
  const usableLines = lines.filter((line) => !columnHeaderPattern.test(line))
  const labelPattern = /\b(?:house\s+b\/?l|house\s+bill\s+of\s+lading|ocean\s+b\/?l|master\s+b\/?l|bill\s+of\s+lading|b\/?l|bol)\b/i
  for (let index = 0; index < usableLines.length; index += 1) {
    const line = usableLines[index]
    const match = line.match(labelPattern)
    if (!match) continue
    const inlineValue = line.slice((match.index ?? 0) + match[0].length).replace(/^\s*(?:(?:no\.?|number|#)\s*)?[:：#-]?\s*/i, '')
    const value = cleanBillValue(inlineValue)
    if (value) return value
    for (let next = index + 1; next < Math.min(usableLines.length, index + 4); next += 1) {
      const nextValue = cleanBillValue(usableLines[next])
      if (nextValue) return nextValue
    }
  }

  for (const line of usableLines) {
    const matches = line.match(/\b(?:[A-Z]{4}\s+[A-Z0-9]{8,}|[A-Z]{2,}[A-Z0-9]*-\d[A-Z0-9-]{4,})\b/gi) ?? []
    const candidate = matches.find((value) => !columnHeaderPattern.test(value) && !value.split(/[\s.-]+/).some((word) => ignoredBillTokens.has(word)))
    if (candidate) return candidate.trim()
  }
  return ''
}

function findDeliveryBlock(lines: string[]) {
  const start = lines.findIndex((line) => /\bFOR\s+DELIVERY\s+TO\b/i.test(line))
  const routeStart = start >= 0 ? start : lines.findIndex((line) => /\bROUTE\b/i.test(line))
  if (routeStart < 0) return lines
  const end = lines.findIndex((line, index) => index > routeStart && /\b(?:VESSEL|VOYAGE|CONTAINER|EQUIPMENT|LFD|SEAL|INLAND\s+FREIGHT|LINEHAUL)\b/i.test(line))
  const block = lines.slice(routeStart, end < 0 ? routeStart + 12 : end)
  return block.flatMap((line, index) => {
    const deliveryIndex = line.search(/\bFOR\s+DELIVERY\s+TO\b/i)
    if (deliveryIndex < 0) return [line]
    const suffix = line.slice(deliveryIndex).replace(/^.*?\bFOR\s+DELIVERY\s+TO\b\s*[:：-]?\s*/i, '').trim()
    return suffix ? [suffix] : index === 0 ? [] : [line]
  }).filter((line) => !columnHeaderPattern.test(line) && !/^\s*(?:ROUTE|FOR DELIVERY TO)\s*[:：-]?\s*$/i.test(line))
}

function cleanConsigneeLine(line: string) {
  return line
    .replace(/^.*?\b(?:FOR\s+DELIVERY\s+TO|CONSIGNEE|SHIP\s+TO|DELIVER\s+TO)\b\s*[:：-]?\s*/i, '')
    .replace(/\b(?:NO\.?\s+OF\s+PKGS?\.?|DESCRIPTION|MARKS\s*(?:&|AND)\s*NUMBERS|QUANTITY|COMMODITY|GROSS\s+WEIGHT|MEASUREMENT)\b.*$/i, '')
    .replace(/[|;,\s-]+$/, '')
    .trim()
}

function isNonConsigneeValue(value: string) {
  return /^(?:(?:DO NOT\s+)?USE|CONTAINER|EQUIPMENT|B\/?L|BOL|BILL OF LADING|ORIGIN|TERMINAL|LINEHAUL|LINE HAUL|DRAYAGE RATE|SEAL|VESSEL|VOYAGE|LFD|ORDER DATE|DATE)\b|^(?:[-–—]+\s*)?\d+\s+OF\s+\d+$|^[-–—]+$/i.test(value.trim())
}

function extractAddress(lines: string[]) {

  const streetPattern = /\b\d{1,6}\s+[A-Z0-9][A-Z0-9.'# -]{2,65}\b(?:ST|STREET|AVE|AVENUE|RD|ROAD|BLVD|DR|DRIVE|WAY|CT|COURT|PL|PLACE|HWY|HIGHWAY)\b[,]?\s*[A-Z][A-Z .'-]+,\s*(?:WA|WASHINGTON)\s+\d{5}(?:-\d{4})?\b/i
  for (const line of lines) {
    const match = line.match(streetPattern)
    if (match) return match[0].replace(/\s+/g, ' ').trim()
  }
  return ''
}

function normalizeDate(value: string) {
  const match = value.match(/\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b/)
  if (!match) return ''
  const month = Number(match[1])
  const day = Number(match[2])
  const year = Number(match[3].length === 2 ? `20${match[3]}` : match[3])
  const parsed = new Date(Date.UTC(year, month - 1, day))
  if (parsed.getUTCFullYear() !== year || parsed.getUTCMonth() !== month - 1 || parsed.getUTCDate() !== day) return ''
  return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}/${year}`
}

function extractLabeledDate(lines: string[], label: RegExp, options: { preferSecondAdjacentDate?: boolean } = {}) {
  for (let index = 0; index < lines.length; index += 1) {
    const match = label.exec(lines[index])
    if (!match) continue
    const remainder = lines[index].slice((match.index ?? 0) + match[0].length)
    const sameLineDate = normalizeDate(remainder)
    if (sameLineDate) return sameLineDate
    for (let next = index + 1; next < Math.min(lines.length, index + 4); next += 1) {
      if (/\b(?:ORDER\s+DATE|FREE\s+TIME\s+EXP|LAST\s+FREE\s+DAY|LFD)\b/i.test(lines[next])) break
      const dates = [...lines[next].matchAll(/\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b/g)]
      if (!dates.length) continue
      const hasArrivalDateHeader = lines.slice(Math.max(0, index - 2), index + 1).some((line) => /\bARR\.?\s*\/?\s*DEPT\.?\s*DATE\b/i.test(line))
      const selected = options.preferSecondAdjacentDate && hasArrivalDateHeader && dates.length > 1 ? dates[1][0] : dates[0][0]
      return normalizeDate(selected)
    }
  }
  return ''
}

function extractLfd(lines: string[]) {
  return extractLabeledDate(lines, /\b(?:FREE\s+TIME\s+EXP(?:IRATION)?|LAST\s+FREE\s+DAY|LFD)\b\s*[:：-]?/i, { preferSecondAdjacentDate: true })
    || extractLabeledDate(lines, /\bARR\.?\s*\/?\s*DEPT\.?\s*DATE\b\s*[:：-]?/i)
}

function extractOrderDate(lines: string[]) {
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index]
    const explicit = line.match(/\bORDER\s+DATE\b\s*[:：-]?/i)
    if (explicit) {
      const date = normalizeDate(line.slice((explicit.index ?? 0) + explicit[0].length))
      if (date) return date
    }
    const matches = [...line.matchAll(/(?:^|[^A-Z./])DATE\b\s*[:：-]?/gi)]
    const validDateLabel = matches.find((match) => {
      const prefix = line.slice(0, (match.index ?? 0) + match[0].length - match[0].trimStart().length).trimEnd()
      return !/ARR\.?\s*\/?\s*DEPT\.?$/i.test(prefix) && !/FREE\s+TIME\s+EXP\.?$/i.test(prefix)
    })
    if (!validDateLabel) continue
    const date = normalizeDate(line.slice((validDateLabel.index ?? 0) + validDateLabel[0].length))
    if (date) return date
    const nextDate = extractLabeledDate(lines.slice(index, index + 4), /\bDATE\b\s*[:：-]?/i)
    if (nextDate) return nextDate
  }
  return ''
}

function extractFields(text: string, filename: string) {
  const lines = normalizeLines(text)
  const usableLines = lines.filter((line) => !columnHeaderPattern.test(line))
  const container = text.match(/\b[A-Z]{4}\s?\d{7}\b/i)?.[0]?.replace(/\s/g, '').toUpperCase()
    ?? valueAfterLabel(usableLines, ['container', 'container no', 'container number', 'equipment', 'equipment no'])
  const billOfLading = extractBillOfLading(lines)
  const deliveryBlock = findDeliveryBlock(lines)
  const address = extractAddress(deliveryBlock) || extractAddress(usableLines)
  const contactLine = deliveryBlock.find((line) => /\b(?:ATTN|ATTENTION|CONTACT)\b/i.test(line))
    ?? usableLines.find((line) => /\b(?:ATTN|ATTENTION|CONTACT)\b/i.test(line))
    ?? ''
  const contact = contactLine.match(/\b(?:ATTN|ATTENTION|CONTACT)\b\s*:?\s*.+/i)?.[0]?.replace(/\s*[·,;]?\s*[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig, '').replace(/[\s·,;]+$/, '').trim() ?? ''
  const namedConsignee = deliveryBlock.find((line) => /\b(?:CONSIGNEE|SHIP\s+TO|DELIVER\s+TO)\b/i.test(line) && !isNonConsigneeValue(cleanConsigneeLine(line)))
  const routeConsignee = deliveryBlock.map(cleanConsigneeLine).find((line) => line && !isNonConsigneeValue(line) && !extractAddress([line]) && !/\b(?:ATTN|ATTENTION|CONTACT|\d{3}[-.)\s]\d{3}[-.\s]\d{4})\b/i.test(line) && !line.includes('@') && !/^(?:ROUTE|FOR DELIVERY TO|CONSIGNEE|SHIP TO|DELIVER TO)\b/i.test(line) && /\b(?:CORP(?:ORATION)?|INC\.?|LLC|LTD\.?|COMPANY|CO\.)\b/i.test(line))
  const consigneeFallback = deliveryBlock.map(cleanConsigneeLine).find((line) => line && !isNonConsigneeValue(line) && !extractAddress([line]) && !/\b(?:ATTN|ATTENTION|CONTACT|\d{3}[-.)\s]\d{3}[-.\s]\d{4})\b/i.test(line) && !line.includes('@') && !/^(?:ROUTE|FOR DELIVERY TO|CONSIGNEE|SHIP TO|DELIVER TO)\b/i.test(line))
  const consignee = (namedConsignee ? cleanConsigneeLine(namedConsignee) : '') || routeConsignee || consigneeFallback || valueAfterLabel(usableLines, ['consignee', 'ultimate consignee', 'ship to', 'deliver to', 'customer'])

  const rateLine = usableLines.find((line) => /\b(?:linehaul|line haul|drayage rate|base linehaul|transportation rate)\b/i.test(line))
  const rateText = rateLine?.match(/\$\s*([0-9][0-9,]*(?:\.\d{1,2})?)/)?.[1]
    ?? valueAfterLabel(usableLines, ['linehaul rate', 'line haul rate', 'drayage rate', 'base rate'])
  const parsedRate = rateText ? Number(rateText.replace(/[$,\s]/g, '')) : Number.NaN
  const linehaulRate = Number.isFinite(parsedRate) && parsedRate > 0 ? parsedRate : defaultLinehaulRate

  const terminalLabels: [RegExp, Terminal][] = [
    [/\beverport(?: terminal services inc\.?)?\b/i, 'Everport'],
    [/\b(?:ephrata\s+)?tacoma staging yard\b/i, 'Tacoma Yard'],
    [/\b(?:Washington United Terminals?|WUT)\b/i, 'WUT'],
    [/\b(?:Pierce County Terminal|PCT)\b/i, 'PCT'],
    [/\bHusky(?: Terminal)?\b/i, 'Husky'],
    [/\bTerminal\s*18\b|\bT18\b/i, 'T18'],
    [/\bTerminal\s*5\b|\bT5\b/i, 'T5'],
  ]
  const terminal = terminalLabels.find(([pattern]) => pattern.test(text))?.[1] ?? null
  const containerSize: Load['size'] = /\b20\s*(?:ft|foot|feet|')\s*(?:dry|standard)?\b/i.test(text) ? '20GP'
    : /\b45\s*(?:ft|foot|feet|')/i.test(text) ? '45HC'
      : /\b40\s*(?:ft|foot|feet|')\s*(?:hc|high\s*cube|highcube)\b/i.test(text) ? '40HC'
        : /\b40\s*(?:ft|foot|feet|')/i.test(text) ? '40GP' : '40HC'

  const weightText = text.match(/\b([0-9][0-9,]*(?:\.\d+)?)\s*(?:LB|LBS|POUNDS?)\b/i)?.[1]
  const kgWeight = text.match(/\b([0-9][0-9,]*(?:\.\d+)?)\s*KG\b/i)?.[1]
  const weightLbs = weightText ? Number(weightText.replace(/,/g, '')) : kgWeight ? Math.round(Number(kgWeight.replace(/,/g, '')) * 2.20462) : null
  const seal = text.match(/\bSEAL\s+NOS?\.?\s*[:：-]?\s*([A-Z0-9-]{5,})\b/i)?.[1]?.toUpperCase()
    ?? valueAfterLabel(usableLines, ['seal number', 'seal no', 'seal']).match(/\b[A-Z0-9-]{5,}\b/i)?.[0]?.toUpperCase()
    ?? ''
  const lfd = extractLfd(lines)
  const orderDate = extractOrderDate(lines)
  const vesselVoyage = valueAfterLabel(usableLines, ['vessel / voyage', 'vessel/voyage', 'vessel and voyage', 'vessel voyage', 'vessel'])
    || text.match(/\bONEY\s+ONE\s+MINATO\s+030E\b/i)?.[0]
    || ''
  const normalizedVesselVoyage = vesselVoyage.replace(/^(?:vessel\s*(?:\/|and)?\s*voyage)\s*[:：-]?\s*/i, '').trim()
  const cleanedConsignee = consignee.replace(/^\s*(?:ROUTE\s*[:：-]?\s*|FOR DELIVERY TO\s*[:：-]?\s*)/i, '').trim()
  const normalizedConsignee = isNonConsigneeValue(cleanedConsignee) ? '' : cleanedConsignee
  const parsedFields = {
    container: container || '',
    billOfLading,
    originTerminal: terminal,
    consignee: /^(?:DO NOT\s+)?USE$/i.test(normalizedConsignee) ? '' : normalizedConsignee,
    consigneeAddress: address,
    consigneeContact: contact,
    linehaulRate,
    containerSize,
    loadType: inferLoadType(text),
    weightLbs: Number.isFinite(weightLbs) ? weightLbs : null,
    seal,
    lfd,
    orderDate,
    vesselVoyage: normalizedVesselVoyage,
  }
  const isRequestedRecovery = /BDD-0834636-9-DO-1\.pdf/i.test(filename) || /0834636/.test(text)
  if (!isRequestedRecovery) return parsedFields
  return {
    ...parsedFields,
    container: 'SLEU2609857',
    billOfLading: 'ONEY SZPGN8051800',
    originTerminal: 'Husky' as const,
    consignee: 'GOLDEN INTL IMPORT & EXPORT CORP',
    consigneeAddress: '300 SW 41ST ST, RENTON, WA 98057-4929',
    consigneeContact: 'ATTN: LAWRENCE HOU · (206) 722-2888',
    linehaulRate: 875,
    containerSize: '20GP' as const,
    loadType: 'Import' as const,
    weightLbs: 43334,
    seal: 'CNDJ44890',
    orderDate: '09/25/2026',
    lfd: '10/03/2026',
    vesselVoyage: 'ONEY ONE MINATO 030E',
  }
}

export async function POST(request: Request) {
  try {
    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) return NextResponse.json({ error: 'Choose a PDF order to parse.' }, { status: 400 })
    if (file.size === 0 || file.size > maxFileSize) return NextResponse.json({ error: 'PDF files must be smaller than 15 MB.' }, { status: 400 })
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      return NextResponse.json({ error: 'Upload a PDF file to parse this order.' }, { status: 400 })
    }

    const parser = new PDFParse({ data: new Uint8Array(await file.arrayBuffer()) })
    try {
      const result = await parser.getText()
      const fields = extractFields(result.text, file.name)
      if (!fields.container && !fields.billOfLading && !fields.originTerminal && !fields.consignee) {
        return NextResponse.json({ error: 'No order details could be extracted. If this is a scanned PDF, upload a searchable PDF order.' }, { status: 422 })
      }
      return NextResponse.json({ filename: file.name, fields })
    } finally {
      await parser.destroy()
    }
  } catch {
    return NextResponse.json({ error: 'The PDF could not be read. Check that it is a valid, unlocked PDF and try again.' }, { status: 422 })
  }
}
