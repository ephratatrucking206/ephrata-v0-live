export type Terminal = 'Husky' | 'WUT' | 'PCT' | 'Everport' | 'T5' | 'T18' | 'Tacoma Yard'

export const EVERPORT_TERMINAL_NAME = 'Everport Terminal Services Inc. - Tacoma, WA'

export type LoadStatus =
  | 'Unassigned'
  | 'Dispatched'
  | 'At Terminal'
  | 'In Transit'
  | 'At Delivery'
  | 'Delivered'
  | 'Hold'

export type LoadType = 'Import' | 'Export' | 'Empty Return' | 'Yard Staging'

export const LOAD_TYPE_OPTIONS: { value: LoadType; label: string }[] = [
  { value: 'Import', label: 'Import (Pick Full)' },
  { value: 'Export', label: 'Export (Drop Full)' },
  { value: 'Empty Return', label: 'Empty Return (Drop Empty)' },
  { value: 'Yard Staging', label: 'Yard Staging' },
]

export function loadTypeLabel(loadType: LoadType): string {
  return LOAD_TYPE_OPTIONS.find((option) => option.value === loadType)?.label ?? loadType
}

export function inferLoadType(text: string): LoadType {
  const explicitType = text.match(/\b(?:MOVE|LOAD|OPERATION|SERVICE)?\s*TYPE\s*[:#-]\s*(IMPORT|EXPORT|EMPTY\s+RETURN|DROP\s+EMPTY|DROP\s+FULL|PICK\s+FULL|YARD\s+STAGING)\b/i)?.[1]
  if (/^EXPORT$/i.test(explicitType ?? '')) return 'Export'
  if (/^IMPORT$/i.test(explicitType ?? '')) return 'Import'
  const candidate = explicitType ?? text.match(/\b(?:DROP\s+EMPTY|EMPTY\s+RETURN|RETURN\s+EMPTY|DROP\s+FULL|PICK\s+FULL|YARD\s+STAGING)\b/i)?.[0]
  if (/DROP\s+EMPTY|EMPTY\s+RETURN|RETURN\s+EMPTY/i.test(candidate ?? '')) return 'Empty Return'
  if (/DROP\s+FULL/i.test(candidate ?? '')) return 'Export'
  if (/YARD\s+STAGING/i.test(candidate ?? '')) return 'Yard Staging'
  if (/PICK\s+FULL/i.test(candidate ?? '')) return 'Import'
  if (/\bEXPORT\b/i.test(candidate ?? text) && !/\bIMPORT\s*&\s*EXPORT(?:\s+CORP(?:ORATION)?)?\b/i.test(text)) return 'Export'
  return 'Import'
}

export const EMODAL_MOVE_TYPES = ['⬆️ PICK FULL', '⬇️ DROP FULL', '⬆️ PICK EMPTY', '⬇️ DROP EMPTY'] as const
export type EModalMoveType = (typeof EMODAL_MOVE_TYPES)[number]
export type DispatchMoveType = EModalMoveType | 'Yard Staging'

export const DISPATCH_MOVE_TYPE_OPTIONS: { value: DispatchMoveType; label: string }[] = [
  { value: '⬆️ PICK FULL', label: '⬆️ PICK FULL (Import pick)' },
  { value: '⬇️ DROP FULL', label: '⬇️ DROP FULL (Export drop)' },
  { value: '⬆️ PICK EMPTY', label: '⬆️ PICK EMPTY (Chassis / Repo pick)' },
  { value: '⬇️ DROP EMPTY', label: '⬇️ DROP EMPTY (Empty return)' },
  { value: 'Yard Staging', label: 'Yard Staging' },
]

export function defaultDispatchMoveType(loadType: LoadType): DispatchMoveType {
  if (loadType === 'Yard Staging') return 'Yard Staging'
  return defaultEmodalMoveType(loadType)
}

export function dispatchMoveTypeLabel(moveType: DispatchMoveType): string {
  return moveType
}

export interface TerminalAppointment {
  terminal: string
  moveType: EModalMoveType
  container: string
  billOfLading: string
  seal: string
  chassis: string
  driverName: string
  licensePlate: string
  date: string
  timeSlot: string
  pin: string
  savedAtIso: string
}

export function defaultEmodalMoveType(loadType: LoadType): EModalMoveType {
  if (loadType === 'Export') return '⬇️ DROP FULL'
  if (loadType === 'Empty Return') return '⬇️ DROP EMPTY'
  return '⬆️ PICK FULL'
}

export interface Charge {
  label: string
  amount: number
}

export type PodDropStatus = 'Drop MT' | 'Drop Loaded' | 'Stay With' | 'Chassis Only'

export interface PodReceiptDetails {
  moveType?: DispatchMoveType
  timeIn: string
  timeOut: string
  receiverName: string
  companyName: string
  dropStatus: PodDropStatus
  signatureDataUrl: string
  confirmationCode?: string
}

export interface Load {
  id: string
  container: string
  billOfLading?: string
  consigneeAddress?: string
  consigneeContact?: string
  vesselVoyage?: string
  orderDate?: string
  deliveryOrder?: string
  poNumber?: string
  size: '20GP' | '40GP' | '40HC' | '45HC'
  type: LoadType
  moveType?: DispatchMoveType
  terminal: Terminal
  line: string
  customer: string
  billingEmail?: string
  destination: string
  driver: string | null
  truck: string | null
  chassis: string
  status: LoadStatus
  appt: string
  appointmentDate?: string
  appointmentWindow?: string
  dispatchNotes?: string
  lfd: string
  weightLbs: number
  seal: string
  charges: Charge[]
  podSigned: boolean
  podSignedAt?: string
  podSignedAtIso?: string
  podReceipt?: PodReceiptDetails
  podConfirmationCode?: string
  podVoided?: boolean
  podVoidReason?: string
  deliveryEmailStatus?: 'sent'
  terminalAppointment?: TerminalAppointment
}

export interface RouteChainLeg {
  id: string
  action: string
  origin: string
  destination: string
  equipmentRequired: string
  appointment?: string
  container?: string
  reference?: string
}

export interface RouteChain {
  id: string
  createdAtIso: string
  driver: string
  hosHoursAvailable: number
  container: string
  reference: string
  appointment: string
  finalChassisDrop: string
  emptyBobtailMiles: number
  dualMissionVerified: boolean
  legs: RouteChainLeg[]
}

export function createSmartDrayagePreset(): RouteChain {
  return {
    id: `CHAIN-${Date.now()}`,
    createdAtIso: new Date().toISOString(),
    driver: 'Asmarew',
    hosHoursAvailable: 8,
    container: 'MRSU5023427',
    reference: '#9174',
    appointment: 'Today · 07:00 AM eModal slot',
    finalChassisDrop: 'Tacoma Staging Yard',
    emptyBobtailMiles: 0,
    dualMissionVerified: true,
    legs: [
      { id: 'leg-1', action: 'Hook long chassis', origin: 'Cosentino', destination: 'Tacoma Staging Yard', equipmentRequired: 'Long chassis · empty' },
      { id: 'leg-2', action: 'Hook 4-axle chassis', origin: 'Tacoma Staging Yard', destination: 'Husky Terminal', equipmentRequired: '4-Axle 40′ chassis · empty' },
      { id: 'leg-3', action: 'In-gate and pull full container', origin: 'Husky Terminal', destination: 'Tacoma Staging Yard', equipmentRequired: '4-Axle 40′ chassis · loaded', appointment: 'Today · 07:00 AM eModal slot', container: 'MRSU5023427', reference: '#9174' },
    ],
  }
}

export type QboStatus = 'Draft / Under Review' | 'Syncing' | 'Synced' | 'Sent' | 'Paid' | 'Overdue'

export type InvoiceApprovalStatus = 'Needs Review' | 'Approved for Friday Billing' | 'Billed / Sent'

export interface InvoiceLineItem {
  item: string
  account: string
  amount: number
  quantity: number
  rate: number
  ourRef: string
  theirRef: string
  memo: string
}

export interface InvoiceDraftDetails {
  lineItems: InvoiceLineItem[]
  issued: string
  due: string
  terms: string
  attention: string
  billingAddress: string
  phone: string
  email: string
}

export interface Invoice {
  id: string
  loadId: string
  customer: string
  container: string
  issued: string
  due: string
  terms: string
  amount: number
  status: QboStatus
  approvalStatus: InvoiceApprovalStatus
  approvedBy?: string
  approvedAt?: string
  paymentReference?: string
  lineItems?: InvoiceLineItem[]
  attention?: string
  billingAddress?: string
  phone?: string
  email?: string
  qboRef: string
}

export const DEMURRAGE_RATE_BY_TERMINAL: Record<Terminal, number> = {
  T5: 150,
  T18: 150,
  PCT: 150,
  Husky: 150,
  WUT: 150,
  Everport: 150,
  'Tacoma Yard': 0,
}

export function calculateDaysPastLfd(lfd: string, gateOutDate: Date) {
  const match = /^(\d{2})\/(\d{2})(?:\/(\d{4}))?$/.exec(lfd)
  if (!match) return 0
  const month = Number(match[1])
  const day = Number(match[2])
  let year = match[3] ? Number(match[3]) : gateOutDate.getFullYear()
  let cutoff = new Date(year, month - 1, day)
  if (!match[3] && cutoff.getTime() > gateOutDate.getTime() + 183 * 24 * 60 * 60 * 1000) {
    year -= 1
    cutoff = new Date(year, month - 1, day)
  }
  const gateOutDay = Date.UTC(gateOutDate.getFullYear(), gateOutDate.getMonth(), gateOutDate.getDate())
  const cutoffDay = Date.UTC(cutoff.getFullYear(), cutoff.getMonth(), cutoff.getDate())
  return Math.max(0, Math.floor((gateOutDay - cutoffDay) / (24 * 60 * 60 * 1000)))
}

export function formatLfdCutoff(lfd: string, referenceDate: Date) {
  const match = /^(\d{2})\/(\d{2})(?:\/(\d{4}))?$/.exec(lfd)
  if (!match) return 'Not recorded'
  const month = Number(match[1])
  const day = Number(match[2])
  let year = match[3] ? Number(match[3]) : referenceDate.getFullYear()
  if (!match[3] && new Date(year, month - 1, day).getTime() > referenceDate.getTime() + 183 * 24 * 60 * 60 * 1000) year -= 1
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
}

export const TERMINALS: {
  code: Terminal
  name: string
  appointmentLabel?: string
  port: 'Seattle' | 'Tacoma'
  gate?: 'Open' | 'Congested' | 'Closed'
  turnMin?: number
}[] = [
  { code: 'Husky', name: 'Husky Terminal (Tacoma)', appointmentLabel: 'Husky Terminal', port: 'Tacoma', gate: 'Open', turnMin: 66 },
  { code: 'WUT', name: 'Washington United Terminals / WUT (Tacoma)', appointmentLabel: 'Washington United Terminals (WUT)', port: 'Tacoma', gate: 'Open', turnMin: 71 },
  { code: 'PCT', name: 'Pierce County Terminal / PCT (Tacoma)', appointmentLabel: 'Pierce County Terminal (PCT)', port: 'Tacoma', gate: 'Open', turnMin: 47 },
  { code: 'Everport', name: EVERPORT_TERMINAL_NAME, appointmentLabel: EVERPORT_TERMINAL_NAME, port: 'Tacoma' },
  { code: 'T5', name: 'Terminal 5 / T5 (Seattle)', appointmentLabel: 'Terminal 5 (Seattle)', port: 'Seattle', gate: 'Open', turnMin: 58 },
  { code: 'T18', name: 'Terminal 18 / T18 (Seattle)', appointmentLabel: 'Terminal 18 (Seattle)', port: 'Seattle', gate: 'Congested', turnMin: 94 },
  { code: 'Tacoma Yard', name: 'Ephrata Tacoma Staging Yard', port: 'Tacoma' },
]

const baseCharges = (linehaul: number, extras: Charge[] = []): Charge[] => [
  { label: 'Drayage linehaul', amount: linehaul },
  { label: 'Fuel surcharge (32%)', amount: Math.round(linehaul * 0.32) },
  ...extras,
]

export const SIGNATURE_LOAD_ID = '106381'

export const INITIAL_LOADS: Load[] = [
  {
    id: '106381',
    container: 'YMMU6496451',
    billOfLading: 'MEDUST884910',
    deliveryOrder: 'DO-99214-SEA',
    poNumber: 'YAH20620124',
    size: '40HC',
    type: 'Import',
    terminal: 'Husky',
    line: 'YANG MING',
    customer: 'Baxter',
    destination: 'Orting, WA',
    driver: 'Dependes',
    truck: 'Unit 387',
    chassis: 'EPHZ-28',
    status: 'At Delivery',
    appt: '13:30',
    lfd: '09/26',
    weightLbs: 38420,
    seal: '3391093',
    charges: baseCharges(485, [
      { label: 'Chassis split (2 days)', amount: 90 },
      { label: 'Terminal congestion fee', amount: 65 },
    ]),
    podSigned: false,
  },
  {
    id: '106382',
    container: 'CMAU 771204-9',
    size: '40GP',
    type: 'Import',
    terminal: 'T5',
    line: 'CMA CGM',
    customer: 'Northwest Paper Supply',
    destination: '7800 S 206th St, Kent WA',
    driver: 'Marcus T.',
    truck: 'Unit 207',
    chassis: 'DCLI 40-552093',
    status: 'In Transit',
    appt: '14:15',
    lfd: '09/27',
    weightLbs: 41200,
    seal: 'CMA0922461',
    charges: baseCharges(460),
    podSigned: false,
  },
  {
    id: '106383',
    container: 'ONEU 203381-5',
    size: '40HC',
    type: 'Import',
    terminal: 'PCT',
    line: 'ONE',
    customer: 'Rainier Outdoor Co.',
    destination: '1200 Andover Park W, Tukwila WA',
    driver: 'Priya S.',
    truck: 'Unit 221',
    chassis: 'TRAC 40-093310',
    status: 'At Terminal',
    appt: '12:45',
    lfd: '09/25',
    weightLbs: 29850,
    seal: 'ONE4418820',
    charges: baseCharges(520, [{ label: 'Pre-pull', amount: 150 }]),
    podSigned: false,
  },
  {
    id: '106384',
    container: 'HLXU 660017-2',
    size: '45HC',
    type: 'Export',
    terminal: 'Husky',
    line: 'Hapag-Lloyd',
    customer: 'Emerald Foods Export',
    destination: '6450 S 190th St, Kent WA',
    driver: 'Dmitri K.',
    truck: 'Unit 218',
    chassis: 'FLXV 45-004471',
    status: 'Dispatched',
    appt: '15:00',
    lfd: '—',
    weightLbs: 44100,
    seal: 'HLX2290014',
    charges: baseCharges(540, [{ label: 'Overweight permit', amount: 120 }]),
    podSigned: false,
  },
  {
    id: '106385',
    container: 'EGHU 918822-0',
    size: '40HC',
    type: 'Import',
    terminal: 'T18',
    line: 'Evergreen',
    customer: 'Puget Furnishings',
    destination: '19011 72nd Ave S, Kent WA',
    driver: null,
    truck: null,
    chassis: 'Pool — pending',
    status: 'Hold',
    appt: '—',
    lfd: '09/25',
    weightLbs: 33700,
    seal: 'EGH5510372',
    charges: baseCharges(485),
    podSigned: false,
  },
  {
    id: '106386',
    container: 'MSCU 482917-3',
    billOfLading: 'MEDUST884910',
    size: '40GP',
    type: 'Import',
    terminal: 'T5',
    line: 'Maersk',
    customer: 'Olympic Beverage',
    billingEmail: 'accounting@client.com',
    destination: '22010 68th Ave S, Kent WA',
    driver: 'Luis R.',
    truck: 'Unit 203',
    chassis: 'DCLI 40-771005',
    status: 'Delivered',
    appt: '08:00',
    lfd: '09/26',
    weightLbs: 42880,
    seal: 'MSK8830115',
    charges: baseCharges(460),
    podSigned: true,
    podSignedAt: '09:12',
    podSignedAtIso: '2026-09-25T16:12:00.000Z',
    deliveryEmailStatus: 'sent',
  },
  {
    id: '106387',
    container: 'CSNU 604418-1',
    size: '20GP',
    type: 'Empty Return',
    terminal: 'PCT',
    line: 'COSCO',
    customer: 'Rainier Outdoor Co.',
    destination: 'PCT empty yard',
    driver: 'Priya S.',
    truck: 'Unit 221',
    chassis: 'TRAC 20-018840',
    status: 'Dispatched',
    appt: '16:30',
    lfd: '09/28',
    weightLbs: 5100,
    seal: '—',
    charges: baseCharges(310),
    podSigned: false,
  },
  {
    id: '106388',
    container: 'ONEU 118047-6',
    size: '40HC',
    type: 'Import',
    terminal: 'Husky',
    line: 'ONE',
    customer: 'Summit Tire Distribution',
    destination: '8201 S 212th St, Kent WA',
    driver: null,
    truck: null,
    chassis: 'Pool — pending',
    status: 'Unassigned',
    appt: '17:00',
    lfd: '09/27',
    weightLbs: 39960,
    seal: 'ONE7714402',
    charges: baseCharges(530),
    podSigned: false,
  },
  {
    id: '106389',
    container: 'MSCU 225190-4',
    size: '40HC',
    type: 'Import',
    terminal: 'T18',
    line: 'MSC',
    customer: 'Cascade Home Goods',
    destination: '21415 84th Ave S, Kent WA',
    driver: 'Tomasz W.',
    truck: 'Unit 225',
    chassis: 'TRAC 40-119044',
    status: 'At Terminal',
    appt: '13:00',
    lfd: '09/26',
    weightLbs: 37210,
    seal: 'MSC7731977',
    charges: baseCharges(485, [{ label: 'Terminal congestion fee', amount: 65 }]),
    podSigned: false,
  },
  {
    id: '106390',
    container: 'CMAU 902266-8',
    size: '40GP',
    type: 'Export',
    terminal: 'T5',
    line: 'CMA CGM',
    customer: 'Evergreen Hay & Feed',
    destination: '1811 Central Ave S, Kent WA',
    driver: 'Marcus T.',
    truck: 'Unit 207',
    chassis: 'DCLI 40-552093',
    status: 'Dispatched',
    appt: '16:00',
    lfd: '—',
    weightLbs: 46300,
    seal: 'CMA0922510',
    charges: baseCharges(460, [{ label: 'Overweight permit', amount: 120 }]),
    podSigned: false,
  },
  {
    id: '106391',
    container: 'HLXU 441290-3',
    size: '40HC',
    type: 'Import',
    terminal: 'Husky',
    line: 'Hapag-Lloyd',
    customer: 'Pacific Crest Electronics',
    destination: '20250 72nd Ave S, Kent WA',
    driver: 'Anita B.',
    truck: 'Unit 212',
    chassis: 'FLXV 40-008812',
    status: 'In Transit',
    appt: '13:45',
    lfd: '09/26',
    weightLbs: 24380,
    seal: 'HLX2290102',
    charges: baseCharges(530),
    podSigned: false,
  },
  {
    id: '106392',
    container: 'EGHU 330415-9',
    size: '40HC',
    type: 'Import',
    terminal: 'PCT',
    line: 'Evergreen',
    customer: 'Puget Furnishings',
    destination: '19011 72nd Ave S, Kent WA',
    driver: 'Dmitri K.',
    truck: 'Unit 218',
    chassis: 'TRAC 40-093455',
    status: 'Delivered',
    appt: '07:30',
    lfd: '09/25',
    weightLbs: 31020,
    seal: 'EGH5510419',
    charges: baseCharges(520),
    podSigned: true,
    podSignedAt: '08:47',
  },
  {
    id: '106393',
    container: 'MSKU 781140-2',
    size: '20GP',
    type: 'Import',
    terminal: 'T5',
    line: 'Maersk',
    customer: 'Olympic Beverage',
    destination: '22010 68th Ave S, Kent WA',
    driver: null,
    truck: null,
    chassis: 'Pool — pending',
    status: 'Unassigned',
    appt: '18:00',
    lfd: '09/28',
    weightLbs: 40150,
    seal: 'MSK8830201',
    charges: baseCharges(440),
    podSigned: false,
  },
  {
    id: '106394',
    container: 'CSNU 118273-0',
    size: '40HC',
    type: 'Import',
    terminal: 'T18',
    line: 'COSCO',
    customer: 'Summit Tire Distribution',
    destination: '8201 S 212th St, Kent WA',
    driver: 'Luis R.',
    truck: 'Unit 203',
    chassis: 'DCLI 40-771005',
    status: 'Dispatched',
    appt: '15:30',
    lfd: '09/27',
    weightLbs: 42010,
    seal: 'CSN3019944',
    charges: baseCharges(485),
    podSigned: false,
  },
  {
    id: '106395',
    container: 'TCLU 771409-2',
    billOfLading: 'MEDUTW884925',
    deliveryOrder: 'DO-99215-SEA',
    poNumber: 'PO-8830193',
    size: '40HC',
    type: 'Import',
    terminal: 'WUT',
    line: 'MSC',
    customer: 'Cascade Home Goods',
    destination: '21415 84th Ave S, Kent WA',
    driver: 'Jemal A.',
    truck: 'Unit 214',
    chassis: 'TRAC 40-118823',
    status: 'At Terminal',
    appt: '15:30',
    lfd: '09/25',
    weightLbs: 36120,
    seal: 'TCL7714092',
    charges: baseCharges(485, [{ label: 'Chassis split (2 days)', amount: 90 }]),
    podSigned: false,
  },
]

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'AAA-26-4471',
    loadId: '106392',
    customer: 'Puget Furnishings',
    container: 'EGHU 330415-9',
    issued: '09/25/26',
    due: '10/25/26',
    terms: 'Net 30',
    amount: 686,
    status: 'Synced',
    approvalStatus: 'Approved for Friday Billing',
    approvedBy: 'A. Moreno',
    approvedAt: '2026-09-25T16:10:00-07:00',
    qboRef: 'QBO-18834',
  },
  {
    id: 'AAA-26-4470',
    loadId: '106386',
    customer: 'Olympic Beverage',
    container: 'MSCU 482917-3',
    issued: '09/25/26',
    due: '10/10/26',
    terms: 'Net 15',
    amount: 607,
    status: 'Sent',
    approvalStatus: 'Billed / Sent',
    approvedBy: 'A. Moreno',
    approvedAt: '2026-09-25T15:42:00-07:00',
    qboRef: 'QBO-18833',
  },
  {
    id: 'AAA-26-4462',
    loadId: '106351',
    customer: 'Cascade Home Goods',
    container: 'MSCU 119043-1',
    issued: '09/24/26',
    due: '10/24/26',
    terms: 'Net 30',
    amount: 795,
    status: 'Sent',
    approvalStatus: 'Billed / Sent',
    approvedBy: 'M. Davis',
    approvedAt: '2026-09-24T15:18:00-07:00',
    qboRef: 'QBO-18825',
  },
  {
    id: 'AAA-26-4455',
    loadId: '106340',
    customer: 'Rainier Outdoor Co.',
    container: 'ONEU 772018-4',
    issued: '09/23/26',
    due: '10/23/26',
    terms: 'Net 30',
    amount: 836,
    status: 'Paid',
    approvalStatus: 'Billed / Sent',
    approvedBy: 'A. Moreno',
    approvedAt: '2026-09-23T18:02:00-07:00',
    paymentReference: 'CHK-10482',
    qboRef: 'QBO-18818',
  },
  {
    id: 'AAA-26-4431',
    loadId: '106302',
    customer: 'Pacific Crest Electronics',
    container: 'HLXU 509912-7',
    issued: '08/20/26',
    due: '09/19/26',
    terms: 'Net 30',
    amount: 700,
    status: 'Overdue',
    approvalStatus: 'Billed / Sent',
    approvedBy: 'M. Davis',
    approvedAt: '2026-08-20T16:15:00-07:00',
    qboRef: 'QBO-18794',
  },
  {
    id: 'AAA-26-4428',
    loadId: '106297',
    customer: 'Emerald Foods Export',
    container: 'CMAU 330198-2',
    issued: '09/19/26',
    due: '10/19/26',
    terms: 'Net 30',
    amount: 873,
    status: 'Paid',
    approvalStatus: 'Billed / Sent',
    approvedBy: 'A. Moreno',
    approvedAt: '2026-09-19T18:06:00-07:00',
    paymentReference: 'ACH-90213',
    qboRef: 'QBO-18791',
  },
]

export const loadReferences = (load: Load) => ({
  billOfLading: load.billOfLading ?? (load.id === SIGNATURE_LOAD_ID ? 'MEDUST884910' : `BOL-${load.id}-SEA`),
  deliveryOrder: load.deliveryOrder ?? `DO-${load.id}-SEA`,
  poNumber: load.poNumber ?? `PO-${load.id}`,
})

export const loadTotal = (load: Load) =>
  load.charges.reduce((sum, c) => sum + c.amount, 0)

export const formatUsd = (n: number) =>
  n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })
