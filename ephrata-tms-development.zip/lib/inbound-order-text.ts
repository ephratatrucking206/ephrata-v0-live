import { inferLoadType, type Load, type Terminal } from './tms-data'

export interface ParsedTextOrder {
  id: string
  container: string
  billOfLading: string
  poNumber: string
  consignee: string
  terminal: Terminal | ''
  size: Load['size']
  lfd: string
  linehaulRate: string
}

const containerPattern = /\b[A-Z]{4}\s?\d{7}\b/gi
const terminalMatchers: { pattern: RegExp; value: Terminal }[] = [
  { pattern: /\beverport(?: terminal services inc\.?)?\b/i, value: 'Everport' },
  { pattern: /\b(?:ephrata\s+)?tacoma staging yard\b/i, value: 'Tacoma Yard' },
  { pattern: /\b(?:terminal\s*5|t5)\b/i, value: 'T5' },
  { pattern: /\b(?:terminal\s*18|t18)\b/i, value: 'T18' },
  { pattern: /\b(?:pierce county terminal|pct)\b/i, value: 'PCT' },
  { pattern: /\bhusky(?: terminal)?\b/i, value: 'Husky' },
  { pattern: /\b(?:washington united terminal|wut)\b/i, value: 'WUT' },
]

function uniqueMatches(pattern: RegExp, text: string) {
  return [...new Set([...text.matchAll(pattern)].map((match) => match[1] ?? match[0]))]
}

function parseTerminal(text: string): Terminal | '' {
  return terminalMatchers.find(({ pattern }) => pattern.test(text))?.value ?? ''
}

function parseSize(text: string): Load['size'] {
  if (/\b20\s*(?:ft|foot|feet|dv|gp|dry|standard|'|′)\b/i.test(text)) return '20GP'
  if (/\b45\s*(?:ft|foot|feet|hc|high\s*cube|'|′)\b/i.test(text)) return '45HC'
  if (/\b40\s*(?:ft|foot|feet|hc|high\s*cube|'|′)\b/i.test(text)) return /\b(?:hc|high\s*cube)\b/i.test(text) ? '40HC' : '40GP'
  return '40HC'
}

function parseLfd(text: string): string {
  const match = text.match(/\b(?:LFD(?:\s+AT\s+TERMINAL)?|LAST\s+FREE\s+DAY|FREE\s+TIME\s+EXP\.?)\s*[:#-]?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/i)
  if (!match) return ''
  const [month, day, rawYear] = match[1].split(/[\/\-]/)
  const year = rawYear.length === 2 ? `20${rawYear}` : rawYear
  return `${month.padStart(2, '0')}/${day.padStart(2, '0')}/${year}`
}

function cleanValue(value: string | undefined) {
  return value?.replace(/^[\s:;,|#-]+|[\s;,|]+$/g, '').trim() ?? ''
}

export function parseInboundEmailText(text: string): ParsedTextOrder[] {
  const normalized = text.replace(/\r/g, '\n').replace(/[\u00a0\t]+/g, ' ').replace(/\s{2,}/g, ' ')
  const containers = uniqueMatches(containerPattern, normalized).map((value) => value.replace(/\s/g, '').toUpperCase())
  if (containers.length === 0) return []

  const lines = normalized.split('\n').map((line) => line.trim()).filter(Boolean)
  const poNumbers = uniqueMatches(/\b(?:P\.?O\.?|PURCHASE\s+ORDER)\s*(?:NO\.?|#)?\s*[:#-]?\s*([A-Z0-9]+(?:-[A-Z0-9]+)*)/gi, normalized)
  const referenceNumbers = uniqueMatches(/\bF\d{6,}-[A-Z0-9-]+\b/gi, normalized)
  const explicitCustomer = normalized.match(/\b(?:customer|consignee|deliver\s+to)\s*[:#-]\s*([^\n,;]+)/i)?.[1]
  const goldenCustomer = normalized.match(/\bGolden\s+Intl(?:\s+Import\s*&\s*Export\s+Corp)?\b/i)?.[0]
  const sharedCustomer = cleanValue(explicitCustomer ?? goldenCustomer) || 'Golden Intl'
  const defaultPO = poNumbers[0] ?? referenceNumbers[0] ?? ''

  return containers.map((container, index) => {
    const row = lines.find((line) => line.toUpperCase().replace(/\s/g, '').includes(container)) ?? normalized
    const containerPosition = row.toUpperCase().replace(/\s/g, '').indexOf(container)
    const nearby = containerPosition >= 0 ? row : normalized
    const billOfLading = cleanValue(
      nearby.match(/\b(?:HOUSE\s+)?B\s*\/?\s*L(?:\s*(?:NO\.?|NUMBER))?\s*[:#-]?\s*([A-Z0-9][A-Z0-9-]{5,})/i)?.[1]
      ?? nearby.match(/\b(?:MEDU|ONEY|BDD)[A-Z0-9-]{5,}\b/i)?.[0]
      ?? '',
    )
    const poNumber = cleanValue(nearby.match(/\b(?:P\.?O\.?|PURCHASE\s+ORDER)\s*(?:NO\.?|#)?\s*[:#-]?\s*([A-Z0-9]+(?:-[A-Z0-9]+)*)/i)?.[1] ?? defaultPO)
    const matchingTerminal = parseTerminal(nearby) || parseTerminal(normalized)
    const lfd = parseLfd(nearby) || parseLfd(normalized)
    const consigneeMatch = nearby.match(/\b(?:customer|consignee|deliver\s+to)\s*[:#-]\s*([^,;|]+)/i)?.[1]
    const consignee = cleanValue(consigneeMatch ?? sharedCustomer)

    return {
      id: `${container}-${index}`,
      container,
      billOfLading,
      poNumber,
      consignee,
      terminal: matchingTerminal,
      size: parseSize(nearby),
      lfd,
      linehaulRate: '875',
    }
  })
}

export function toInboundOrderDetails(order: ParsedTextOrder) {
  return {
    container: order.container,
    billOfLading: order.billOfLading,
    terminal: order.terminal as Terminal,
    consignee: order.consignee,
    consigneeAddress: '',
    consigneeContact: '',
    linehaulRate: Number(order.linehaulRate.replace(/[$,\s]/g, '')),
    containerSize: order.size,
    loadType: 'Import' as const,
    weightLbs: 0,
    seal: '',
    lfd: order.lfd,
    vesselVoyage: '',
    poNumber: order.poNumber,
  }
}

export function isValidEmailOrder(order: ParsedTextOrder) {
  const rate = Number(order.linehaulRate.replace(/[$,\s]/g, ''))
  return Boolean(order.container.trim() && order.consignee.trim() && order.terminal && Number.isFinite(rate) && rate > 0)
}

export function updateParsedTextOrder(orders: ParsedTextOrder[], id: string, field: keyof ParsedTextOrder, value: string | boolean) {
  return orders.map((order) => order.id === id ? { ...order, [field]: value } as ParsedTextOrder : order)
}

export interface ParsedAppointmentOrder {
  id: string
  container: string
  loadType: Load['type']
  appointment: string
  appointmentDate: string
  appointmentWindow: string
  dispatchNotes: string
}

const appointmentContainerPattern = /\b[A-Z]{4}\s?\d{6,7}\b/gi
const appointmentTimePattern = String.raw`\d{1,2}(?::\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)`

function formatAppointmentDate(value: string): string {
  const [monthValue, dayValue, rawYear] = value.split('/')
  const month = Number(monthValue)
  const day = Number(dayValue)
  const year = rawYear ? Number(rawYear.length === 2 ? `20${rawYear}` : rawYear) : new Date().getFullYear()
  const parsed = new Date(year, month - 1, day)
  if (parsed.getFullYear() !== year || parsed.getMonth() !== month - 1 || parsed.getDate() !== day) return ''
  return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}/${year}`
}

function formatAppointmentTime(value: string): string {
  const match = value.match(/(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)/i)
  if (!match) return ''
  const hourValue = Number(match[1])
  const minute = Number(match[2] ?? 0)
  const meridiem = match[3].toLowerCase().startsWith('p') ? 'PM' : 'AM'
  if (hourValue < 1 || hourValue > 12 || minute > 59) return ''
  const hour = hourValue % 12 + (meridiem === 'PM' ? 12 : 0)
  return `${hour % 12 || 12}:${String(minute).padStart(2, '0')} ${meridiem}`
}

function normalizeDispatchNote(value: string): string {
  const note = value.replace(/^[\s–—:;,-]+/, '').trim()
  if (!note) return ''
  return `⚠️ Note: ${note.replace(/^note\s*:\s*/i, '')}`
}

export function parseDispatchAppointmentText(text: string): ParsedAppointmentOrder[] {
  const normalized = text.replace(/\r\n?/g, '\n').replace(/[\u00a0\t]/g, ' ')
  const seenContainers = new Set<string>()
  const matches = [...normalized.matchAll(appointmentContainerPattern)].filter((match) => {
    const container = match[0].replace(/\s/g, '').toUpperCase()
    if (seenContainers.has(container)) return false
    seenContainers.add(container)
    return true
  })
  return matches.map((containerMatch, index) => {
    const start = containerMatch.index ?? 0
    const end = matches[index + 1]?.index ?? normalized.length
    const segment = normalized.slice(start, end)
    const container = containerMatch[0].replace(/\s/g, '').toUpperCase()
    const firmMatch = segment.match(new RegExp(`(\\d{1,2}\\/\\d{1,2}(?:\\/\\d{2,4})?)\\s*@\\s*(${appointmentTimePattern})`, 'i'))
    const windowMatch = segment.match(new RegExp(`(?:del(?:ivery)?\\s+)?(\\d{1,2}\\/\\d{1,2}(?:\\/\\d{2,4})?)\\s+(?:at\\s+)?(${appointmentTimePattern})\\s*(?:-|–|—|to)\\s*(${appointmentTimePattern})`, 'i'))
    const deliveryMatch = segment.match(new RegExp(`(?:del(?:ivery)?\\s+)(\\d{1,2}\\/\\d{1,2}(?:\\/\\d{2,4})?)\\s+(?:at\\s+)?(${appointmentTimePattern})`, 'i'))
    const appointmentDate = formatAppointmentDate(firmMatch?.[1] ?? windowMatch?.[1] ?? deliveryMatch?.[1] ?? '')
    const appointmentTime = formatAppointmentTime(firmMatch?.[2] ?? deliveryMatch?.[2] ?? windowMatch?.[2] ?? '')
    const windowStart = windowMatch ? formatAppointmentTime(windowMatch[2]) : ''
    const windowEnd = windowMatch ? formatAppointmentTime(windowMatch[3]) : ''
    const appointmentWindow = windowStart && windowEnd ? `${windowStart} - ${windowEnd}` : ''
    const appointment = appointmentDate && appointmentTime
      ? `${appointmentDate} @ ${appointmentTime}${appointmentWindow ? ` (Window: ${appointmentWindow})` : ''}`
      : ''
    const noteMatch = firmMatch
      ? segment.slice((firmMatch.index ?? 0) + firmMatch[0].length)
      : windowMatch
        ? segment.slice((windowMatch.index ?? 0) + windowMatch[0].length)
        : ''
    const segmentHasMoveType = /\b(?:MOVE|LOAD|OPERATION|SERVICE)?\s*TYPE\s*[:#-]\s*(?:IMPORT|EXPORT|EMPTY\s+RETURN|DROP\s+EMPTY|DROP\s+FULL|PICK\s+FULL|YARD\s+STAGING)\b|\b(?:DROP\s+EMPTY|EMPTY\s+RETURN|RETURN\s+EMPTY|DROP\s+FULL|PICK\s+FULL|YARD\s+STAGING|EXPORT)\b/i.test(segment)
    const loadType = inferLoadType(segmentHasMoveType ? segment : normalized)

    return {
      id: `${container}-${index}`,
      container,
      loadType,
      appointment,
      appointmentDate,
      appointmentWindow,
      dispatchNotes: normalizeDispatchNote(noteMatch),
    }
  })
}
