import { jsPDF } from 'jspdf'
import type { Invoice, Load, PodReceiptDetails } from './tms-data'
import { defaultDispatchMoveType, loadReferences } from './tms-data'

const NAVY: [number, number, number] = [27, 77, 137]
const INK: [number, number, number] = [28, 35, 44]
const MUTED: [number, number, number] = [93, 103, 116]
const BORDER: [number, number, number] = [150, 160, 173]

export function createDeliveryDocumentAttachments(load: Load, receipt: PodReceiptDetails, signedAt: Date) {
  return [buildReceiptPdf(load, receipt, signedAt), buildPortEirPdf(load, signedAt)]
}

export interface OfficialInvoicePdfInput {
  invoiceNumber: string
  invoiceDate: string
  dueDate: string
  terms: string
  customer: string
  attention: string
  billingAddress: string
  phone: string
  email: string
  amount: number
  load: Load
  lines: { item: string; account: string; quantity: number; rate: number; amount: number; memo: string }[]
}

export function createOfficialInvoicePdf(input: OfficialInvoicePdfInput) {
  const { load } = input
  const refs = loadReferences(load)
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'letter' })
  const money = (value: number) => value.toLocaleString('en-US', { style: 'currency', currency: 'USD' })
  const drawChargeHeader = (y: number) => {
    doc.setFillColor(...NAVY)
    doc.rect(12, y, 192, 9, 'F')
    doc.setTextColor(255, 255, 255)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(7)
    doc.text('DESCRIPTION', 15, y + 5.8)
    doc.text('QTY / DAYS', 135, y + 5.8, { align: 'right' })
    doc.text('RATE', 166, y + 5.8, { align: 'right' })
    doc.text('AMOUNT', 201, y + 5.8, { align: 'right' })
  }

  doc.setTextColor(...NAVY)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(15)
  doc.text('EPHRATA TRUCKING, LLC', 12, 17)
  doc.setFont('helvetica', 'normal')
  doc.setTextColor(...MUTED)
  doc.setFontSize(8)
  doc.text('dba AAA Intermodal · 10105 SE 212th St, Kent, WA 98031', 12, 23)
  doc.text('Office (206) 866-4720 · Dispatch (206) 372-8570', 12, 28)
  doc.text('Email: seattletruck@gmail.com · USDOT 1839352 · MC 669162', 12, 33)
  doc.setTextColor(...INK)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(14)
  doc.text('Trucking INVOICE', 204, 17, { align: 'right' })
  doc.setFontSize(8)
  doc.text('PCS FORM #750056', 204, 23, { align: 'right' })
  doc.setFont('helvetica', 'normal')
  doc.text(`Invoice # ${input.invoiceNumber}`, 204, 29, { align: 'right' })
  doc.setDrawColor(...NAVY)
  doc.setLineWidth(0.7)
  doc.line(12, 38, 204, 38)

  drawFields(doc, 12, 43, 92, 1, [
    ['Bill to', input.customer],
    ['Attention', input.attention],
    ['Billing address', input.billingAddress],
    ['Phone / Email', `${input.phone} · ${input.email}`],
  ])
  drawFields(doc, 112, 43, 92, 2, [
    ['Invoice date', input.invoiceDate],
    ['Due date', input.dueDate],
    ['Payment terms', input.terms],
    ['Load #', load.id],
    ['Container #', load.container],
    ['B/L · PO · DO', `${refs.billOfLading} · ${refs.poNumber} · ${refs.deliveryOrder}`],
  ])
  drawFields(doc, 12, 134, 192, 2, [
    ['Pickup terminal', `${load.terminal} · ${load.line}`],
    ['Delivery location', load.destination],
    ['Driver / unit', `${load.driver ?? 'Unassigned'} · ${load.truck ?? 'Unit not assigned'}`],
    ['Chassis / seal', `${load.chassis} · ${load.seal}`],
  ])

  let rowY = 185
  drawChargeHeader(rowY)
  rowY += 9
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  for (const line of input.lines) {
    const description = doc.splitTextToSize(`Acct ${line.account} · ${line.item}${line.memo ? ` · ${line.memo}` : ''}`, 112)
    const rowHeight = Math.max(10, description.length * 4 + 4)
    if (rowY + rowHeight > 264) {
      doc.addPage('letter', 'portrait')
      rowY = 18
      drawChargeHeader(rowY)
      rowY += 9
    }
    doc.setDrawColor(...BORDER)
    doc.line(12, rowY + rowHeight, 204, rowY + rowHeight)
    doc.setTextColor(...INK)
    doc.text(description, 15, rowY + 4)
    doc.text(String(line.quantity), 135, rowY + 4, { align: 'right' })
    doc.text(money(line.rate), 166, rowY + 4, { align: 'right' })
    doc.setFont('helvetica', 'bold')
    doc.text(money(line.amount), 201, rowY + 4, { align: 'right' })
    doc.setFont('helvetica', 'normal')
    rowY += rowHeight
  }
  if (rowY + 24 > 264) {
    doc.addPage('letter', 'portrait')
    rowY = 22
  }
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(11)
  doc.setTextColor(...INK)
  doc.text('TOTAL DUE', 155, rowY + 12)
  doc.setTextColor(...NAVY)
  doc.text(money(input.amount), 201, rowY + 12, { align: 'right' })
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.setTextColor(...MUTED)
  doc.text(`Payment due ${input.dueDate} · ${input.terms}`, 12, rowY + 23)
  doc.text('Please include the invoice number with payment. Contact accounting for secure payment instructions.', 12, rowY + 29)
  doc.setDrawColor(...NAVY)
  doc.line(12, 271, 204, 271)
  doc.setFontSize(7)
  doc.text('Remit payments & remittance slips to: seattletruck@gmail.com · PCS Software Form #750056', 12, 276)

  const safeCustomer = input.customer.trim().replace(/[^a-z0-9]+/gi, '_').replace(/^_+|_+$/g, '') || 'Customer'
  return {
    filename: `Invoice_${safeFilename(input.invoiceNumber)}_${safeCustomer}.pdf`,
    blob: doc.output('blob'),
  }
}

function buildPortEirPdf(load: Load, signedAt: Date) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'letter' })
  const refs = loadReferences(load)
  const generatedAt = signedAt.toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'America/Los_Angeles' })
  doc.setTextColor(...NAVY)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(15)
  doc.text('Ephrata Trucking, LLC dba AAA Intermodal', 12, 17)
  doc.setTextColor(...MUTED)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.text('Email: seattletruck@gmail.com', 12, 23)
  doc.setTextColor(...INK)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(13)
  doc.text('PORT EIR · GATE TICKET', 12, 40)
  doc.setDrawColor(...NAVY)
  doc.setLineWidth(0.7)
  doc.line(12, 46, 204, 46)
  drawFields(doc, 12, 55, 192, 2, [
    ['Gate status', 'OUT · Delivery completed'],
    ['Gate-out timestamp', generatedAt],
    ['Container', load.container],
    ['Chassis', load.chassis],
    ['Terminal', load.terminal],
    ['Steamship line', load.line],
    ['Load #', load.id],
    ['B/L #', refs.billOfLading],
    ['Delivery order', refs.deliveryOrder],
    ['Customer / consignee', `${load.customer} · ${load.destination}`],
    ['Driver / truck', `${load.driver ?? 'Unassigned'} · ${load.truck ?? 'Unassigned'}`],
    ['Seal', load.seal],
  ])
  doc.setDrawColor(...BORDER)
  doc.line(12, 253, 204, 253)
  doc.setTextColor(...MUTED)
  doc.setFontSize(7)
  doc.text('Port equipment interchange gate ticket · Generated for delivery records', 12, 260)
  return { filename: `port-eir-gate-ticket-${safeFilename(load.container)}.pdf`, bytes: new Uint8Array(doc.output('arraybuffer')) }
}

export function createDeliveryReceiptPdf(load: Load, receipt: PodReceiptDetails, signedAt: Date) {
  const { filename, bytes } = buildReceiptPdf(load, receipt, signedAt)
  return { filename, blob: new Blob([bytes], { type: 'application/pdf' }) }
}

export function downloadDeliveryReceiptPdf(load: Load, receipt: PodReceiptDetails, signedAt: Date) {
  const { filename, blob } = createDeliveryReceiptPdf(load, receipt, signedAt)
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.append(anchor)
  anchor.click()
  anchor.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 1000)
}

export function openDeliveryReceiptPdf(load: Load, receipt: PodReceiptDetails, signedAt: Date) {
  const { blob } = createDeliveryReceiptPdf(load, receipt, signedAt)
  const url = URL.createObjectURL(blob)
  const openedWindow = window.open(url, '_blank')
  if (openedWindow) openedWindow.opener = null
  else downloadDeliveryReceiptPdf(load, receipt, signedAt)
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000)
}

export function downloadDeliveryDocuments(load: Load, receipt: PodReceiptDetails, signedAt: Date) {
  for (const { filename, bytes } of createDeliveryDocumentAttachments(load, receipt, signedAt)) {
    downloadPdf(filename, bytes)
  }
}

export function downloadInvoiceArchivePdf(invoice: Invoice, load?: Load) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'letter' })
  const refs = load ? loadReferences(load) : { billOfLading: '', deliveryOrder: '', poNumber: '' }
  const deliveryDate = load?.podSignedAtIso
    ? new Date(load.podSignedAtIso).toLocaleDateString('en-US', { dateStyle: 'medium' })
    : 'Not recorded'

  doc.setTextColor(...NAVY)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(15)
  doc.text('Ephrata Trucking, LLC', 12, 18)
  doc.setFont('helvetica', 'normal')
  doc.setTextColor(...MUTED)
  doc.setFontSize(8)
  doc.text('10105 SE 212th St, Kent, WA 98031 · seattletruck@gmail.com', 12, 25)
  doc.setTextColor(...INK)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(14)
  doc.text('INVOICE ARCHIVE COPY', 204, 18, { align: 'right' })
  doc.setDrawColor(...NAVY)
  doc.line(12, 33, 204, 33)

  const fields: [string, string][] = [
    ['Invoice #', invoice.id],
    ['Customer', invoice.customer],
    ['Invoice date', invoice.issued],
    ['Due date', invoice.due],
    ['Terms', invoice.terms],
    ['Container', invoice.container],
    ['Load #', invoice.loadId],
    ['BOL #', refs.billOfLading],
    ['Delivery date', deliveryDate],
    ['Status', invoice.status],
  ]
  let y = 42
  for (const [label, value] of fields) {
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(8)
    doc.setTextColor(...MUTED)
    doc.text(label.toUpperCase(), 14, y)
    doc.setFont('helvetica', 'normal')
    doc.setTextColor(...INK)
    doc.text(value || '—', 82, y)
    doc.setDrawColor(...BORDER)
    doc.line(12, y + 3, 204, y + 3)
    y += 11
  }
  y += 8
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(11)
  doc.setTextColor(...INK)
  doc.text(invoice.status === 'Paid' ? 'Invoice total / paid' : 'Open invoice total', 130, y)
  doc.setTextColor(...NAVY)
  doc.text(formatCurrency(invoice.amount), 201, y, { align: 'right' })
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.setTextColor(...MUTED)
  doc.text('Archive copy generated from the current TMS invoice ledger.', 12, y + 12)
  doc.text('Original itemized charges and POD evidence are available when recorded in the TMS.', 12, y + 18)

  const filename = `ephrata-invoice-${safeFilename(invoice.id)}.pdf`
  downloadPdf(filename, new Uint8Array(doc.output('arraybuffer')))
}

function downloadPdf(filename: string, bytes: Uint8Array) {
  const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }))
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.append(anchor)
  anchor.click()
  anchor.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 1000)
}

function buildReceiptPdf(load: Load, receipt: PodReceiptDetails, signedAt: Date) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'letter' })
  const refs = loadReferences(load)
  const moveType = receipt.moveType ?? load.moveType ?? defaultDispatchMoveType(load.type)
  const date = signedAt.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })
  const truckFields: [string, string][] = [
    ['Driver', load.driver ?? '—'],
    ['Job #', '002'],
    ['Trk #', load.truck ?? '—'],
    ['Date', date],
  ]
  const consigneeFields: [string, string][] = [
    ['Port of Origin', 'Port of TAC - Husky/WUT'],
    ['Receiving Company / Facility', receipt.companyName || `${load.customer} - ${load.destination}`],
    ['Booking / PO #', `PO# ${refs.poNumber}`],
  ]

  doc.setTextColor(...NAVY)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(15)
  doc.text('Ephrata Trucking, LLC dba AAA Intermodal', 12, 17)
  doc.setTextColor(...MUTED)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.text('10105 SE 212th St, Kent WA 98031  |  USDOT: 1839352  |  MC: 669162', 12, 23)
  doc.text('Email: seattletruck@gmail.com', 12, 28)
  doc.setTextColor(...INK)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(12)
  doc.text('EQUIPMENT DELIVERY RECEIPT', 204, 17, { align: 'right' })
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.text(`Load ${load.id}`, 204, 23, { align: 'right' })
  doc.setDrawColor(...NAVY)
  doc.setLineWidth(0.7)
  doc.line(12, 33, 204, 33)

  drawFields(doc, 12, 40, 92, 2, truckFields)
  drawFields(doc, 112, 40, 92, 3, consigneeFields)
  drawSectionLabel(doc, 'EQUIPMENT', 12, 94, 192)
  const equipmentFields: [string, string][] = [
    ['Container Unit #', load.container],
    ['Chassis #', load.chassis],
    ['Seal #', `${load.seal} - Intact`],
    ['B/L #', refs.billOfLading || '—'],
    ['Move Type', moveType.replace(/^(?:⬆️|⬇️)\s*/u, '')],
  ]
  const equipmentCellWidth = 96
  const equipmentRowHeight = 8
  equipmentFields.forEach(([label, value], index) => {
    const column = index % 2
    const row = Math.floor(index / 2)
    const x = 12 + column * equipmentCellWidth
    const y = 100 + row * equipmentRowHeight
    doc.setDrawColor(...BORDER)
    doc.setLineWidth(0.25)
    doc.rect(x, y, equipmentCellWidth, equipmentRowHeight)
    doc.setTextColor(...MUTED)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(6)
    doc.text(label, x + 2, y + 2.5)
    doc.setTextColor(...INK)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(7.5)
    if (label === 'Move Type' && moveType.startsWith('⬆️')) {
      doc.setDrawColor(...NAVY)
      doc.setLineWidth(0.55)
      doc.line(x + 3, y + 6.5, x + 3, y + 4.2)
      doc.line(x + 3, y + 4.2, x + 1.8, y + 5.4)
      doc.line(x + 3, y + 4.2, x + 4.2, y + 5.4)
      doc.text(value, x + 6, y + 6.4)
    } else if (label === 'Move Type' && moveType.startsWith('⬇️')) {
      doc.setDrawColor(...NAVY)
      doc.setLineWidth(0.55)
      doc.line(x + 3, y + 4.2, x + 3, y + 6.5)
      doc.line(x + 3, y + 6.5, x + 1.8, y + 5.3)
      doc.line(x + 3, y + 6.5, x + 4.2, y + 5.3)
      doc.text(value, x + 6, y + 6.4)
    } else {
      doc.text(value || '—', x + 2, y + 6.4)
    }
  })

  drawSectionLabel(doc, 'DRAYAGE DROP STATUS', 12, 126, 192)
  const statusOptions = ['Drop MT', 'Drop Loaded', 'Stay With', 'Chassis Only'] as const
  statusOptions.forEach((option, index) => {
    const x = 16 + index * 47
    doc.setDrawColor(...INK)
    doc.setLineWidth(0.35)
    doc.rect(x, 134, 4, 4)
    if (receipt.dropStatus === option) {
      doc.setTextColor(...NAVY)
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(10)
      doc.text('✓', x + 0.35, 137.4)
    }
    doc.setTextColor(...INK)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8.5)
    doc.text(option, x + 6, 137.2)
  })

  drawSectionLabel(doc, 'CONSIGNEE SIGN-OFF', 12, 147, 192)
  drawFields(doc, 12, 153, 94, 2, [
    ['Time In', receipt.timeIn],
    ['Time Out', receipt.timeOut],
  ])
  drawFields(doc, 12, 173, 94, 1, [['Print Name', receipt.receiverName]])
  doc.setDrawColor(...BORDER)
  doc.setLineWidth(0.35)
  doc.rect(112, 153, 92, 29)
  doc.setTextColor(...MUTED)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(7)
  doc.text('GLASS SIGNATURE', 116, 158)
  if (receipt.signatureDataUrl) {
    doc.addImage(receipt.signatureDataUrl, 'PNG', 116, 159, 82, 19, undefined, 'FAST')
  }
  doc.setDrawColor(...BORDER)
  doc.line(116, 178.5, 200, 178.5)
  doc.setTextColor(...MUTED)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(7)
  doc.text('Consignee signature', 116, 181)
  doc.setTextColor(...NAVY)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.text(`Verification Code · ${receipt.confirmationCode ?? load.podConfirmationCode ?? 'Not recorded'}`, 12, 189)

  doc.setDrawColor(...BORDER)
  doc.line(12, 194, 204, 194)
  doc.setTextColor(...INK)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.text('CUSTOMER NOTICE', 12, 201)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.setTextColor(...INK)
  doc.text(doc.splitTextToSize('Customer is responsible for reporting the empty container at least 24 hours prior to free time expiration.', 188), 12, 207)
  doc.text(doc.splitTextToSize('Container must be swept out and returned free of debris. Cleaning or disposal charges resulting from a container not returned clean may be billed to the customer.', 188), 12, 220)
  doc.setDrawColor(...NAVY)
  doc.line(12, 263, 204, 263)
  doc.setTextColor(...MUTED)
  doc.setFontSize(7)
  doc.text('Ephrata Trucking, LLC dba AAA Intermodal · seattletruck@gmail.com', 12, 269)
  doc.text(`Generated ${date} ${signedAt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`, 204, 269, { align: 'right' })
  return { filename: `Equipment Delivery Receipt (POD) - ${safeFilename(load.container)}.pdf`, bytes: new Uint8Array(doc.output('arraybuffer')) }
}

function buildInvoicePdf(load: Load, issuedAt: Date, invoiceAmount: number) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'letter' })
  const refs = loadReferences(load)
  const date = issuedAt.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric', timeZone: 'America/Los_Angeles' })

  doc.setTextColor(...NAVY)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(15)
  doc.text('Ephrata Trucking, LLC dba AAA Intermodal', 12, 17)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.setTextColor(...MUTED)
  doc.text('10105 SE 212th St, Kent WA 98031  |  USDOT: 1839352  |  MC: 669162', 12, 23)
  doc.text('Email: seattletruck@gmail.com', 12, 28)
  doc.setTextColor(...INK)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(14)
  doc.text('PCS INVOICE', 204, 17, { align: 'right' })
  doc.setFontSize(10)
  doc.text('#750056', 204, 24, { align: 'right' })
  doc.setDrawColor(...NAVY)
  doc.line(12, 33, 204, 33)

  drawFields(doc, 12, 40, 192, 1, [
    ['Bill To', `${load.customer} - ${load.destination}`],
    ['Invoice Date', date],
    ['Terms', 'Net 30'],
  ])
  drawFields(doc, 12, 56, 192, 1, [
    ['Container', load.container],
    ['PO #', refs.poNumber],
    ['Load #', load.id],
  ])

  const x = [12, 90, 159, 204]
  const y = 81
  doc.setFillColor(...NAVY)
  doc.rect(12, y, 192, 9, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.text('Description', x[0] + 3, y + 6)
  doc.text('Reference', x[1] + 3, y + 6)
  doc.text('Amount', x[3] - 3, y + 6, { align: 'right' })

  let rowY = y + 9
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  for (const charge of load.charges) {
    doc.setDrawColor(...BORDER)
    doc.line(12, rowY + 9, 204, rowY + 9)
    doc.setTextColor(...INK)
    doc.text(doc.splitTextToSize(charge.label, 73), 15, rowY + 5)
    doc.text(`Container ${load.container}`, 93, rowY + 5)
    doc.text(formatCurrency(charge.amount), 201, rowY + 5, { align: 'right' })
    rowY += 11
  }
  rowY += 8
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(11)
  doc.setTextColor(...INK)
  doc.text('Invoice Total', 150, rowY)
  doc.setTextColor(...NAVY)
  doc.text(formatCurrency(invoiceAmount), 201, rowY, { align: 'right' })
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.setTextColor(...MUTED)
  doc.text(`Payment due ${new Date(issuedAt.getTime() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric', timeZone: 'America/Los_Angeles' })} · Net 30`, 12, rowY + 12)
  doc.setDrawColor(...NAVY)
  doc.line(12, 263, 204, 263)
  doc.setFontSize(7)
  doc.text('Thank you for your business. Please include invoice #750056 with payment.', 12, 269)
  return { filename: 'PCS-invoice-750056.pdf', bytes: new Uint8Array(doc.output('arraybuffer')) }
}

function drawFields(doc: jsPDF, x: number, y: number, width: number, columns: number, fields: [string, string][]) {
  const cellWidth = width / columns
  const cellHeight = columns === 1 ? 21 : 20
  doc.setDrawColor(...BORDER)
  doc.setLineWidth(0.3)
  fields.forEach(([label, value], index) => {
    const column = index % columns
    const row = Math.floor(index / columns)
    const cellX = x + column * cellWidth
    const cellY = y + row * cellHeight
    doc.rect(cellX, cellY, cellWidth, cellHeight)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(7)
    doc.setTextColor(...MUTED)
    doc.text(label.toUpperCase(), cellX + 3, cellY + 5)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(9)
    doc.setTextColor(...INK)
    const valueLines = doc.splitTextToSize(value || '—', cellWidth - 6)
    doc.text(valueLines.slice(0, 2), cellX + 3, cellY + 11)
  })
}

function drawSectionLabel(doc: jsPDF, label: string, x: number, y: number, width: number) {
  doc.setFillColor(...NAVY)
  doc.rect(x, y, width, 6, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.text(label, x + 3, y + 4.2)
}

function formatCurrency(amount: number) {
  return amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' })
}

function safeFilename(value: string) {
  return value.replace(/[^a-z0-9-]+/gi, '-')
}

