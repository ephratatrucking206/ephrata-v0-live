export type ReportValue = string | number | boolean | null | undefined

export async function downloadExcelReport(fileName: string, sheetName: string, headers: string[], rows: ReportValue[][]) {
  const XLSX = await import('xlsx')
  const sheet = XLSX.utils.aoa_to_sheet([headers, ...rows])
  sheet['!cols'] = headers.map((header) => ({ wch: Math.min(32, Math.max(header.length + 2, 14)) }))
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, sheet, sheetName.slice(0, 31))
  XLSX.writeFile(workbook, `${fileName}.xlsx`, { compression: true })
}

export function downloadCsvReport(fileName: string, headers: string[], rows: ReportValue[][]) {
  const csv = [headers, ...rows]
    .map((row) => row.map((value) => csvCell(value)).join(','))
    .join('\r\n')
  const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' })
  downloadBlob(blob, `${fileName}.csv`)
}

export async function downloadPdfReport(title: string, fileName: string, headers: string[], rows: ReportValue[][]) {
  const { jsPDF } = await import('jspdf')
  const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' })
  const margin = 36
  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()
  const printableWidth = pageWidth - margin * 2
  const colWidth = printableWidth / headers.length
  let y = margin

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(15)
  doc.text(title, margin, y)
  y += 24
  doc.setFontSize(7)
  doc.setFillColor(27, 77, 137)
  doc.setTextColor(255, 255, 255)
  doc.rect(margin, y - 10, printableWidth, 18, 'F')
  headers.forEach((header, index) => doc.text(truncate(header, Math.max(8, Math.floor(colWidth / 4))), margin + index * colWidth + 3, y + 2))
  y += 20

  doc.setTextColor(31, 41, 55)
  doc.setFont('helvetica', 'normal')
  for (const row of rows) {
    const values = row.map((value, index) => doc.splitTextToSize(String(value ?? '—'), Math.max(22, colWidth - 6)).slice(0, 2))
    const lineCount = Math.max(1, ...values.map((lines) => lines.length))
    const rowHeight = Math.max(19, lineCount * 8 + 8)
    if (y + rowHeight > pageHeight - margin) {
      doc.addPage()
      y = margin
    }
    if (Math.floor((y - margin) / rowHeight) % 2 === 0) {
      doc.setFillColor(244, 247, 251)
      doc.rect(margin, y - 11, printableWidth, rowHeight, 'F')
    }
    values.forEach((lines, index) => doc.text(lines, margin + index * colWidth + 3, y))
    y += rowHeight
  }

  doc.save(`${fileName}.pdf`)
}

function csvCell(value: ReportValue) {
  const raw = String(value ?? '')
  const safe = /^[=+@\-]/.test(raw) ? `'${raw}` : raw
  return `"${safe.replace(/"/g, '""')}"`
}

function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = fileName
  document.body.append(anchor)
  anchor.click()
  anchor.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 1000)
}

function truncate(value: string, maxLength: number) {
  return value.length > maxLength ? `${value.slice(0, maxLength - 1)}…` : value
}

