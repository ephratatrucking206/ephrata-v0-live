'use client'

import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { Check, Download } from 'lucide-react'

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>
}

type PwaInstallContextValue = {
  promptInstall: InstallPromptEvent | null
  installed: boolean
}

const PwaInstallContext = createContext<PwaInstallContextValue | null>(null)

export function PwaInstallProvider({ children }: { children: ReactNode }) {
  const [promptInstall, setPromptInstall] = useState<InstallPromptEvent | null>(null)
  const [installed, setInstalled] = useState(false)

  useEffect(() => {
    setInstalled(
      window.matchMedia('(display-mode: standalone)').matches ||
        (navigator as Navigator & { standalone?: boolean }).standalone === true,
    )

    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault()
      setPromptInstall(event as InstallPromptEvent)
    }
    const handleAppInstalled = () => {
      setPromptInstall(null)
      setInstalled(true)
    }

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    window.addEventListener('appinstalled', handleAppInstalled)

    if (process.env.NODE_ENV === 'production' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => undefined)
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
      window.removeEventListener('appinstalled', handleAppInstalled)
    }
  }, [])

  return (
    <PwaInstallContext.Provider value={{ promptInstall, installed }}>
      {children}
    </PwaInstallContext.Provider>
  )
}

export function InstallAppButton() {
  const context = useContext(PwaInstallContext)
  const [message, setMessage] = useState('')

  if (!context) throw new Error('InstallAppButton must be used within PwaInstallProvider')

  const handleInstall = async () => {
    setMessage('')
    if (context.installed) return

    if (context.promptInstall) {
      try {
        await context.promptInstall.prompt()
        const choice = await context.promptInstall.userChoice
        if (choice.outcome === 'accepted') setMessage('Ephrata TMS is installing.')
        else setMessage('You can install Ephrata TMS later from your browser menu.')
      } catch {
        setMessage('Open your browser menu and choose Install app or Add to Home Screen.')
      }
      return
    }

    const isAppleTouchDevice = /iphone|ipad|ipod/i.test(navigator.userAgent) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
    setMessage(
      isAppleTouchDevice
        ? 'In Safari, tap Share, then Add to Home Screen.'
        : 'Open your browser menu and choose Install app or Add to Home Screen.',
    )
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        onClick={handleInstall}
        disabled={context.installed}
        aria-label={context.installed ? 'Ephrata TMS is installed' : 'Install Ephrata TMS App'}
        className="inline-flex min-h-9 items-center gap-2 rounded-md border border-primary/30 bg-primary/5 px-3 text-xs font-semibold text-primary transition-colors hover:bg-primary/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-default disabled:opacity-70"
      >
        {context.installed ? <Check className="size-3.5" aria-hidden /> : <Download className="size-3.5" aria-hidden />}
        {context.installed ? 'Ephrata TMS Installed' : '⬇️ Install Ephrata TMS App'}
      </button>
      {message && <span role="status" className="max-w-56 text-[11px] text-muted-foreground">{message}</span>}
    </div>
  )
}

export function AppVersionFooter() {
  return (
    <footer className="flex min-h-7 shrink-0 items-center justify-center border-t border-border bg-card px-3 py-1 font-mono text-[10px] text-muted-foreground">
      Ephrata TMS v1.0 · Live Cloud Sync
    </footer>
  )
}

export function usePwaInstall() {
  const context = useContext(PwaInstallContext)
  if (!context) throw new Error('usePwaInstall must be used within PwaInstallProvider')
  return context
}

export { PwaInstallContext }

export default function PwaInstallStatus() {
  return null
}
