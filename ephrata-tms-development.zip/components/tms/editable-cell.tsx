'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'

export function EditableCell({
  value,
  label,
  onCommit,
  className,
  align = 'left',
  disabled = false,
}: {
  value: string
  label: string
  onCommit: (value: string) => void
  className?: string
  align?: 'left' | 'right'
  disabled?: boolean
}) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(value)

  useEffect(() => setDraft(value), [value])

  const commit = () => {
    const nextValue = draft.trim()
    if (nextValue !== value) onCommit(nextValue)
    setEditing(false)
  }

  if (editing) {
    return (
      <input
        autoFocus
        disabled={disabled}
        aria-label={`Edit ${label}`}
        value={draft}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === 'Enter') {
            event.preventDefault()
            commit()
          }
          if (event.key === 'Escape') {
            setDraft(value)
            setEditing(false)
          }
        }}
        className={cn(
          'min-w-16 max-w-full rounded-sm border border-primary/40 bg-background px-1 py-0.5 text-inherit outline-none ring-2 ring-ring/30 disabled:opacity-70',
          align === 'right' && 'text-right',
          className,
        )}
      />
    )
  }

  return (
    <button
      type="button"
      disabled={disabled}
      aria-label={`Edit ${label}: ${value || 'empty'}`}
      title="Click to edit"
      onClick={() => setEditing(true)}
      className={cn(
        'max-w-full rounded-sm text-left decoration-dotted underline-offset-2 hover:bg-accent/20 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-70',
        align === 'right' && 'w-full text-right',
        className,
      )}
    >
      {value || <span className="text-muted-foreground">—</span>}
    </button>
  )
}

export function EditableText({
  value,
  label,
  onCommit,
  className,
  disabled = false,
}: {
  value: string
  label: string
  onCommit: (value: string) => void
  className?: string
  disabled?: boolean
}) {
  return <EditableCell value={value} label={label} onCommit={onCommit} className={className} disabled={disabled} />
}

export function EditableAmount({
  value,
  label,
  onCommit,
  className,
  disabled = false,
}: {
  value: number
  label: string
  onCommit: (value: number) => void
  className?: string
  disabled?: boolean
}) {
  return (
    <EditableCell
      value={value.toFixed(2)}
      label={label}
      align="right"
      className={className}
      disabled={disabled}
      onCommit={(nextValue) => {
        const parsed = Number(nextValue.replace(/[$,]/g, ''))
        if (Number.isFinite(parsed)) onCommit(parsed)
      }}
    />
  )
}
