'use client'

import { useMemo, useState } from 'react'
import { Download, Eye, FileDown, FileText, Smartphone, Globe2, Check, CalendarClock, Search, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { formatUsd, loadReferences, loadTotal, SIGNATURE_LOAD_ID, type Invoice, type Load } from '@/lib/tms-data'
import { useTms } from './tms-store'
import { PageHeader } from './page-header'
import { EditableAmount, EditableCell } from './editable-cell'
import { ClickableEditableCell } from './clickable-editable-cell'
import { ReportExportToolbar } from './report-export-toolbar'
import { downloadExcelReport } from '@/lib/report-exports'
import { downloadDeliveryDocuments, downloadInvoiceArchivePdf } from '@/lib/delivery-documents'
import { DeliveryReceiptPreview } from './delivery-receipt-preview'
import { PcsInvoiceForm } from './pcs-invoice-form'

export function BillingView() {
  const { invoices, loads, newInvoiceId, setView, openTracking, releaseFridayBatch, updateInvoice } = useTms()
  const [formLoadId, setFormLoadId] = useState(SIGNATURE_LOAD_ID)
  const [formLoadOverride, setFormLoadOverride] = useState<Load | null>(null)
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false)
  const [podPreviewLoadId, setPodPreviewLoadId] = useState<string | null>(null)
  const podPreviewLoad = loads.find((load) => load.id === podPreviewLoadId)
  const [batchExportNotice, setBatchExportNotice] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [historyCustomer, setHistoryCustomer] = useState<string | null>(null)
  const awaitingPod = loads.filter((load) => !load.podSigned && (load.status === 'At Delivery' || load.status === 'In Transit'))
  const openAr = invoices.filter((invoice) => invoice.status !== 'Paid').reduce((sum, invoice) => sum + invoice.amount, 0)
  const overdue = invoices.filter((invoice) => invoice.status === 'Overdue').reduce((sum, invoice) => sum + invoice.amount, 0)
  const today = new Date().toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' })
  const billedToday = invoices.filter((invoice) => invoice.issued === today).reduce((sum, invoice) => sum + invoice.amount, 0)
  const formLoad = formLoadOverride ?? loads.find((load) => load.id === formLoadId) ?? null
  const customers = useMemo(() => Array.from(new Set([...invoices.map((invoice) => invoice.customer), ...loads.map((load) => load.customer)])).filter(Boolean).sort((a, b) => a.localeCompare(b)), [invoices, loads])
  const filteredInvoices = invoices.filter((invoice) => matchesInvoiceSearch(invoice, loads.find((load) => load.id === invoice.loadId), searchQuery))
  const matchingCustomers = customers.filter((customer) => !searchQuery || customer.toLowerCase().includes(searchQuery.trim().toLowerCase()) || invoices.some((invoice) => invoice.customer === customer && matchesInvoiceSearch(invoice, loads.find((load) => load.id === invoice.loadId), searchQuery)) || loads.some((load) => load.customer === customer && matchesLoadSearch(load, searchQuery)))
  const customerHistory = historyCustomer ? invoices.filter((invoice) => invoice.customer === historyCustomer) : []
  const historyBilled = customerHistory.reduce((sum, invoice) => sum + invoice.amount, 0)
  const historyPaid = customerHistory.filter((invoice) => invoice.status === 'Paid').reduce((sum, invoice) => sum + invoice.amount, 0)
  const reportHeaders = ['Commercial Invoice No.', 'Post Date', 'Due Date', 'Bill-To Customer', 'B/L #', 'Container #', 'A/R Account 1030', 'Linehaul Freight Account 3000', 'Port Demurrage & Accessorial Account 3010', 'Total Receivable', 'Dispatcher Approval', 'Settlement Status', 'Accounting Sync Ref']
  const reportRows = invoices.map((invoice) => {
    const load = loads.find((candidate) => candidate.id === invoice.loadId)
    const refs = load ? loadReferences(load) : { billOfLading: '', deliveryOrder: '', poNumber: '' }
    const linehaul = load?.charges.find((charge) => charge.label.toLowerCase().includes('linehaul'))?.amount ?? invoice.amount
    const accessorials = load?.charges.filter((charge) => !/linehaul/i.test(charge.label)).reduce((sum, charge) => sum + charge.amount, 0) ?? 0
    return [invoice.id, toIsoDate(invoice.issued), toIsoDate(invoice.due), invoice.customer, refs.billOfLading, invoice.container, formatUsd(invoice.amount), formatUsd(linehaul), formatUsd(accessorials), formatUsd(invoice.amount), approvalBadgeLabel(invoice), invoice.status === 'Paid' ? 'Settled & Reconciled' : 'Open', invoice.qboRef]
  })
  const deliveredLoadIds = new Set(loads.filter((load) => load.status === 'Delivered' || load.podSigned).map((load) => load.id))
  const approvedForBatch = invoices.filter((invoice) => invoice.approvalStatus === 'Approved for Friday Billing' && invoice.status !== 'Paid' && deliveredLoadIds.has(invoice.loadId))
  const paidInvoices = invoices.filter((invoice) => invoice.status === 'Paid')
  const needsReview = invoices.filter((invoice) => invoice.approvalStatus === 'Needs Review' && deliveredLoadIds.has(invoice.loadId))
  const approvedReportRows = invoices.flatMap((invoice, index) => invoice.approvalStatus !== 'Needs Review' ? [reportRows[index]] : [])
  const batchRows = invoices.flatMap((invoice, index) => approvedForBatch.some((item) => item.id === invoice.id) ? [reportRows[index]] : [])

  const openFormForLoad = (loadId: string) => {
    setFormLoadId(loadId)
    setFormLoadOverride(null)
    setIsInvoiceOpen(true)
  }

  const openFormForInvoice = (invoice: Invoice) => {
    setFormLoadId(invoice.loadId)
    setFormLoadOverride(loads.find((load) => load.id === invoice.loadId) ?? {
      id: invoice.loadId,
      container: invoice.container,
      size: '40HC',
      type: 'Import',
      terminal: 'T18',
      line: 'Archived invoice',
      customer: invoice.customer,
      destination: 'Destination not available for this archived load',
      driver: null,
      truck: null,
      chassis: 'Not recorded',
      status: 'Dispatched',
      appt: invoice.issued,
      lfd: '—',
      weightLbs: 0,
      seal: 'Not recorded',
      charges: [{ label: 'Drayage linehaul', amount: invoice.amount }],
      podSigned: false,
    })
    setIsInvoiceOpen(true)
  }

  const exportBatch = async () => {
    setBatchExportNotice('')
    try {
      await downloadExcelReport('ephrata-friday-invoice-batch', 'Friday Batch', reportHeaders, batchRows)
      setBatchExportNotice(`${batchRows.length} approved invoice row${batchRows.length === 1 ? '' : 's'} exported.`)
    } catch {
      setBatchExportNotice('Excel export failed. Please try again.')
    }
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <PageHeader title="Commercial Billing & Accounts Receivable" subtitle="Commercial freight receivables · scheduled consolidated billing">
        <span className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-card px-2.5 text-xs font-medium text-muted-foreground">
          <FileText className="size-3.5" aria-hidden />
          QBO mapping · demo mode
        </span>
      </PageHeader>

      <div aria-label="General ledger account summary" className="border-b border-border bg-muted/40 px-4 py-2">
        <p className="font-mono text-[10px] font-semibold text-muted-foreground">A/R Acct 1030 | Linehaul Freight Acct 3000 | Port Demurrage &amp; Accessorial Acct 3010</p>
      </div>

      <dl className="grid grid-cols-2 gap-px border-b border-border bg-border md:grid-cols-4">
        <Metric label="Open AR" value={formatUsd(openAr)} />
        <Metric label="Overdue" value={formatUsd(overdue)} emphasize={overdue > 0} />
        <Metric label="Billed today" value={formatUsd(billedToday)} />
        <Metric label="Awaiting POD" value={`${awaitingPod.length} loads`} />
      </dl>

      <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-auto p-4 pb-28">
        <label className="relative block max-w-xl">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <span className="sr-only">Filter invoices and customers</span>
          <input value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} placeholder="Filter by Customer Name, Container #, BOL, or Date" className="h-10 w-full rounded-md border border-input bg-card pl-9 pr-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" />
        </label>
        <ReportExportToolbar
          fileName="ephrata-ar-friday-billing"
          sheetName="A-R and Friday Batch"
          reportTitle="Commercial Freight Billing & Accounts Receivable Register"
          headers={reportHeaders}
          rows={approvedReportRows}
          excelLabel="Export to Excel (.xlsx)"
        />
        <section aria-labelledby="customer-directory-heading" className="overflow-hidden rounded-md border border-border bg-card">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-3 py-2">
            <div><h2 id="customer-directory-heading" className="text-sm font-semibold">Customer Directory &amp; History</h2><p className="mt-0.5 text-[11px] text-muted-foreground">Select a customer to review ledger totals, invoices, and available delivery records.</p></div>
            <span className="font-mono text-[11px] text-muted-foreground">{matchingCustomers.length} customers</span>
          </div>
          <div className="flex flex-wrap gap-2 p-3">
            {matchingCustomers.map((customer) => (
              <button key={customer} type="button" onClick={() => setHistoryCustomer(customer)} className="rounded-full border border-border bg-background px-3 py-1.5 text-xs font-medium hover:border-primary/40 hover:bg-primary/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{customer}<span className="ml-2 font-mono text-muted-foreground">{invoices.filter((invoice) => invoice.customer === customer).length}</span></button>
            ))}
          </div>
        </section>
        <section aria-labelledby="qbo-heading" className="overflow-hidden rounded-md border border-border bg-card">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-3 py-2">
            <div>
              <h2 id="qbo-heading" className="text-sm font-semibold">Commercial Freight Billing &amp; Accounts Receivable Register</h2>
              <p className="mt-0.5 text-[11px] text-muted-foreground">Commercial freight ledger · PCS Software Form #750056</p>
            </div>
            <button type="button" onClick={() => openFormForLoad(SIGNATURE_LOAD_ID)} className="pointer-events-auto relative z-10 inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              <FileText className="size-3.5" aria-hidden /> Open PCS invoice form
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="pointer-events-auto relative z-10 w-full min-w-[1320px] border-collapse text-xs">
              <thead className="bg-muted text-left">
                <tr className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  {['Commercial Invoice #', 'Load #', 'Bill-To Customer', 'Container', 'POD Verification', 'Invoice Date', 'Due Date', 'Payment Terms', 'Dispatcher Review', 'Settlement Status', 'Settlement Reference', 'Accounting Sync Ref', 'Invoice Amount', 'Commercial Invoice Status', 'PCS Form #750056'].map((heading) => (
                    <th key={heading} scope="col" className={cn('whitespace-nowrap border-b border-border px-2.5 py-2 font-medium', heading === 'Invoice Amount' && 'text-right')}>{heading}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                  {filteredInvoices.map((invoice) => {
                    const isNew = invoice.id === newInvoiceId
                    const invoiceLoad = loads.find((candidate) => candidate.id === invoice.loadId)
                    return (
                    <tr
                      key={invoice.id}
                      tabIndex={0}
                      aria-label={`Open PCS invoice form for load ${invoice.loadId}, invoice ${invoice.id}`}
                      onClick={(event) => {
                        const target = event.target as HTMLElement
                        if (target.closest('button, input, textarea, select, a, [contenteditable="true"]')) return
                        openFormForInvoice(invoice)
                      }}
                      onKeyDown={(event) => {
                        if (event.target !== event.currentTarget) return
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault()
                          openFormForInvoice(invoice)
                        }
                      }}
                      className={cn('pointer-events-auto cursor-pointer border-b border-border/70 last:border-0 hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring', isNew ? 'row-arrive bg-accent/15' : '')}
                    >
                      <td className="whitespace-nowrap px-2.5 py-1.5 font-mono font-semibold">
                        <ClickableEditableCell value={invoice.id} label="invoice number" openLabel={`Open invoice ${invoice.id}`} onOpen={() => openFormForInvoice(invoice)} onCommit={(value) => updateInvoice(invoice.id, 'id', value)} />
                        {isNew && <span className="ml-1.5 rounded-sm bg-accent px-1 py-px font-sans text-[10px] font-semibold text-accent-foreground">New · e-POD</span>}
                      </td>
                      <td className="px-2.5 py-1.5 font-mono"><ClickableEditableCell value={invoice.loadId} label="load number" openLabel={`Open invoice for load ${invoice.loadId}`} onOpen={() => openFormForInvoice(invoice)} onCommit={(value) => updateInvoice(invoice.id, 'loadId', value)} /></td>
                      <td className="whitespace-nowrap px-2.5 py-1.5"><button type="button" onClick={(event) => { event.stopPropagation(); setHistoryCustomer(invoice.customer) }} className="font-medium text-primary underline decoration-dotted underline-offset-2 hover:text-primary/80">{invoice.customer}</button></td>
                      <td className="whitespace-nowrap px-2.5 py-1.5 font-mono text-muted-foreground"><EditableInvoiceCell invoice={invoice} field="container" label="container" /></td>
                      <td className="whitespace-nowrap px-2.5 py-1.5">{invoiceLoad?.podSigned && invoiceLoad.podReceipt ? <div className="flex items-center gap-2"><span className="font-mono text-[10px] font-semibold text-emerald-700 dark:text-emerald-300">{invoiceLoad.podConfirmationCode}</span><button type="button" title="View signed proof of delivery" aria-label={`View signed POD for load ${invoice.loadId}`} onClick={() => setPodPreviewLoadId(invoiceLoad.id)} className="inline-flex size-8 items-center justify-center rounded border border-border hover:bg-muted"><Eye className="size-3.5" aria-hidden /></button></div> : <span className="text-[10px] text-muted-foreground">Awaiting POD</span>}</td>
                      <td className="px-2.5 py-1.5 font-mono text-muted-foreground"><EditableInvoiceCell invoice={invoice} field="issued" label="issued date" /></td>
                      <td className="px-2.5 py-1.5 font-mono text-muted-foreground"><EditableInvoiceCell invoice={invoice} field="due" label="due date" /></td>
                      <td className="whitespace-nowrap px-2.5 py-1.5 text-muted-foreground"><EditableInvoiceCell invoice={invoice} field="terms" label="terms" /></td>
                      <td className="min-w-44 px-2.5 py-1.5">
                        <span className={cn('inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-semibold', invoice.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' : invoice.approvalStatus === 'Needs Review' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-800')}>
                          {invoice.approvalStatus === 'Needs Review' ? <CalendarClock className="size-3" aria-hidden /> : <Check className="size-3" aria-hidden />}{approvalBadgeLabel(invoice)}
                        </span>
                        {invoice.approvedBy && <span className="mt-1 block text-[9px] text-muted-foreground">{invoice.approvedBy}</span>}
                      </td>
                      <td className="whitespace-nowrap px-2.5 py-1.5">
                        <button type="button" disabled={invoice.status === 'Paid'} onClick={() => updateInvoice(invoice.id, 'status', 'Paid')} aria-label={invoice.status === 'Paid' ? `Invoice ${invoice.id} settled and reconciled` : `Mark invoice ${invoice.id} as settled and reconciled`} className={cn('rounded-full px-2 py-1 text-[10px] font-semibold disabled:cursor-default', invoice.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' : 'border border-border bg-background text-muted-foreground hover:bg-muted')}>{invoice.status === 'Paid' ? 'Settled & Reconciled' : 'Mark settled'}</button>
                      </td>
                      <td className="px-2.5 py-1.5 font-mono text-muted-foreground"><EditableInvoiceCell invoice={invoice} field="paymentReference" label="check number or ACH confirmation" /></td>
                      <td className="px-2.5 py-1.5 font-mono text-muted-foreground"><EditableInvoiceCell invoice={invoice} field="qboRef" label="QuickBooks reference" /></td>
                      <td className="px-2.5 py-1.5 text-right font-mono font-semibold"><EditableInvoiceAmount invoice={invoice} /></td>
                      <td className="px-2.5 py-1.5"><EditableInvoiceCell invoice={invoice} field="status" label="invoice status" className={invoice.status === 'Paid' ? 'text-success' : invoice.status === 'Overdue' ? 'text-destructive' : ''} /></td>
                      <td className="px-2.5 py-1.5">
                        <button type="button" disabled={!invoiceLoad?.podSigned} onClick={() => openFormForInvoice(invoice)} title={invoiceLoad?.podSigned ? `Ready to invoice load ${invoice.loadId}` : 'A signed POD is required before invoicing.'} className="pointer-events-auto relative z-10 whitespace-nowrap rounded-sm border border-primary/30 px-1.5 py-px text-[11px] font-semibold text-primary hover:bg-primary/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-45">{invoiceLoad?.podSigned ? 'Ready to Invoice' : 'Awaiting POD'}</button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </section>

        <section aria-labelledby="friday-batch-heading" className="overflow-hidden rounded-md border border-border bg-card">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-3 py-2">
            <div>
              <h2 id="friday-batch-heading" className="text-sm font-semibold">Scheduled Friday Night Consolidated Billing Engine (6:00 PM PST Release)</h2>
              <p className="mt-0.5 text-[11px] text-muted-foreground">Only dispatcher-approved, delivered loads are eligible. Review invoices from the register before release.</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button type="button" disabled={approvedForBatch.length === 0} onClick={() => void exportBatch()} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-2.5 text-xs font-semibold hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50"><Download className="size-3.5" aria-hidden />Export Excel</button>
              <button type="button" disabled={approvedForBatch.length === 0} onClick={releaseFridayBatch} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-primary px-3 text-xs font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"><CalendarClock className="size-3.5" aria-hidden />Release Consolidated Friday Billing</button>
            </div>
          </div>
          {batchExportNotice && <p role="status" className="border-b border-border px-3 py-1.5 text-[10px] text-muted-foreground">{batchExportNotice}</p>}
          {needsReview.length > 0 && <p className="border-b border-amber-200 bg-amber-50 px-3 py-2 text-[11px] text-amber-950">{needsReview.length} delivered invoice{needsReview.length === 1 ? '' : 's'} still need dispatcher review and approval; they are excluded from this batch.</p>}
          {approvedForBatch.length === 0 ? (
            <p className="px-3 py-6 text-center text-xs text-muted-foreground">No approved, unpaid invoices are waiting for this batch.</p>
          ) : (
            <ul className="divide-y divide-border/70 text-xs">
              {approvedForBatch.map((invoice) => (
                <li key={invoice.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-3 py-2">
                  <button type="button" onClick={() => openFormForInvoice(invoice)} className="font-mono font-semibold text-primary underline decoration-dotted underline-offset-2">{invoice.id}</button>
                  <span className="font-mono text-muted-foreground">Load {invoice.loadId} · {invoice.container}</span>
                  <span className="min-w-0 flex-1 truncate">{invoice.customer}</span>
                  <span className="text-[10px] text-muted-foreground">Approved by {invoice.approvedBy ?? 'Dispatcher'}</span>
                  <span className="font-mono font-semibold">{formatUsd(invoice.amount)}</span>
                </li>
              ))}
            </ul>
          )}
          <p className="border-t border-border bg-muted/40 px-3 py-2 text-[10px] text-muted-foreground">Demo release marks eligible invoices as audited and approved for Friday billing. Email delivery and accounting-system synchronization are not connected.</p>
        </section>

        <section aria-labelledby="paid-ledger-heading" className="overflow-hidden rounded-md border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <div><h2 id="paid-ledger-heading" className="text-sm font-semibold">Settled &amp; Reconciled Ledger</h2><p className="mt-0.5 text-[11px] text-muted-foreground">Record the check number or ACH confirmation for each reconciled freight invoice.</p></div>
            <span className="font-mono text-[11px] text-muted-foreground">{paidInvoices.length} settled</span>
          </div>
          {paidInvoices.length === 0 ? <p className="px-3 py-5 text-center text-xs text-muted-foreground">No invoices are marked paid yet.</p> : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] border-collapse text-xs">
                <thead className="bg-muted text-left"><tr className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{['Commercial Invoice #', 'Bill-To Customer', 'Container', 'Settled Amount', 'Settlement Reference'].map((heading) => <th key={heading} scope="col" className="border-b border-border px-2.5 py-2 font-medium">{heading}</th>)}</tr></thead>
                <tbody>{paidInvoices.map((invoice) => <tr key={invoice.id} className="border-b border-border/70 last:border-0">
                  <td className="px-2.5 py-2 font-mono font-semibold"><button type="button" onClick={() => openFormForInvoice(invoice)} className="text-primary underline decoration-dotted underline-offset-2">{invoice.id}</button></td>
                  <td className="px-2.5 py-2"><button type="button" onClick={() => setHistoryCustomer(invoice.customer)} className="text-primary underline decoration-dotted underline-offset-2">{invoice.customer}</button></td><td className="px-2.5 py-2 font-mono">{invoice.container}</td><td className="px-2.5 py-2 font-mono font-semibold">{formatUsd(invoice.amount)}</td>
                  <td className="px-2.5 py-2 font-mono"><EditableInvoiceCell invoice={invoice} field="paymentReference" label="check number or ACH confirmation" /></td>
                </tr>)}</tbody>
              </table>
            </div>
          )}
        </section>

        <section aria-labelledby="pod-heading" className="overflow-hidden rounded-md border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <h2 id="pod-heading" className="text-sm font-semibold">Awaiting Consignee Delivery Receipt &amp; Proof of Delivery · Unbilled</h2>
            <p className="font-mono text-[11px] text-muted-foreground">{formatUsd(awaitingPod.reduce((sum, load) => sum + loadTotal(load), 0))} pending</p>
          </div>
          {awaitingPod.length === 0 ? (
            <p className="px-3 py-6 text-center text-xs text-muted-foreground">Every delivered load has a signed POD.</p>
          ) : (
            <ul className="divide-y divide-border/70 text-xs">
              {awaitingPod.map((load) => (
                <li key={load.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-3 py-2">
                  <span className="font-mono font-semibold">{load.id}</span>
                  <span className="font-mono text-muted-foreground">{load.container}</span>
                  <span className="min-w-0 flex-1 truncate">{load.customer}</span>
                  <span className="text-muted-foreground">{load.driver}</span>
                  <span className="rounded-sm bg-muted px-1.5 py-0.5 text-[10px]">{load.status}</span>
                  <span className="w-16 text-right font-mono">{formatUsd(loadTotal(load))}</span>
                  <button type="button" onClick={() => openTracking(load.id)} className="pointer-events-auto relative z-10 inline-flex items-center gap-1 rounded-sm border border-border px-1.5 py-px text-[11px] font-medium hover:bg-muted"><Globe2 className="size-3" aria-hidden /> Track</button>
                  {load.id === SIGNATURE_LOAD_ID && <button type="button" onClick={() => setView('driver')} className="inline-flex items-center gap-1 rounded-sm border border-primary/30 px-1.5 py-px text-[11px] font-medium text-primary hover:bg-primary/5"><Smartphone className="size-3" aria-hidden /> Open driver view</button>}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {historyCustomer && (
        <div className="fixed inset-0 z-40 flex justify-end bg-slate-950/45" onMouseDown={(event) => event.target === event.currentTarget && setHistoryCustomer(null)}>
          <section role="dialog" aria-modal="true" aria-labelledby="customer-history-title" className="flex h-full w-full max-w-2xl flex-col overflow-hidden border-l border-border bg-background shadow-2xl">
            <header className="flex items-start justify-between gap-4 border-b border-border px-5 py-4">
              <div><p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Customer history &amp; ledger</p><h2 id="customer-history-title" className="mt-1 text-xl font-semibold">{historyCustomer}</h2><p className="mt-1 text-xs text-muted-foreground">Invoice and delivery records currently available in this preview session.</p></div>
              <button type="button" aria-label="Close customer history" onClick={() => setHistoryCustomer(null)} className="rounded-md p-2 text-muted-foreground hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><X className="size-4" aria-hidden /></button>
            </header>
            <div className="grid grid-cols-3 gap-px border-b border-border bg-border">
              <HistoryMetric label="Lifetime billed" value={formatUsd(historyBilled)} />
              <HistoryMetric label="Paid" value={formatUsd(historyPaid)} />
              <HistoryMetric label="Open balance" value={formatUsd(historyBilled - historyPaid)} />
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto p-4">
              <h3 className="text-sm font-semibold">Invoice &amp; delivery archive</h3>
              {customerHistory.length === 0 ? <p className="mt-4 rounded-md border border-dashed border-border p-5 text-center text-xs text-muted-foreground">No invoices for this customer are in the current session.</p> : (
                <ul className="mt-3 divide-y divide-border rounded-md border border-border">
                  {customerHistory.map((invoice) => {
                    const load = loads.find((candidate) => candidate.id === invoice.loadId)
                    const deliveryDate = load?.podSignedAtIso ? new Date(load.podSignedAtIso).toLocaleDateString('en-US', { dateStyle: 'medium' }) : 'Not recorded'
                    const hasPod = Boolean(load?.podSigned && load.podReceipt && load.podSignedAtIso)
                    return (
                      <li key={invoice.id} className="grid gap-3 p-3 sm:grid-cols-[1fr_auto] sm:items-center">
                        <div className="min-w-0"><p className="font-mono text-xs font-semibold">{invoice.id} <span className="ml-1 font-sans font-normal text-muted-foreground">· Load {invoice.loadId}</span></p><p className="mt-1 truncate text-sm">Container {invoice.container}</p><p className="mt-1 text-[11px] text-muted-foreground">Issued {invoice.issued} · Due {invoice.due} · Delivery {deliveryDate}</p><p className="mt-1 text-[11px]">{invoice.status === 'Paid' ? 'Paid' : 'Open'} · {formatUsd(invoice.amount)}</p></div>
                        <div className="flex flex-wrap gap-2">
                          <button type="button" disabled={invoice.approvalStatus === 'Needs Review'} title={invoice.approvalStatus === 'Needs Review' ? 'Dispatcher approval is required before exporting this invoice.' : undefined} onClick={() => downloadInvoiceArchivePdf(invoice, load)} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-2.5 text-[11px] font-medium hover:bg-muted disabled:cursor-not-allowed disabled:opacity-45"><FileDown className="size-3.5" aria-hidden />Download invoice PDF</button>
                          <button type="button" disabled={!hasPod || !load?.podReceipt || !load.podSignedAtIso} onClick={() => { if (load?.podReceipt && load.podSignedAtIso) downloadDeliveryDocuments(load, load.podReceipt, new Date(load.podSignedAtIso)) }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-2.5 text-[11px] font-medium hover:bg-muted disabled:cursor-not-allowed disabled:opacity-45"><FileDown className="size-3.5" aria-hidden />{hasPod ? 'Download POD & EIR' : 'POD not on file'}</button>
                          <button type="button" onClick={() => { setHistoryCustomer(null); openFormForInvoice(invoice) }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-primary/30 px-2.5 text-[11px] font-medium text-primary hover:bg-primary/5">Open invoice form</button>
                        </div>
                      </li>
                    )
                  })}
                </ul>
              )}
              <p className="mt-4 rounded-md bg-muted/50 p-3 text-[11px] leading-5 text-muted-foreground">Session preview only: totals and archive entries are based on the in-memory ledger and are not saved across reloads or shared between devices. PDF downloads are archive summaries; itemized charge history is not stored in this preview.</p>
            </div>
          </section>
        </div>
      )}
      {podPreviewLoad?.podReceipt && podPreviewLoad.podSignedAtIso && <DeliveryReceiptPreview load={podPreviewLoad} receipt={podPreviewLoad.podReceipt} signedAt={new Date(podPreviewLoad.podSignedAtIso)} onClose={() => setPodPreviewLoadId(null)} />}
      {isInvoiceOpen && formLoad && <PcsInvoiceForm key={formLoad.id} load={formLoad} onClose={() => setIsInvoiceOpen(false)} />}
    </div>
  )
}

function EditableInvoiceCell({ invoice, field, label, className = '' }: { invoice: Invoice; field: Exclude<keyof Invoice, 'amount'>; label: string; className?: string }) {
  const { updateInvoice } = useTms()
  return <EditableCell value={String(invoice[field] ?? '')} label={`${invoice.id} ${label}`} onCommit={(value) => updateInvoice(invoice.id, field, value)} className={className} />
}

function EditableInvoiceAmount({ invoice }: { invoice: Invoice }) {
  const { updateInvoice } = useTms()
  return <EditableAmount value={invoice.amount} label={`${invoice.id} amount`} onCommit={(value) => updateInvoice(invoice.id, 'amount', String(value))} />
}

function matchesInvoiceSearch(invoice: Invoice, load: Load | undefined, query: string) {
  const normalized = query.trim().toLowerCase()
  if (!normalized) return true
  return [invoice.customer, invoice.container, invoice.id, invoice.loadId, invoice.issued, invoice.due]
    .some((value) => value.toLowerCase().includes(normalized)) || Boolean(load && matchesLoadSearch(load, normalized))
}

function matchesLoadSearch(load: Load, query: string) {
  const normalized = query.trim().toLowerCase()
  if (!normalized) return true
  const refs = loadReferences(load)
  const deliveryDate = load.podSignedAtIso ? new Date(load.podSignedAtIso).toLocaleDateString('en-US') : ''
  return [load.customer, load.container, load.id, refs.billOfLading, refs.deliveryOrder, refs.poNumber, deliveryDate, load.podSignedAtIso ?? '', load.podSignedAt ?? '']
    .some((value) => value.toLowerCase().includes(normalized))
}

function HistoryMetric({ label, value }: { label: string; value: string }) {
  return <div className="bg-card p-3"><dt className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</dt><dd className="mt-1 font-mono text-sm font-semibold">{value}</dd></div>
}

function approvalBadgeLabel(invoice: Invoice) {
  if (invoice.status === 'Paid') return 'Settled & Reconciled'
  return invoice.approvalStatus === 'Needs Review' ? '⚠️ Needs Dispatcher Review & Approval' : 'Approved & Locked for Release'
}

function toIsoDate(value: string) {
  const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(value)
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`
  const local = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/.exec(value)
  if (!local) return ''
  const year = local[3].length === 2 ? `20${local[3]}` : local[3]
  return `${year}-${local[1].padStart(2, '0')}-${local[2].padStart(2, '0')}`
}

function Metric({ label, value, emphasize }: { label: string; value: string; emphasize?: boolean }) {
  return (
    <div className="bg-card px-4 py-2.5">
      <dt className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</dt>
      <dd className={cn('font-mono text-base font-semibold tabular-nums', emphasize && 'text-foreground underline decoration-accent decoration-2 underline-offset-4')}>{value}</dd>
    </div>
  )
}
