'use client'

import { useState } from 'react'
import { Download, FileSpreadsheet, FileText, Printer } from 'lucide-react'
import { cn } from '@/lib/utils'
import { downloadCsvReport, downloadExcelReport, downloadPdfReport, type ReportValue } from '@/lib/report-exports'

export function ReportExportToolbar({
  title = 'Reports & Export',
  fileName,
  sheetName,
  reportTitle,
  headers,
  rows,
  excelLabel = 'Export to Excel (.xlsx)',
  className,
}: {
  title?: string
  fileName: string
  sheetName: string
  reportTitle: string
  headers: string[]
  rows: ReportValue[][]
  excelLabel?: string
  className?: string
}) {
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)

  const run = async (exporter: () => void | Promise<void>, success: string) => {
    setBusy(true)
    setMessage('')
    try {
      await exporter()
      setMessage(success)
    } catch {
      setMessage('Export could not be created. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <section aria-label={title} className={cn('flex flex-wrap items-center justify-between gap-3 rounded-md border border-border bg-card px-3 py-2', className)}>
      <div className="flex min-w-0 items-center gap-2">
        <FileSpreadsheet className="size-4 shrink-0 text-primary" aria-hidden />
        <div className="min-w-0">
          <h2 className="truncate text-xs font-semibold">{title}</h2>
          <p aria-live="polite" className="truncate text-[10px] text-muted-foreground">{message || `${rows.length.toLocaleString()} report rows · downloadable locally`}</p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        <button type="button" disabled={busy} onClick={() => void run(() => downloadExcelReport(fileName, sheetName, headers, rows), 'Excel workbook downloaded.')} className="inline-flex min-h-8 items-center gap-1.5 rounded-md bg-primary px-2.5 text-[11px] font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <Download className="size-3.5" aria-hidden />{excelLabel}
        </button>
        <button type="button" disabled={busy} onClick={() => void run(() => downloadCsvReport(fileName, headers, rows), 'CSV file downloaded.')} className="inline-flex min-h-8 items-center gap-1.5 rounded-md border border-border bg-background px-2.5 text-[11px] font-medium hover:bg-muted disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <FileText className="size-3.5" aria-hidden />Export to CSV
        </button>
        <button type="button" disabled={busy} onClick={() => void run(() => downloadPdfReport(reportTitle, fileName, headers, rows), 'PDF summary downloaded.')} className="inline-flex min-h-8 items-center gap-1.5 rounded-md border border-border bg-background px-2.5 text-[11px] font-medium hover:bg-muted disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <Printer className="size-3.5" aria-hidden />Print / Download PDF Summary
        </button>
      </div>
    </section>
  )
}

