'use client'

import { useState, type FormEvent } from 'react'
import { AlertTriangle, KeyRound, LockKeyhole, Pencil, Plus, ShieldCheck, Users, X } from 'lucide-react'
import { PageHeader } from './page-header'

type TeamRole = 'Admin / Owner' | 'Dispatcher' | 'Billing / Accounting' | 'Driver'
type Member = { id: number; name: string; email: string; role: TeamRole; status: 'Active' | 'Invited' }

const roles: TeamRole[] = ['Admin / Owner', 'Dispatcher', 'Billing / Accounting', 'Driver']
const permissionRows = [
  { permission: 'Dispatch and load management', values: ['Full access', 'Manage and assign', 'View only', 'Assigned runs'] },
  { permission: 'Edit container, LFD, DO and PO', values: ['Yes', 'Yes', 'No', 'No'] },
  { permission: 'Accounts receivable and payments', values: ['Full access', 'No', 'Manage', 'No'] },
  { permission: 'Rate adjustments and chart of accounts', values: ['Yes', 'No', 'Rate adjustments', 'No'] },
  { permission: 'QuickBooks sync', values: ['Yes', 'No', 'Yes', 'No'] },
  { permission: 'Delete loads or billing history', values: ['Yes', 'No', 'No', 'No'] },
  { permission: 'Invite and manage team', values: ['Yes', 'No', 'No', 'No'] },
  { permission: 'Driver Mobile, POD and gate photos', values: ['All runs', 'All runs', 'No', 'Assigned only'] },
]

const initialMembers: Member[] = [
  { id: 1, name: 'G - Owner', email: 'owner@ephrata-tms.demo', role: 'Admin / Owner', status: 'Active' },
  { id: 2, name: 'Jemal A.', email: 'jemal@ephrata-tms.demo', role: 'Driver', status: 'Active' },
  { id: 3, name: 'Billing Clerk', email: 'billing@ephrata-tms.demo', role: 'Billing / Accounting', status: 'Active' },
]

export function SettingsView() {
  const [members, setMembers] = useState(initialMembers)
  const [modal, setModal] = useState<'password' | 'add' | 'edit' | null>(null)
  const [selectedMember, setSelectedMember] = useState<Member | null>(null)
  const [notice, setNotice] = useState('')

  const openEdit = (member: Member) => {
    setSelectedMember(member)
    setModal('edit')
  }

  const inviteMember = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const name = String(formData.get('name') ?? '').trim()
    const email = String(formData.get('email') ?? '').trim()
    const role = String(formData.get('role') ?? 'Driver') as TeamRole
    if (!name || !email) return
    setMembers((current) => [...current, { id: Date.now(), name, email, role, status: 'Invited' }])
    setModal(null)
    setNotice('Invite added to this demo session only. No email was sent.')
  }

  const saveRole = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!selectedMember) return
    const role = new FormData(event.currentTarget).get('role') as TeamRole
    setMembers((current) => current.map((member) => member.id === selectedMember.id ? { ...member, role } : member))
    setModal(null)
    setNotice('Role change is shown in this demo session only. It does not enforce access controls.')
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <PageHeader title="Settings" subtitle="Team access and account security · Ephrata TMS" />
      <div className="min-h-0 flex-1 overflow-y-auto p-4 pb-32 sm:p-6 sm:pb-32">
        <div className="mx-auto max-w-6xl space-y-6">
          <div className="flex items-start gap-3 rounded-xl border border-amber-300/70 bg-amber-50 px-4 py-3 text-amber-950 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-100">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
            <p className="text-sm"><span className="font-semibold">Demo mode.</span> Team roster and role edits are temporary UI state. Authentication, password changes, invitations, and server-enforced permissions are not connected.</p>
          </div>

          {notice && <div role="status" className="flex items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-sm"><span>{notice}</span><button type="button" onClick={() => setNotice('')} aria-label="Dismiss message" className="text-muted-foreground hover:text-foreground"><X className="size-4" aria-hidden /></button></div>}

          <section className="rounded-xl border border-border bg-card shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border px-5 py-4">
              <div className="flex items-center gap-3"><span className="flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><Users className="size-5" aria-hidden /></span><div><h2 className="font-semibold">Team management</h2><p className="mt-0.5 text-sm text-muted-foreground">People shown here are sample users for the demo.</p></div></div>
              <button type="button" onClick={() => setModal('add')} className="inline-flex h-9 items-center gap-2 rounded-lg bg-primary px-3.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"><Plus className="size-4" aria-hidden /> Invite / Add Team Member</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[680px] text-left text-sm">
                <thead><tr className="bg-muted/50 text-xs uppercase tracking-wide text-muted-foreground"><th className="px-5 py-3 font-medium">Team member</th><th className="px-5 py-3 font-medium">Role</th><th className="px-5 py-3 font-medium">Status</th><th className="px-5 py-3 text-right font-medium">Action</th></tr></thead>
                <tbody className="divide-y divide-border">
                  {members.map((member) => <tr key={member.id}>
                    <td className="px-5 py-4"><p className="font-medium">{member.name}</p><p className="mt-0.5 text-xs text-muted-foreground">{member.email}</p></td>
                    <td className="px-5 py-4"><span className="rounded-full border border-border bg-muted/60 px-2.5 py-1 text-xs font-medium">{member.role}</span></td>
                    <td className="px-5 py-4"><span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${member.status === 'Active' ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'bg-amber-500/10 text-amber-800 dark:text-amber-200'}`}><span className="size-1.5 rounded-full bg-current" />{member.status}</span></td>
                    <td className="px-5 py-4 text-right"><button type="button" onClick={() => openEdit(member)} className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs font-medium hover:bg-muted"><Pencil className="size-3" aria-hidden /> Edit permissions</button></td>
                  </tr>)}
                </tbody>
              </table>
            </div>
          </section>

          <section className="rounded-xl border border-border bg-card shadow-sm">
            <div className="flex items-center gap-3 border-b border-border px-5 py-4"><span className="flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><ShieldCheck className="size-5" aria-hidden /></span><div><h2 className="font-semibold">Role permissions</h2><p className="mt-0.5 text-sm text-muted-foreground">Reference matrix only; permissions are not enforced in this demo.</p></div></div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[780px] text-left text-xs">
                <thead><tr className="bg-muted/50 text-muted-foreground"><th className="w-[24%] px-4 py-3 font-semibold">Permission</th>{roles.map((role) => <th key={role} className="px-3 py-3 font-semibold">{role}</th>)}</tr></thead>
                <tbody className="divide-y divide-border">{permissionRows.map((row) => <tr key={row.permission}><th scope="row" className="px-4 py-3 font-medium">{row.permission}</th>{row.values.map((value, index) => <td key={index} className="px-3 py-3 text-muted-foreground">{value}</td>)}</tr>)}</tbody>
              </table>
            </div>
          </section>

          <section className="flex flex-wrap items-center justify-start gap-4 rounded-xl border border-border bg-card p-5 shadow-sm">
            <div className="flex items-center gap-3"><span className="flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><LockKeyhole className="size-5" aria-hidden /></span><div><h2 className="font-semibold">User profile &amp; security</h2><p className="mt-0.5 text-sm text-muted-foreground">Change the password for your sign-in account.</p></div></div>
            <button type="button" onClick={() => setModal('password')} className="inline-flex h-9 items-center gap-2 rounded-lg border border-border px-3.5 text-sm font-semibold hover:bg-muted"><KeyRound className="size-4" aria-hidden /> Change Password</button>
          </section>
        </div>
      </div>

      {modal === 'add' && <Modal title="Invite team member" onClose={() => setModal(null)}><form onSubmit={inviteMember} className="space-y-4"><TextField label="Name" name="name" autoComplete="name" required /><TextField label="Email" name="email" type="email" autoComplete="email" required /><RoleSelect /><p className="rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">Demo only: this adds a temporary roster row. No invitation email or account is created.</p><ModalActions onCancel={() => setModal(null)} submitLabel="Add team member" /></form></Modal>}

      {modal === 'edit' && selectedMember && <Modal title={`Edit permissions · ${selectedMember.name}`} onClose={() => setModal(null)}><form onSubmit={saveRole} className="space-y-4"><RoleSelect defaultValue={selectedMember.role} /><p className="rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">Changing a role here updates only this page session. It does not restrict access to app features.</p><ModalActions onCancel={() => setModal(null)} submitLabel="Save role" /></form></Modal>}

      {modal === 'password' && <Modal title="Change password" onClose={() => setModal(null)}><PasswordForm onClose={() => setModal(null)} onResult={setNotice} /></Modal>}
    </div>
  )
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}><section role="dialog" aria-modal="true" aria-label={title} className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"><div className="mb-5 flex items-center justify-between gap-4"><h2 className="text-lg font-semibold">{title}</h2><button type="button" onClick={onClose} aria-label="Close dialog" className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"><X className="size-4" aria-hidden /></button></div>{children}</section></div>
}

function TextField({ label, name, type = 'text', autoComplete, required }: { label: string; name: string; type?: string; autoComplete?: string; required?: boolean }) {
  return <label className="block"><span className="mb-1.5 block text-sm font-medium">{label}</span><input name={name} type={type} autoComplete={autoComplete} required={required} className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
}

function RoleSelect({ defaultValue = 'Driver' }: { defaultValue?: TeamRole }) {
  return <label className="block"><span className="mb-1.5 block text-sm font-medium">Role</span><select name="role" defaultValue={defaultValue} className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring">{roles.map((role) => <option key={role}>{role}</option>)}</select></label>
}

function ModalActions({ onCancel, submitLabel }: { onCancel: () => void; submitLabel: string }) {
  return <div className="flex justify-end gap-2 pt-1"><button type="button" onClick={onCancel} className="h-9 rounded-lg border border-border px-3 text-sm font-medium hover:bg-muted">Cancel</button><button type="submit" className="h-9 rounded-lg bg-primary px-3.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90">{submitLabel}</button></div>
}

function PasswordForm({ onClose, onResult }: { onClose: () => void; onResult: (message: string) => void }) {
  const submitPassword = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const values = new FormData(event.currentTarget)
    const nextPassword = String(values.get('newPassword') ?? '')
    const confirmPassword = String(values.get('confirmPassword') ?? '')
    if (nextPassword.length < 12) {
      onResult('Choose a new password with at least 12 characters.')
      return
    }
    if (nextPassword !== confirmPassword) {
      onResult('The new password and confirmation do not match.')
      return
    }
    onClose()
    onResult('Password changes are unavailable because authentication is not connected. No password was changed.')
  }

  return <form onSubmit={submitPassword} className="space-y-4"><TextField label="Current password" name="currentPassword" type="password" autoComplete="current-password" required /><TextField label="New password" name="newPassword" type="password" autoComplete="new-password" required /><TextField label="Confirm new password" name="confirmPassword" type="password" autoComplete="new-password" required /><p className="rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">Use at least 12 characters. This demo cannot verify your current password or update an account.</p><ModalActions onCancel={onClose} submitLabel="Update Password" /></form>
}
