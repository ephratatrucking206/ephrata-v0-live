'use client'

import { useEffect, useMemo, useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { CalendarClock, Check, Download, Mail, PencilLine, Printer, Share2, Truck, X } from 'lucide-react'
import { calculateDaysPastLfd, DEMURRAGE_RATE_BY_TERMINAL, formatLfdCutoff, formatUsd, loadReferences, TERMINALS, type Load } from '@/lib/tms-data'
import { downloadExcelReport } from '@/lib/report-exports'
import { createDeliveryDocumentAttachments, createOfficialInvoicePdf } from '@/lib/delivery-documents'
import { useTms } from './tms-store'
import { EditableAmount, EditableText } from './editable-cell'

interface InvoiceLine {
  item: string
  account: string
  amount: number
  quantity: number
  rate: number
  ourRef: string
  theirRef: string
  memo: string
}

const initialLines = (load: Load, demurrageDays: number, demurrageRate: number): InvoiceLine[] => {
  const chassisCharge = load.charges.find((charge) => charge.label.toLowerCase().includes('chassis'))
  const chassisDays = chassisCharge
    ? Number(chassisCharge.label.match(/(\d+)\s*days?/i)?.[1] ?? 2)
    : 0
  const congestionCharge = load.charges.find((charge) => charge.label.toLowerCase().includes('congestion'))
  const congestionHours = congestionCharge ? Math.round((congestionCharge.amount / 75) * 100) / 100 : 0
  const prePull = load.charges.some((charge) => /pre.?pull/i.test(charge.label) && charge.amount > 0)
  const storageCharge = load.charges.find((charge) => /storage/i.test(charge.label))
  const storageDays = storageCharge ? Number(storageCharge.label.match(/(\d+)\s*days?/i)?.[1] ?? storageCharge.amount / 45) : 0
  const detentionCharge = load.charges.find((charge) => /detention|standby/i.test(charge.label))
  const detentionHours = detentionCharge ? detentionCharge.amount / 75 : 0
  const refs = loadReferences(load)
  const refLine = `B/L: ${refs.billOfLading} | DO: ${refs.deliveryOrder} | PO: ${refs.poNumber}`
  const line = (item: string, account: string, amount: number, quantity: number, rate: number, memo: string, theirRef = refLine): InvoiceLine => ({
    item, account, amount, quantity, rate, ourRef: load.id, theirRef, memo,
  })
  const lines: InvoiceLine[] = [
    line(`Linehaul drayage · ${load.terminal} to ${load.destination}`, '3000', 875, 1, 875, `Port drayage · linehaul | ${refLine}`),
    line('Fuel surcharge (33% of linehaul)', '3010', 288.75, 1, 288.75, `33% fuel surcharge | ${refLine}`),
    line('Chassis usage · days', '3010', chassisDays * 39, chassisDays, 39, `Chassis usage at $39/day | ${refLine}`),
    line('Detention · billable hours after 2 free hours', '3010', detentionHours * 75, detentionHours, 75, `Detention after 2 free hours | ${refLine}`),
    line('Port / rail congestion · billable hours after 2 free hours', '3010', congestionHours * 75, congestionHours, 75, `Congestion after 2 free hours | ${refLine}`),
    line('Tacoma yard pre-pull', '3010', prePull ? 125 : 0, prePull ? 1 : 0, 125, `Tacoma yard pre-pull flat rate | ${refLine}`),
    line('Tacoma yard storage · days', '3010', storageDays * 45, storageDays, 45, `Tacoma yard storage at $45/day | ${refLine}`),
  ]
  if (demurrageDays > 0) {
    lines.push(line(`Port demurrage · ${demurrageDays} days past free time`, '3010', demurrageDays * demurrageRate, demurrageDays, demurrageRate, `Last Free Day (LFD) ${load.lfd} · ${demurrageDays} days past free time · ${refLine}`, `LFD ${load.lfd} · ${demurrageDays} days · ${refLine}`))
  }
  return lines
}

export function PcsInvoiceForm({ load, onClose }: { load: Load; onClose: () => void }) {
  const { invoices, saveInvoiceDraft, approveInvoice } = useTms()
  const invoice = invoices.find((item) => item.loadId === load.id)
  const refs = loadReferences(load)
  const gateOutDate = load.podSignedAtIso ? new Date(load.podSignedAtIso) : new Date()
  const demurrageDays = calculateDaysPastLfd(load.lfd, gateOutDate)
  const lfdCutoff = formatLfdCutoff(load.lfd, gateOutDate)
  const dailyRate = DEMURRAGE_RATE_BY_TERMINAL[load.terminal]
  const [lines, setLines] = useState(() => invoice?.lineItems ?? (invoice && invoice.approvalStatus !== 'Needs Review' ? [{
    item: 'Previously approved freight and accessorial charges',
    account: '3000',
    amount: invoice.amount,
    quantity: 1,
    rate: invoice.amount,
    ourRef: load.id,
    theirRef: `B/L: ${refs.billOfLading}`,
    memo: 'Original itemization was not stored for this archived invoice.',
  }] : initialLines(load, demurrageDays, dailyRate)))
  const [billTo, setBillTo] = useState(invoice?.customer ?? load.customer)
  const [billToAttention, setBillToAttention] = useState(invoice?.attention ?? 'Accounts Payable')
  const [billToAddress, setBillToAddress] = useState(invoice?.billingAddress ?? 'Billing address not on file')
  const [billToPhone, setBillToPhone] = useState(invoice?.phone ?? 'Not on file')
  const [billToEmail, setBillToEmail] = useState(invoice?.email ?? load.billingEmail ?? 'Not on file')
  const [saved, setSaved] = useState(false)
  const [invoiceDate, setInvoiceDate] = useState(() => toDateInput(invoice?.issued ?? new Date()))
  const [terms, setTerms] = useState(invoice?.terms ?? 'Net 30')
  const [showPodEvidence, setShowPodEvidence] = useState(false)
  const [isAdjusting, setIsAdjusting] = useState(false)
  const [demurrageRate, setDemurrageRate] = useState(dailyRate)
  const [dispatcherName, setDispatcherName] = useState(invoice?.approvedBy ?? 'A. Moreno')
  const [exportBusy, setExportBusy] = useState(false)
  const [exportMessage, setExportMessage] = useState('')
  const [shareMessage, setShareMessage] = useState('')
  const total = useMemo(() => lines.reduce((sum, line) => sum + line.amount, 0), [lines])
  const dueDate = useMemo(() => calculateDueDate(invoiceDate, terms), [invoiceDate, terms])
  const draftDetails = { lineItems: lines, issued: invoiceDate, due: displayDate(dueDate), terms, attention: billToAttention, billingAddress: billToAddress, phone: billToPhone, email: billToEmail }
  const nextInvoiceNumber = Math.max(4471, ...invoices.map((record) => Number(record.id.match(/(\d+)$/)?.[1] ?? 0))) + 1
  const invoiceNumber = invoice?.id ?? `AAA-${String(new Date().getFullYear()).slice(-2)}-${nextInvoiceNumber}`
  const subtotal = total
  const pickupTerminal = `Port of ${TERMINALS.find((terminal) => terminal.code === load.terminal)?.port ?? 'Tacoma'} · ${load.terminal}`
  const deliveryWindow = load.podReceipt ? `${load.podReceipt.timeIn} – ${load.podReceipt.timeOut}` : 'Not recorded'
  const stagedAtYard = load.charges.some((charge) => /pre.?pull/i.test(charge.label) && charge.amount > 0)
  const paymentRequest = `mailto:seattletruck@gmail.com?subject=${encodeURIComponent(`Payment instructions and invoice verification · ${invoiceNumber}`)}&body=${encodeURIComponent(`Please provide secure payment instructions and verify invoice ${invoiceNumber} for ${billTo}. Amount due: ${formatUsd(total)}.`)}`

  const updateDemurrageRate = (value: string) => {
    const nextRate = Number(value)
    if (!Number.isFinite(nextRate) || nextRate < 0) return
    setDemurrageRate(nextRate)
    setLines((current) => current.map((line) => line.item.toLowerCase().startsWith('port demurrage')
      ? { ...line, rate: nextRate, quantity: demurrageDays, amount: demurrageDays * nextRate }
      : line,
    ))
    setSaved(false)
  }

  const handleSaveDraft = () => {
    if (invoiceLocked) return
    saveInvoiceDraft({ ...load, customer: billTo, container: load.container }, total, draftDetails)
    setSaved(true)
  }

  const handleApprove = () => {
    if (invoiceLocked || invoice?.status === 'Paid') return
    saveInvoiceDraft({ ...load, customer: billTo, container: load.container }, total, draftDetails)
    approveInvoice({ ...load, customer: billTo, container: load.container }, total, dispatcherName, draftDetails)
    setSaved(true)
  }

  const approvalStatus = invoice?.approvalStatus ?? 'Needs Review'
  const invoiceLocked = Boolean(invoice && approvalStatus !== 'Needs Review')
  const approvalBadgeText = approvalStatus === 'Needs Review'
    ? '⚠️ Needs Dispatcher Review & Approval'
    : approvalStatus === 'Billed / Sent'
      ? 'Approved & Released'
      : 'Approved & Locked for Release'
  const approvalStamp = invoice?.approvedAt
    ? `${invoice.approvedBy ?? 'Dispatcher'} · ${new Date(invoice.approvedAt).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}`
    : 'Awaiting dispatcher review'

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => event.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [onClose])

  const updateLine = (index: number, field: keyof InvoiceLine, value: string | number) => {
    if (invoiceLocked) return
    setLines((current) => current.map((line, lineIndex) => {
      if (lineIndex !== index) return line
      if (field === 'quantity') {
        const quantity = Number(value) || 0
        return { ...line, quantity, amount: quantity * line.rate }
      }
      if (field === 'rate') {
        const rate = Number(value) || 0
        return { ...line, rate, amount: line.quantity * rate }
      }
      if (field === 'amount') {
        const amount = Number(value) || 0
        return { ...line, amount, rate: line.quantity > 0 ? amount / line.quantity : amount }
      }
      return { ...line, [field]: value }
    }))
    setSaved(false)
  }

  const addAccessorialLine = () => {
    if (invoiceLocked) return
    setLines((current) => [...current, {
      item: 'Custom accessorial', account: '3010', amount: 0, quantity: 1, rate: 0,
      ourRef: load.id, theirRef: `B/L: ${refs.billOfLading}`, memo: 'Dispatcher-entered accessorial',
    }])
    setSaved(false)
  }

  const exportInvoice = async () => {
    if (!invoiceLocked) return
    setExportBusy(true)
    setExportMessage('')
    try {
      const headers = ['Invoice #', 'Invoice Date', 'Due Date', 'Terms', 'Bill To', 'Load #', 'BOL #', 'PO #', 'DO #', 'Container #', 'Description', 'Quantity / Days', 'Rate', 'Account', 'Amount']
      const billRows = lines.filter((line) => line.amount !== 0).map((line) => [invoiceNumber, displayDate(invoiceDate), displayDate(dueDate), terms, billTo, load.id, refs.billOfLading, refs.poNumber, refs.deliveryOrder, load.container, line.item, line.quantity, line.rate, line.account, line.amount])
      await downloadExcelReport(`ephrata-invoice-${invoiceNumber}`, 'Invoice', headers, billRows)
      setExportMessage('Invoice workbook downloaded.')
    } catch {
      setExportMessage('Excel export failed. Please try again.')
    } finally {
      setExportBusy(false)
    }
  }

  const shareInvoicePdf = async () => {
    if (!invoiceLocked) return
    setShareMessage('')
    const pdf = createOfficialInvoicePdf({
      invoiceNumber,
      invoiceDate: displayDate(invoiceDate),
      dueDate: displayDate(dueDate),
      terms,
      customer: billTo,
      attention: billToAttention,
      billingAddress: billToAddress,
      phone: billToPhone,
      email: billToEmail,
      amount: total,
      load,
      lines: lines.map(({ item, account, quantity, rate, amount, memo }) => ({ item, account, quantity, rate, amount, memo })),
    })
    const attachments = load.podSigned && load.podReceipt && load.podSignedAtIso
      ? createDeliveryDocumentAttachments(load, load.podReceipt, new Date(load.podSignedAtIso))
      : []
    const files = [
      new File([pdf.blob], pdf.filename, { type: 'application/pdf' }),
      ...attachments.map(({ filename, bytes }) => new File([bytes], filename, { type: 'application/pdf' })),
    ]
    const amountText = total.toLocaleString('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 })
    const podSummary = attachments.length > 0 ? ' along with signed e-POD.' : '.'
    const summary = `Attached please find official Ephrata Trucking Invoice ${invoiceNumber} (${amountText} due ${displayDate(dueDate)})${podSummary}`

    if (typeof navigator.share === 'function' && typeof navigator.canShare === 'function' && navigator.canShare({ files })) {
      try {
        await navigator.share({ title: `Ephrata Trucking Invoice ${invoiceNumber}`, text: summary, files })
        setShareMessage('The invoice PDF and available signed delivery documents were shared.')
        return
      } catch (error) {
        if (error instanceof DOMException && error.name === 'AbortError') return
      }
    }

    for (const file of files) downloadFile(file.name, file)
    setShareMessage('PDF package downloaded. Attach the downloaded files in your email or messaging app.')
  }

  return (
    <div className="invoice-print-overlay fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/65 p-2 backdrop-blur-sm" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section role="dialog" aria-modal="true" aria-labelledby="pcs-invoice-title" className="invoice-print-sheet my-auto w-full max-w-6xl overflow-hidden rounded-md border border-slate-300 bg-white text-slate-900 shadow-2xl">
        <header className="relative z-30 flex flex-wrap items-center justify-between gap-3 bg-slate-800 px-4 py-3 text-white">
          <div className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded bg-white/10"><Truck className="size-5" aria-hidden /></span>
            <div><span id="pcs-invoice-title" className="block text-lg font-bold tracking-wide">Trucking INVOICE</span><span className="font-mono text-[10px] text-slate-300">CUSTOMER INVOICE · PCS FORM #750056</span></div>
          </div>
          <div className="invoice-no-print flex flex-wrap items-center gap-2">
            <button type="button" disabled={!invoiceLocked} title={!invoiceLocked ? 'Dispatcher approval is required before printing or exporting this invoice.' : undefined} onClick={() => window.print()} className="inline-flex h-8 items-center gap-1.5 rounded border border-white/25 px-2.5 text-xs font-semibold hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"><Printer className="size-3.5" aria-hidden />Print / Download PDF</button>
            <details className="relative z-40">
              <summary className="inline-flex h-8 cursor-pointer list-none items-center gap-1.5 rounded border border-white/25 px-2.5 text-xs font-semibold hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"><Share2 className="size-3.5" aria-hidden />Share / Dispatch Invoice</summary>
              <div className="absolute right-0 top-10 z-20 grid min-w-56 gap-1 rounded-md border border-slate-200 bg-white p-1.5 text-slate-800 shadow-xl">
                <button type="button" disabled={!invoiceLocked} onClick={() => void shareInvoicePdf()} className="rounded px-2.5 py-2 text-left text-xs hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-45">✉ Email PDF</button>
                <button type="button" disabled={!invoiceLocked} onClick={() => void shareInvoicePdf()} className="rounded px-2.5 py-2 text-left text-xs hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-45">💬 WhatsApp PDF</button>
                <button type="button" disabled={!invoiceLocked} onClick={() => void shareInvoicePdf()} className="rounded px-2.5 py-2 text-left text-xs hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-45">✈ Telegram PDF</button>
                <button type="button" disabled={!invoiceLocked} onClick={() => void shareInvoicePdf()} className="rounded px-2.5 py-2 text-left text-xs hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-45">📋 Share PDF / Download</button>
                <p className="border-t border-slate-100 px-2.5 py-2 text-[10px] leading-4 text-slate-500">Shares the actual PDF through your browser&apos;s file share sheet or downloads it for attachment. A permanent secure link requires a hosted customer portal.</p>
              </div>
            </details>
            <button type="button" aria-label="Export this invoice to Excel (.xlsx)" disabled={exportBusy || !invoiceLocked} onClick={() => void exportInvoice()} className="inline-flex h-8 items-center gap-1.5 rounded bg-white px-2.5 text-xs font-semibold text-slate-800 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-45"><Download className="size-3.5" aria-hidden />Export to Excel (.xlsx)</button>
            <button type="button" aria-label="Close invoice form" onClick={onClose} className="rounded p-1.5 hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"><X className="size-4" aria-hidden /></button>
          </div>
        </header>
        <section aria-label="Dispatcher review and approval status" className="invoice-no-print grid gap-2 border-b border-slate-200 bg-slate-50 px-4 py-2 sm:grid-cols-[1fr_auto] sm:items-center">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-bold ${invoice?.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' : approvalStatus === 'Needs Review' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-800'}`}>
              {approvalStatus === 'Needs Review' ? <CalendarClock className="size-3" aria-hidden /> : <Check className="size-3" aria-hidden />}
              {approvalBadgeText}
            </span>
            <span className="text-[10px] text-slate-600">{approvalStamp}</span>
          </div>
          <p className="text-[10px] font-medium text-slate-600">{invoiceLocked ? 'Approved and locked · queued for dispatcher-controlled Friday release' : 'Draft / Under Review · excluded from billing, sharing, and exports'}</p>
        </section>

        <div className="invoice-scroll-area max-h-[calc(100dvh-150px)] overflow-auto p-4 sm:p-6">
          <div className="grid gap-5 border-b border-slate-200 pb-4 md:grid-cols-[1fr_auto]">
            <section aria-label="Carrier information">
              <p className="text-lg font-extrabold tracking-tight text-slate-900">EPHRATA TRUCKING, LLC <span className="font-medium text-slate-500">(dba AAA Intermodal)</span></p>
              <p className="mt-1 text-xs leading-5 text-slate-600">10105 SE 212th St, Kent, WA 98031<br />Office: (206) 866-4720 <span className="px-1 text-slate-300">|</span> Dispatch: (206) 372-8570<br />Email: seattletruck@gmail.com<br />USDOT: 1839352 <span className="px-1 text-slate-300">|</span> MC: 669162</p>
            </section>
            <section aria-label="Invoice details" className="grid min-w-[250px] grid-cols-2 gap-2 self-start text-xs">
              <InvoiceDatum label="Invoice #" value={invoiceNumber} prominent />
              <InvoiceDatum label="Terms" value={terms} />
              <label className="grid gap-1 rounded border border-slate-200 bg-slate-50 p-2 text-[10px] font-semibold text-slate-500">Invoice date<input aria-label="Invoice date" type="date" disabled={invoiceLocked} value={invoiceDate} onChange={(event) => { setInvoiceDate(event.target.value); setSaved(false) }} className="w-full bg-transparent font-mono text-xs text-slate-900 outline-none disabled:opacity-70" /></label>
              <InvoiceDatum label="Due date" value={displayDate(dueDate)} />
              <label className="col-span-2 grid gap-1 rounded border border-slate-200 bg-slate-50 p-2 text-[10px] font-semibold text-slate-500">Payment terms<select aria-label="Payment terms" disabled={invoiceLocked} value={terms} onChange={(event) => { setTerms(event.target.value); setSaved(false) }} className="bg-transparent text-xs text-slate-900 outline-none disabled:opacity-70"><option>Net 30</option><option>Net 15</option></select></label>
              <div className="col-span-2 flex items-center gap-3 rounded border border-sky-200 bg-sky-50 p-2">
                <QRCodeSVG value={paymentRequest} size={76} level="M" bgColor="#ffffff" fgColor="#0f172a" title={`Scan to request payment instructions for invoice ${invoiceNumber}`} />
                <div className="min-w-0"><p className="text-[10px] font-bold uppercase tracking-wide text-sky-900">Scan to Pay / Verify</p><p className="mt-1 text-[10px] leading-4 text-slate-600">Opens accounting to request secure payment instructions for this invoice. A direct payment portal is not connected.</p></div>
              </div>
            </section>
          </div>

          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <section aria-labelledby="bill-to-heading" className="rounded border border-slate-200">
              <h2 id="bill-to-heading" className="border-b border-slate-200 bg-slate-50 px-3 py-2 text-[10px] font-bold tracking-[0.14em] text-slate-600">BILL TO</h2>
              <div className="grid gap-2 p-3 sm:grid-cols-2">
                <InvoiceField label="Customer name" value={billTo} onChange={(value) => { setBillTo(value); setSaved(false) }} disabled={invoiceLocked} className="sm:col-span-2 font-bold" />
                <InvoiceField label="Attn" value={billToAttention} onChange={setBillToAttention} disabled={invoiceLocked} />
                <InvoiceField label="Phone" value={billToPhone} onChange={setBillToPhone} disabled={invoiceLocked} />
                <InvoiceField label="Billing address" value={billToAddress} onChange={setBillToAddress} disabled={invoiceLocked} className="sm:col-span-2" />
                <InvoiceField label="Accounting email" value={billToEmail} onChange={setBillToEmail} disabled={invoiceLocked} className="sm:col-span-2" />
              </div>
            </section>
            <section aria-labelledby="load-info-heading" className="rounded border border-slate-200">
              <h2 id="load-info-heading" className="border-b border-slate-200 bg-slate-50 px-3 py-2 text-[10px] font-bold tracking-[0.14em] text-slate-600">LOAD INFORMATION</h2>
              <div className="grid grid-cols-2 gap-x-4 gap-y-2 p-3 sm:grid-cols-3">
                <InvoiceDatum label="Load #" value={load.id} mono />
                <InvoiceDatum label="BOL #" value={refs.billOfLading} mono />
                <InvoiceDatum label="PO #" value={refs.poNumber} mono />
                <InvoiceDatum label="DO #" value={refs.deliveryOrder} mono />
                <InvoiceDatum label="Container #" value={load.container} mono />
                <InvoiceDatum label="Chassis #" value={load.chassis} mono />
                <InvoiceDatum label="Driver & unit" value={`${load.driver ?? 'Unassigned'} · ${load.truck ?? 'Unit not assigned'}`} className="col-span-2 sm:col-span-3" />
              </div>
            </section>
          </div>

          <section aria-label="Route details" className="mt-4 rounded border border-sky-200 bg-sky-50 p-3">
            <div className="grid items-center gap-3 md:grid-cols-[1fr_auto_1fr]">
              <div><p className="text-[10px] font-bold tracking-[0.14em] text-sky-800">PICKUP</p><p className="mt-1 text-sm font-bold text-slate-900">{pickupTerminal}</p><p className="mt-0.5 text-[11px] text-slate-600">Port gate-out: Not recorded</p></div>
              <span aria-hidden className="hidden text-xl font-semibold text-sky-700 md:block">→</span>
              <div className="md:text-right"><p className="text-[10px] font-bold tracking-[0.14em] text-sky-800">DELIVERY</p><p className="mt-1 text-sm font-bold text-slate-900">{load.destination}</p><p className="mt-0.5 text-[11px] text-slate-600">Facility in / out: {deliveryWindow}</p></div>
            </div>
            <div className="mt-3 grid gap-2 border-t border-sky-200 pt-3 text-[10px] sm:grid-cols-2 lg:grid-cols-4">
              <InvoiceDatum label="Intermediate yard" value={stagedAtYard ? 'Staged at Tacoma Yard' : 'Direct port delivery'} />
              <InvoiceDatum label="Container weight" value={`${load.weightLbs.toLocaleString('en-US')} lbs`} mono />
              <InvoiceDatum label="Seal #" value={`${load.seal} · condition per EIR`} mono />
              <InvoiceDatum label="Free time cutoff / LFD" value={lfdCutoff} mono />
            </div>
          </section>

          <section id="invoice-charges" aria-labelledby="charge-heading" className={`mt-5 overflow-x-auto rounded border border-slate-200 ${isAdjusting ? 'ring-2 ring-amber-300' : ''}`}>
            <h2 id="charge-heading" className="bg-slate-800 px-3 py-2 text-xs font-bold tracking-wide text-white">ITEMIZED FREIGHT &amp; ACCESSORIAL CHARGES</h2>
            <table className="w-full min-w-[620px] border-collapse text-xs">
              <thead className="bg-slate-100 text-left text-[10px] font-bold uppercase tracking-wide text-slate-600"><tr><th scope="col" className="px-3 py-2">Description</th><th scope="col" className="px-2 py-2 text-right">Quantity / Days</th><th scope="col" className="px-2 py-2 text-right">Rate</th><th scope="col" className="px-3 py-2 text-right">Amount</th></tr></thead>
              <tbody>{lines.map((line, index) => (
                <tr key={`${index}-${line.item}`} className="border-t border-slate-100 odd:bg-white even:bg-slate-50">
                  <td className="px-3 py-2"><EditableText label={`Line ${index + 1} description`} value={line.item} onCommit={(value) => updateLine(index, 'item', value)} disabled={invoiceLocked} /><span className="ml-2 font-mono text-[9px] text-slate-400">Acct {line.account}</span></td>
                  <td className="px-2 py-2 text-right"><input aria-label={`${line.item} quantity or days`} type="number" min="0" step="0.01" disabled={invoiceLocked} value={line.quantity} onChange={(event) => updateLine(index, 'quantity', event.target.value)} className="w-20 bg-transparent text-right font-mono outline-none focus-visible:ring-1 focus-visible:ring-sky-600" /></td>
                  <td className="px-2 py-2 text-right"><input aria-label={`${line.item} rate`} type="number" min="0" step="0.01" disabled={invoiceLocked} value={line.rate.toFixed(2)} onChange={(event) => updateLine(index, 'rate', event.target.value)} className="w-24 bg-transparent text-right font-mono outline-none focus-visible:ring-1 focus-visible:ring-sky-600" /></td>
                  <td className="px-3 py-2 text-right font-mono font-semibold"><EditableAmount label={`${line.item} amount`} value={line.amount} onCommit={(value) => updateLine(index, 'amount', value)} disabled={invoiceLocked} /></td>
                </tr>
              ))}</tbody>
            </table>
            <div className="border-t border-slate-200 bg-slate-50 px-3 py-2">
              <button type="button" disabled={invoiceLocked} onClick={addAccessorialLine} className="inline-flex items-center gap-1.5 rounded border border-sky-300 bg-white px-2.5 py-1.5 text-[11px] font-semibold text-sky-800 hover:bg-sky-50 disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-600">+ Add Accessorial Line</button>
            </div>
          </section>

          <div className="mt-4 grid gap-4 md:grid-cols-[1fr_280px]">
            <section aria-label="Payment information" className="rounded border border-slate-200 p-3 text-[11px] leading-5 text-slate-600">
              <p className="font-bold text-slate-800">REMITTANCE &amp; PAYMENT TERMS</p>
              <p>Payment due in {Number(terms.match(/\d+/)?.[0]) || 30} days from invoice date ({displayDate(dueDate)}).</p>
              <p><strong className="text-slate-800">Direct ACH &amp; wire:</strong> Chase Commercial Banking. Request routing and account numbers securely from accounting; they are not displayed in this preview.</p>
              <p><strong className="text-slate-800">Check by mail:</strong> Payable to Ephrata Trucking, LLC, 10105 SE 212th St, Kent, WA 98031.</p>
              <p><strong className="text-slate-800">Remittance:</strong> Remit payments &amp; remittance slips to: seattletruck@gmail.com</p>
              <p><strong className="text-slate-800">Credit card:</strong> Stripe / QuickBooks online link; 3.5% processing fee where permitted. The QR currently opens accounting email to request the payment link.</p>
            </section>
            <section aria-label="Invoice totals" className="grid gap-2 rounded border border-slate-200 bg-slate-50 p-3 text-xs">
              <div className="flex justify-between"><span className="text-slate-600">Subtotal</span><strong className="font-mono">{formatUsd(subtotal)}</strong></div>
              <div className="flex justify-between"><span className="text-slate-600">Tax rate</span><span className="font-mono">0.00%</span></div>
              <div className="flex items-end justify-between border-t border-slate-300 pt-2"><span className="font-bold tracking-wide">TOTAL DUE</span><strong className="font-mono text-xl font-extrabold text-slate-900">{formatUsd(total)}</strong></div>
            </section>
          </div>

          <p className="mt-4 rounded border border-amber-200 bg-amber-50 px-3 py-2 text-[10px] leading-4 text-amber-950">Load delivered on time and in good condition. Signed Equipment Delivery Receipt (e-POD) &amp; EIR gate ticket attached.</p>
          <p className="mt-4 border-t border-slate-200 pt-3 text-center text-base font-bold text-slate-700">Thank you for your business!</p>
          <p aria-live="polite" className="invoice-no-print mt-2 text-center text-[10px] text-slate-500">{exportMessage || shareMessage}</p>
          <div className="invoice-no-print mt-3 border-t border-dashed border-slate-200 pt-3">
            <button type="button" aria-expanded={showPodEvidence} onClick={() => setShowPodEvidence((current) => !current)} className="rounded border border-emerald-300 bg-emerald-50 px-2 py-1.5 text-left text-[10px] font-semibold text-emerald-800 hover:bg-emerald-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-700">
              <Mail className="mr-1 inline size-3" aria-hidden />Delivery receipt &amp; gate ticket evidence · {load.podSigned ? `Signed ${load.podReceipt?.receiverName ?? load.driver ?? 'consignee'} · ${load.podSignedAt ?? ''}` : 'Awaiting signature'}
            </button>
            {showPodEvidence && <div role="status" className="mt-2 grid gap-1 rounded border border-emerald-200 bg-emerald-50 p-2 text-[10px] text-emerald-950 sm:grid-cols-2"><span><b>Receiver:</b> {load.podSigned ? load.podReceipt?.receiverName ?? load.driver ?? 'consignee' : 'Not yet signed'}</span><span><b>Company / Facility:</b> {load.podReceipt?.companyName ?? 'Pending'}</span><span><b>Time in / out:</b> {load.podReceipt?.timeIn ?? 'Pending'} / {load.podReceipt?.timeOut ?? load.podSignedAt ?? 'Pending'}</span><span><b>Signed at:</b> {load.podSignedAtIso ? new Date(load.podSignedAtIso).toLocaleString('en-US') : 'Pending'}</span></div>}
          </div>
        </div>

        <div className="invoice-no-print flex flex-wrap items-center justify-between gap-2 border-t border-slate-300 bg-slate-100 px-4 py-2">
          <span aria-live="polite" className="text-[10px] text-slate-600">{invoiceLocked ? 'Approved invoice details are locked.' : saved ? 'Invoice draft updated in this session.' : 'Dispatcher approval is required before Friday billing batch release.'}</span>
          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-1 text-[10px] font-semibold text-slate-700">Dispatcher
              <input value={dispatcherName} disabled={invoiceLocked} onChange={(event) => setDispatcherName(event.target.value)} aria-label="Dispatcher name for invoice approval" className="h-7 w-28 rounded border border-slate-300 bg-white px-2 font-normal outline-none focus-visible:ring-2 focus-visible:ring-[#1b4d89] disabled:opacity-70" />
            </label>
            <button type="button" disabled={invoiceLocked} onClick={() => { setIsAdjusting(true); document.getElementById('invoice-charges')?.scrollIntoView({ behavior: 'smooth', block: 'center' }) }} className="inline-flex items-center gap-1 rounded border border-[#1b4d89] bg-white px-2.5 py-1.5 text-xs font-semibold text-[#1b4d89] hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><PencilLine className="size-3.5" aria-hidden />Edit / Adjust Charges</button>
            <button type="button" disabled={invoiceLocked} onClick={handleSaveDraft} className="rounded border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">Save invoice draft</button>
            <button type="button" disabled={invoiceLocked || invoice?.status === 'Paid'} onClick={handleApprove} className="inline-flex items-center gap-1 rounded bg-[#1b4d89] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#153a67] disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><Check className="size-3.5" aria-hidden />{invoiceLocked ? '✓ Approved & Locked for Release' : '✓ Approve & Lock Invoice for Release'}</button>
            <button type="button" onClick={onClose} className="rounded border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">Close invoice form</button>
          </div>
        </div>
      </section>
    </div>
  )
}

function InvoiceDatum({ label, value, mono = false, prominent = false, className = '' }: { label: string; value: string; mono?: boolean; prominent?: boolean; className?: string }) {
  return <div className={`min-w-0 ${className}`}><p className="text-[9px] font-semibold uppercase tracking-wide text-slate-500">{label}</p><p className={`mt-0.5 break-words text-xs text-slate-900 ${mono ? 'font-mono' : ''} ${prominent ? 'text-sm font-bold' : 'font-medium'}`}>{value || '—'}</p></div>
}

function InvoiceField({ label, value, onChange, disabled = false, className = '' }: { label: string; value: string; onChange: (value: string) => void; disabled?: boolean; className?: string }) {
  return <label className={`grid min-w-0 gap-1 text-[9px] font-semibold uppercase tracking-wide text-slate-500 ${className}`}>{label}<input aria-label={label} value={value} disabled={disabled} onChange={(event) => onChange(event.target.value)} className="w-full border-b border-slate-200 bg-transparent py-1 text-xs font-medium normal-case tracking-normal text-slate-900 outline-none focus:border-sky-600 disabled:opacity-70" /></label>
}

function toDateInput(value: string | Date) {
  const date = value instanceof Date ? value : parseInvoiceDate(value) ?? new Date()
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

function parseInvoiceDate(value: string) {
  const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value)
  if (iso) return new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]))
  const us = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/.exec(value)
  if (!us) return null
  const year = Number(us[3]) < 100 ? 2000 + Number(us[3]) : Number(us[3])
  return new Date(year, Number(us[1]) - 1, Number(us[2]))
}

function calculateDueDate(invoiceDate: string, terms: string) {
  const date = parseInvoiceDate(invoiceDate) ?? new Date()
  date.setDate(date.getDate() + (Number(terms.match(/\d+/)?.[0]) || 30))
  return toDateInput(date)
}

function displayDate(value: string) {
  const date = parseInvoiceDate(value)
  return date ? date.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' }) : value
}

function downloadFile(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.append(anchor)
  anchor.click()
  anchor.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 1000)
}


