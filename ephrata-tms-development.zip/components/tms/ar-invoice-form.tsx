'use client'

import { useMemo, useState } from 'react'
import { ExternalLink, FileText, PencilLine, Printer } from 'lucide-react'
import { formatUsd } from '@/lib/tms-data'

type ChargeRow = {
  code: string
  description: string
  quantity: number
  rate: number
  amount: number
}

type InvoiceFields = {
  invoiceNo: string
  arAccount: string
  customer: string
  customerCode: string
  billTo: string
  shipTo: string
  shipDate: string
  deliveryDate: string
  terms: string
  reference: string
  container: string
  poNumber: string
}

const initialFields: InvoiceFields = {
  invoiceNo: 'AAA-26-4472',
  arAccount: '1030',
  customer: 'Cascade Home Goods',
  customerCode: 'CASCADE-001',
  billTo: '21415 84th Ave S, Kent, WA 98032',
  shipTo: '21415 84th Ave S, Kent, WA 98032',
  shipDate: '09/25/2026',
  deliveryDate: '09/25/2026',
  terms: 'Net 30',
  reference: 'LOAD 106381',
  container: 'MSCU 482917-3',
  poNumber: 'CHG-PO-8821',
}

const initialRows: ChargeRow[] = [
  { code: '3000', description: 'Freight — Port drayage linehaul, T18 to Kent, WA', quantity: 1, rate: 3000, amount: 3000 },
  { code: '3010', description: 'Pre-pull', quantity: 1, rate: 150, amount: 150 },
  { code: '3010', description: 'Storage', quantity: 0, rate: 0, amount: 0 },
  { code: '3010', description: 'Chassis', quantity: 1, rate: 90, amount: 90 },
]

export function ArInvoiceForm() {
  const [fields, setFields] = useState(initialFields)
  const [rows, setRows] = useState(initialRows)
  const [audit, setAudit] = useState('Original entry · System generated from e-POD')

  const total = useMemo(() => rows.reduce((sum, row) => sum + (Number(row.amount) || 0), 0), [rows])

  function recordEdit(description: string) {
    const timestamp = new Intl.DateTimeFormat('en-US', {
      month: '2-digit', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
    }).format(new Date())
    setAudit(`${timestamp} · Edited ${description} · AAA Intermodal`)
  }

  function updateField(key: keyof InvoiceFields, value: string) {
    setFields((current) => ({ ...current, [key]: value }))
    recordEdit(key.replace(/([A-Z])/g, ' $1').toLowerCase())
  }

  function updateRow(index: number, key: keyof ChargeRow, value: string) {
    setRows((current) => current.map((row, rowIndex) => rowIndex === index
      ? { ...row, [key]: key === 'quantity' || key === 'rate' || key === 'amount' ? Number(value) || 0 : value }
      : row))
    recordEdit(`charge line ${index + 1}`)
  }

  return (
    <section aria-labelledby="ar-form-heading" className="overflow-hidden rounded-md border border-border bg-card shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border bg-muted/50 px-3 py-2">
        <div className="flex items-center gap-2">
          <FileText className="size-4 text-primary" aria-hidden />
          <h2 id="ar-form-heading" className="text-sm font-semibold">Accounts Receivable Invoice</h2>
          <span className="rounded-sm border border-border bg-background px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">FORM #750056</span>
        </div>
        <div className="flex items-center gap-2">
          <a href={`/track/106381`} target="_blank" rel="noreferrer" className="inline-flex h-7 items-center gap-1.5 rounded-sm border border-border bg-background px-2 text-xs font-medium hover:bg-muted">
            <ExternalLink className="size-3.5" aria-hidden />Customer tracking portal
          </a>
          <button type="button" onClick={() => window.print()} className="inline-flex h-7 items-center gap-1.5 rounded-sm border border-border bg-background px-2 text-xs font-medium hover:bg-muted">
            <Printer className="size-3.5" aria-hidden />Print
          </button>
        </div>
      </div>

      <div className="p-3 md:p-4">
        <div className="grid gap-4 border-b-2 border-foreground/80 pb-3 md:grid-cols-[1fr_auto]">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Ephrata TMS · dba AAA Intermodal</p>
            <h3 className="mt-1 text-xl font-bold tracking-tight">INVOICE</h3>
            <p className="text-xs text-muted-foreground">Intermodal drayage · Kent, Washington</p>
          </div>
          <div className="grid grid-cols-2 gap-x-5 gap-y-1 self-start text-xs md:min-w-[300px]">
            <span className="text-muted-foreground">Invoice No.</span><InlineValue label="Invoice number" value={fields.invoiceNo} onSave={(v) => updateField('invoiceNo', v)} />
            <span className="text-muted-foreground">A/R Acct</span><InlineValue label="A/R account" value={fields.arAccount} onSave={(v) => updateField('arAccount', v)} mono />
            <span className="text-muted-foreground">Invoice date</span><InlineValue label="Invoice date" value="09/25/2026" onSave={(v) => recordEdit(`invoice date ${v}`)} mono />
            <span className="text-muted-foreground">Due date</span><InlineValue label="Due date" value="10/25/2026" onSave={(v) => recordEdit(`due date ${v}`)} mono />
          </div>
        </div>

        <div className="grid gap-4 border-b border-border py-3 text-xs sm:grid-cols-2 lg:grid-cols-4">
          <AddressBlock title="BILL TO">
            <InlineValue label="Customer name" value={fields.customer} onSave={(v) => updateField('customer', v)} strong />
            <InlineValue label="Customer code" value={fields.customerCode} onSave={(v) => updateField('customerCode', v)} mono muted />
            <InlineValue label="Billing address" value={fields.billTo} onSave={(v) => updateField('billTo', v)} muted />
          </AddressBlock>
          <AddressBlock title="SHIP TO">
            <InlineValue label="Ship-to name" value={fields.customer} onSave={(v) => updateField('customer', v)} strong />
            <InlineValue label="Delivery address" value={fields.shipTo} onSave={(v) => updateField('shipTo', v)} muted />
          </AddressBlock>
          <AddressBlock title="SHIP / DEL DATES">
            <div className="flex gap-2"><span className="w-12 text-muted-foreground">Ship</span><InlineValue label="Ship date" value={fields.shipDate} onSave={(v) => updateField('shipDate', v)} mono /></div>
            <div className="flex gap-2"><span className="w-12 text-muted-foreground">Del</span><InlineValue label="Delivery date" value={fields.deliveryDate} onSave={(v) => updateField('deliveryDate', v)} mono /></div>
            <div className="flex gap-2"><span className="w-12 text-muted-foreground">Terms</span><InlineValue label="Payment terms" value={fields.terms} onSave={(v) => updateField('terms', v)} /></div>
          </AddressBlock>
          <AddressBlock title="SHIPMENT REFERENCES">
            <InlineValue label="Load number" value={fields.reference} onSave={(v) => updateField('reference', v)} mono strong />
            <InlineValue label="Container number" value={fields.container} onSave={(v) => updateField('container', v)} mono muted />
            <InlineValue label="Customer PO" value={fields.poNumber} onSave={(v) => updateField('poNumber', v)} mono muted />
          </AddressBlock>
        </div>

        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[680px] border-collapse text-xs">
            <thead>
              <tr className="border-y border-foreground/70 bg-muted/60 text-left font-mono text-[10px] uppercase tracking-wider">
                <th className="w-20 px-2 py-2">A/R Code</th>
                <th className="px-2 py-2">Description</th>
                <th className="w-20 px-2 py-2 text-right">Qty</th>
                <th className="w-28 px-2 py-2 text-right">Rate</th>
                <th className="w-28 px-2 py-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={`${row.code}-${index}`} className="border-b border-border/80 hover:bg-muted/30">
                  <td className="px-2 py-1.5"><InlineValue label={`Line ${index + 1} A/R code`} value={row.code} onSave={(v) => updateRow(index, 'code', v)} mono /></td>
                  <td className="px-2 py-1.5"><InlineValue label={`Line ${index + 1} description`} value={row.description} onSave={(v) => updateRow(index, 'description', v)} /></td>
                  <td className="px-2 py-1.5 text-right"><InlineValue label={`Line ${index + 1} quantity`} value={String(row.quantity)} onSave={(v) => updateRow(index, 'quantity', v)} mono align="right" /></td>
                  <td className="px-2 py-1.5 text-right"><InlineValue label={`Line ${index + 1} rate`} value={formatUsd(row.rate)} onSave={(v) => updateRow(index, 'rate', v.replace(/[$,]/g, ''))} mono align="right" /></td>
                  <td className="px-2 py-1.5 text-right"><InlineValue label={`Line ${index + 1} amount`} value={formatUsd(row.amount)} onSave={(v) => updateRow(index, 'amount', v.replace(/[$,]/g, ''))} mono align="right" strong /></td>
                </tr>
              ))}
              <tr className="border-b border-border/80">
                <td className="px-2 py-1.5"><InlineValue label="Additional line A/R code" value="3010" onSave={(v) => recordEdit(`additional charge code ${v}`)} mono muted /></td>
                <td className="px-2 py-1.5"><InlineValue label="Additional line description" value="Additional accessorial / notes" onSave={(v) => recordEdit(`additional charge description ${v}`)} muted /></td>
                <td className="px-2 py-1.5 text-right"><InlineValue label="Additional line quantity" value="—" onSave={(v) => recordEdit(`additional charge quantity ${v}`)} mono align="right" muted /></td>
                <td className="px-2 py-1.5 text-right"><InlineValue label="Additional line rate" value="—" onSave={(v) => recordEdit(`additional charge rate ${v}`)} mono align="right" muted /></td>
                <td className="px-2 py-1.5 text-right"><InlineValue label="Additional line amount" value="—" onSave={(v) => recordEdit(`additional charge amount ${v}`)} mono align="right" muted /></td>
              </tr>
            </tbody>
            <tfoot>
              <tr className="border-b-2 border-foreground/80">
                <td colSpan={3} className="px-2 py-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">A/R total due</td>
                <td className="px-2 py-2 text-right font-semibold">USD</td>
                <td className="px-2 py-2 text-right font-mono text-sm font-bold tabular-nums">{formatUsd(total)}</td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="mt-3 grid gap-3 text-[10px] text-muted-foreground sm:grid-cols-[1fr_auto]">
          <div className="border-t border-border pt-2">
            <p className="font-mono uppercase tracking-wider">Audit trail</p>
            <p className="mt-1">{audit}</p>
            <p>Form #750056 · A/R account {fields.arAccount} · e-POD attached to load 106381</p>
          </div>
          <div className="flex gap-5 border-t border-border pt-2 font-mono sm:text-right">
            <span>Entered by<br /><b className="font-sans text-foreground">Dispatch · AAA</b></span>
            <span>Page<br /><b className="font-sans text-foreground">1 of 1</b></span>
            <span>Printed<br /><b className="font-sans text-foreground">On demand</b></span>
          </div>
        </div>
        <p className="mt-3 flex items-center gap-1 border-t border-dashed border-border pt-2 text-[10px] text-muted-foreground"><PencilLine className="size-3" aria-hidden />Click any value to edit. Changes update the running invoice total.</p>
      </div>
    </section>
  )
}

function AddressBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="flex min-w-0 flex-col gap-1"><h4 className="mb-0.5 font-mono text-[10px] font-semibold tracking-wider text-muted-foreground">{title}</h4>{children}</div>
}

function InlineValue({
  label,
  value,
  onSave,
  mono = false,
  muted = false,
  strong = false,
  align = 'left',
}: {
  label: string
  value: string
  onSave: (value: string) => void
  mono?: boolean
  muted?: boolean
  strong?: boolean
  align?: 'left' | 'right'
}) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(value)
  const classes = `${mono ? 'font-mono' : ''} ${muted ? 'text-muted-foreground' : ''} ${strong ? 'font-semibold text-foreground' : ''} ${align === 'right' ? 'text-right' : 'text-left'}`

  if (editing) {
    return <input
      autoFocus
      aria-label={label}
      value={draft}
      onChange={(event) => setDraft(event.target.value)}
      onBlur={() => { onSave(draft); setEditing(false) }}
      onKeyDown={(event) => {
        if (event.key === 'Enter') event.currentTarget.blur()
        if (event.key === 'Escape') { setDraft(value); setEditing(false) }
      }}
      className={`w-full min-w-12 rounded-sm border border-primary/40 bg-background px-1 py-0.5 text-xs outline-none ring-2 ring-primary/15 ${classes}`}
    />
  }

  return <button
    type="button"
    aria-label={`Edit ${label}: ${value}`}
    title="Click to edit"
    onClick={() => { setDraft(value); setEditing(true) }}
    className={`group inline-flex max-w-full items-center gap-1 rounded-sm px-1 py-0.5 hover:bg-accent/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${classes}`}
  >
    <span className="truncate">{value}</span>
  </button>
}

export const invoiceFormAudit = 'Form 750056 · Editable A/R invoice'
export const invoiceFormIcon = FileText
export const invoiceFormMetadata = { title: 'PCS Software Accounts Receivable', code: '750056' }
export const invoiceFormStatusLabel = 'Ready for review'
export const invoiceFormActionLabel = 'Edit invoice'
export const invoiceFormMarker = 'A/R 1030'
export const invoiceFormHint = 'Freight 3000 · Accessorials 3010'
