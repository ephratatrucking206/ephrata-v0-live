'use client'

import { useState } from 'react'
import { CalendarDays, Check, ChevronLeft, ChevronRight, MapPin, Printer, QrCode, Truck, X } from 'lucide-react'
import { QRCodeSVG } from 'qrcode.react'
import { EMODAL_MOVE_TYPES, defaultEmodalMoveType, TERMINALS, type EModalMoveType, type Load, type TerminalAppointment } from '@/lib/tms-data'

const terminals = TERMINALS.filter((terminal) => terminal.code !== 'Tacoma Yard').map((terminal) => terminal.appointmentLabel ?? terminal.name)

const timeSlots = Array.from({ length: 10 }, (_, index) => {
  const startHour = index + 8
  return `${formatHour(startHour)} - ${formatHour(startHour + 1)}`
})

const stepLabels = ['Add required data', 'Add move details', 'Choose appointment time', 'Confirmation']

type AppointmentForm = Omit<TerminalAppointment, 'pin' | 'savedAtIso'>

type Props = {
  loads: Load[]
  initialLoadId: string
  onSave: (loadId: string, appointment: TerminalAppointment) => void
  onClose: () => void
}

export function EmodalAppointmentModal({ loads, initialLoadId, onSave, onClose }: Props) {
  const initialLoad = loads.find((load) => load.id === initialLoadId) ?? loads[0]
  const [selectedLoadId, setSelectedLoadId] = useState(initialLoad?.id ?? '')
  const [form, setForm] = useState<AppointmentForm>(() => initialLoad ? createAppointmentForm(initialLoad) : createEmptyForm())
  const [step, setStep] = useState(1)
  const [error, setError] = useState('')
  const [savedAppointment, setSavedAppointment] = useState<TerminalAppointment | null>(null)
  const selectedLoad = loads.find((load) => load.id === selectedLoadId)

  const updateForm = <K extends keyof AppointmentForm>(key: K, value: AppointmentForm[K]) => {
    setForm((current) => ({ ...current, [key]: value }))
    setError('')
  }

  const handleLoadChange = (loadId: string) => {
    const nextLoad = loads.find((load) => load.id === loadId)
    setSelectedLoadId(loadId)
    if (nextLoad) setForm(createAppointmentForm(nextLoad))
    setError('')
  }

  const continueStep = () => {
    if (step === 2 && (!form.container.trim() || !form.billOfLading.trim() || !form.driverName.trim())) {
      setError('Container #, B/L #, and Driver Name are required to continue.')
      return
    }
    setStep((current) => Math.min(3, current + 1))
    setError('')
  }

  const confirmAppointment = () => {
    if (!selectedLoad) return
    const appointment: TerminalAppointment = {
      ...form,
      pin: createGatePin(form.terminal),
      savedAtIso: new Date().toISOString(),
    }
    onSave(selectedLoad.id, appointment)
    setSavedAppointment(appointment)
    setStep(4)
  }

  const handleKeyDown = (event: React.KeyboardEvent<HTMLElement>) => {
    if (event.key === 'Escape') onClose()
  }

  if (!selectedLoad) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/65 p-3 backdrop-blur-sm" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section role="dialog" aria-modal="true" aria-labelledby="emodal-title" onKeyDown={handleKeyDown} className="my-auto flex max-h-[94vh] w-full max-w-4xl flex-col overflow-hidden rounded-xl border border-border bg-background shadow-2xl">
        <header className="flex shrink-0 items-start justify-between gap-4 bg-sidebar px-5 py-4 text-sidebar-foreground">
          <div className="min-w-0">
            <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.16em] text-sidebar-foreground/65">Terminal appointment desk</p>
            <h2 id="emodal-title" className="mt-1 text-sm font-bold leading-5 sm:text-base">CargoSprint · eModal Community Portal · Ephrata Trucking LLC</h2>
            <p className="mt-1 text-xs text-sidebar-foreground/75">Demo-only appointment preview. No live booking request or gate credentials are sent to eModal.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close terminal appointment" className="inline-flex size-9 shrink-0 items-center justify-center rounded-md text-sidebar-foreground/80 hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring"><X className="size-4" aria-hidden /></button>
        </header>

        <ol aria-label="Appointment booking steps" className="grid shrink-0 grid-cols-4 border-b border-border bg-card">
          {stepLabels.map((label, index) => {
            const number = index + 1
            const active = step === number
            const complete = step > number
            return <li key={label} aria-current={active ? 'step' : undefined} className="flex min-w-0 items-center gap-2 border-r border-border px-2 py-3 last:border-r-0 sm:px-4">
              <span className={`flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${complete ? 'bg-emerald-600 text-white' : active ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                {complete ? <Check className="size-3.5" aria-hidden /> : number}
              </span>
              <span className={`hidden min-w-0 truncate text-[10px] font-semibold leading-tight sm:block ${active ? 'text-foreground' : 'text-muted-foreground'}`}>{label}</span>
              <span className="sr-only">{label}</span>
            </li>
          })}
        </ol>

        <div className="min-h-0 flex-1 overflow-y-auto px-4 py-5 sm:px-6">
          {step < 4 ? <div className="mx-auto max-w-3xl">
            <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="font-mono text-[10px] font-semibold uppercase tracking-widest text-primary">Step {step} of 4</p>
                <h3 className="mt-1 text-lg font-bold">{stepLabels[step - 1]}</h3>
              </div>
              <label className="grid min-w-56 gap-1 text-[10px] font-semibold text-muted-foreground">Dispatch load
                <select aria-label="Dispatch load" value={selectedLoadId} onChange={(event) => handleLoadChange(event.currentTarget.value)} className="h-10 rounded-md border border-input bg-background px-3 text-sm font-medium text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  {loads.map((load) => <option key={load.id} value={load.id}>{load.id} · {load.container} · {load.driver ?? 'Unassigned'}</option>)}
                </select>
              </label>
            </div>

            {step === 1 && <div className="grid gap-4 sm:grid-cols-2">
              <label className="grid gap-1.5 text-xs font-semibold">Trucking Company
                <input value="Ephrata trucking llc" readOnly aria-readonly="true" className="h-11 rounded-md border border-input bg-muted/60 px-3 text-sm font-medium text-foreground" />
                <span className="text-[10px] font-normal text-muted-foreground">Company is locked to the signed-in carrier profile.</span>
              </label>
              <label className="grid gap-1.5 text-xs font-semibold">Terminal
                <select value={form.terminal} onChange={(event) => updateForm('terminal', event.currentTarget.value)} className="h-11 rounded-md border border-input bg-background px-3 text-sm font-medium text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  {terminals.map((terminal) => <option key={terminal} value={terminal}>{terminal}</option>)}
                </select>
              </label>
              <label className="grid gap-1.5 text-xs font-semibold sm:col-span-2">Move Type
                <select value={form.moveType} onChange={(event) => updateForm('moveType', event.currentTarget.value as EModalMoveType)} className="h-11 rounded-md border border-input bg-background px-3 text-sm font-semibold text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  {EMODAL_MOVE_TYPES.map((moveType) => <option key={moveType} value={moveType}>{moveType}</option>)}
                </select>
              </label>
              <div className="rounded-lg border border-primary/15 bg-primary/5 p-3 text-xs text-muted-foreground sm:col-span-2">
                Booking for <span className="font-semibold text-foreground">Load {selectedLoad.id}</span> · Container <span className="font-mono font-semibold text-foreground">{selectedLoad.container}</span> · Driver <span className="font-semibold text-foreground">{selectedLoad.driver ?? 'Unassigned'}</span>
              </div>
            </div>}

            {step === 2 && <div className="grid gap-4 sm:grid-cols-2">
              <DetailField label="Container #" value={form.container} required error={error} onChange={(value) => updateForm('container', value.toUpperCase())} />
              <DetailField label="B/L #" value={form.billOfLading} required error={error} onChange={(value) => updateForm('billOfLading', value)} />
              <DetailField label="Seal #" value={form.seal} onChange={(value) => updateForm('seal', value)} />
              <DetailField label="Chassis #" value={form.chassis} onChange={(value) => updateForm('chassis', value)} />
              <DetailField label="Driver Name" value={form.driverName} required error={error} onChange={(value) => updateForm('driverName', value)} />
              <DetailField label="License Plate" value={form.licensePlate} onChange={(value) => updateForm('licensePlate', value.toUpperCase())} />
              {error && <p role="alert" className="rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-xs text-destructive sm:col-span-2">{error}</p>}
            </div>}

            {step === 3 && <div className="grid gap-5 sm:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
              <label className="grid content-start gap-2 text-xs font-semibold">Appointment date
                <input type="date" min={getTodayLocal()} value={form.date} onChange={(event) => updateForm('date', event.currentTarget.value)} className="h-11 rounded-md border border-input bg-background px-3 text-sm font-medium text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring" />
                <span className="text-[10px] font-normal text-muted-foreground">Select the date for your terminal gate visit.</span>
              </label>
              <fieldset className="min-w-0">
                <legend className="text-xs font-semibold">Available 1-hour time slots</legend>
                <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-2">
                  {timeSlots.map((timeSlot) => <label key={timeSlot} className={`flex min-h-11 cursor-pointer items-center gap-2 rounded-md border px-3 text-xs font-medium transition-colors ${form.timeSlot === timeSlot ? 'border-primary bg-primary/5 text-primary ring-1 ring-primary/20' : 'border-border bg-card text-foreground hover:bg-muted/60'}`}>
                    <input type="radio" name="appointment-time" value={timeSlot} checked={form.timeSlot === timeSlot} onChange={() => updateForm('timeSlot', timeSlot)} className="accent-primary" />
                    <span className="whitespace-nowrap">{timeSlot}</span>
                  </label>)}
                </div>
              </fieldset>
              {error && <p role="alert" className="text-xs text-destructive sm:col-span-2">{error}</p>}
            </div>}
          </div> : savedAppointment && <section className="mx-auto max-w-2xl" aria-labelledby="appointment-confirmation-title">
            <div className="mb-5 text-center">
              <span className="mx-auto inline-flex size-12 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"><Check className="size-6" aria-hidden /></span>
              <p className="mt-3 font-mono text-[10px] font-semibold uppercase tracking-widest text-emerald-700 dark:text-emerald-300">Preview saved · visible in this session</p>
              <h3 id="appointment-confirmation-title" className="mt-1 text-xl font-bold">eModal appointment pass preview</h3>
              <p className="mt-1 text-xs text-muted-foreground">Load {selectedLoad.id} is updated in this demo session. This booking is not transmitted to eModal.</p>
            </div>
            <article className="gate-pass-print overflow-hidden rounded-xl border border-border bg-card shadow-sm">
              <header className="flex items-start justify-between gap-4 border-b border-border bg-muted/40 px-5 py-4">
                <div><p className="font-mono text-[10px] font-semibold uppercase tracking-widest text-primary">Ephrata Trucking LLC · CargoSprint</p><h4 className="mt-1 text-base font-bold">eModal Gate Appointment</h4><p className="mt-1 text-xs text-muted-foreground">{savedAppointment.terminal}</p></div>
                <span className="rounded-full border border-amber-600/20 bg-amber-500/10 px-2.5 py-1 text-[10px] font-bold uppercase text-amber-900 dark:text-amber-200">Preview only</span>
              </header>
              <div className="grid gap-5 p-5 sm:grid-cols-[1fr_auto] sm:items-center">
                <div className="grid grid-cols-2 gap-x-4 gap-y-4 text-xs">
                  <PassDetail label="Load" value={selectedLoad.id} />
                  <PassDetail label="Move Type" value={savedAppointment.moveType} />
                  <PassDetail label="Container #" value={savedAppointment.container} />
                  <PassDetail label="B/L #" value={savedAppointment.billOfLading} />
                  <PassDetail label="Date" value={formatAppointmentDate(savedAppointment.date)} />
                  <PassDetail label="Appointment Window" value={savedAppointment.timeSlot} />
                  <PassDetail label="Driver" value={savedAppointment.driverName} />
                  <PassDetail label="Preview Gate PIN" value={savedAppointment.pin} emphasized />
                </div>
                <div className="flex flex-col items-center gap-2 rounded-lg border border-border bg-white p-3 text-center">
                  <QRCodeSVG value={`EPHRATA|${selectedLoad.id}|${savedAppointment.container}|${savedAppointment.date}|${savedAppointment.timeSlot}|${savedAppointment.pin}`} size={156} level="M" includeMargin aria-label={`Demo QR reference for preview PIN ${savedAppointment.pin}`} />
                  <span className="inline-flex items-center gap-1 font-mono text-[9px] font-semibold uppercase tracking-widest text-slate-700"><QrCode className="size-3" aria-hidden />Demo QR reference · not gate valid</span>
                </div>
              </div>
              <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-border px-5 py-3 text-[10px] text-muted-foreground">
                <span>This demo pass is not authorized for terminal gate check-in.</span>
                <span className="font-mono font-bold text-foreground">{savedAppointment.pin}</span>
              </footer>
            </article>
            <div className="mt-4 flex justify-center">
              <button type="button" onClick={() => window.print()} className="inline-flex min-h-10 items-center gap-2 rounded-md border border-border bg-card px-4 text-xs font-semibold hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><Printer className="size-4" aria-hidden />Print gate pass</button>
            </div>
          </section>}
        </div>

        <footer className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-border bg-card px-4 py-3 sm:px-6">
          <p className="inline-flex items-center gap-1.5 text-[10px] text-muted-foreground"><MapPin className="size-3.5" aria-hidden />{selectedLoad.driver ? `${selectedLoad.driver} · ${selectedLoad.truck ?? 'Truck not assigned'}` : 'No driver assigned'}</p>
          <div className="flex items-center gap-2">
            {step > 1 && step < 4 && <button type="button" onClick={() => { setStep((current) => current - 1); setError('') }} className="inline-flex min-h-10 items-center gap-1 rounded-md border border-border bg-background px-3 text-xs font-semibold hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><ChevronLeft className="size-4" aria-hidden />Back</button>}
            {step === 1 || step === 2 ? <button type="button" onClick={continueStep} className="inline-flex min-h-10 items-center gap-1 rounded-md bg-primary px-4 text-xs font-semibold text-primary-foreground hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">Continue<ChevronRight className="size-4" aria-hidden /></button> : null}
            {step === 3 && <button type="button" disabled={!form.date || !form.timeSlot} onClick={confirmAppointment} className="inline-flex min-h-10 items-center gap-2 rounded-md bg-primary px-4 text-xs font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><Truck className="size-4" aria-hidden />Confirm & save appointment</button>}
            {step === 4 && <button type="button" onClick={onClose} className="inline-flex min-h-10 items-center gap-2 rounded-md bg-primary px-4 text-xs font-semibold text-primary-foreground hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">Done<Check className="size-4" aria-hidden /></button>}
          </div>
        </footer>
      </section>
    </div>
  )
}

function DetailField({ label, value, required = false, error = '', onChange }: { label: string; value: string; required?: boolean; error?: string; onChange: (value: string) => void }) {
  const missing = required && Boolean(error) && !value.trim()
  return <label className="grid gap-1.5 text-xs font-semibold">{label}{required && <span className="sr-only"> required</span>}
    <input value={value} onChange={(event) => onChange(event.currentTarget.value)} required={required} aria-invalid={missing} className="h-11 rounded-md border border-input bg-background px-3 font-mono text-sm font-medium text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring aria-invalid:border-destructive" />
  </label>
}

function PassDetail({ label, value, emphasized = false }: { label: string; value: string; emphasized?: boolean }) {
  return <div className="min-w-0"><dt className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">{label}</dt><dd className={`mt-1 break-words ${emphasized ? 'font-mono text-base font-bold text-primary' : 'font-medium text-foreground'}`}>{value || '—'}</dd></div>
}

function createAppointmentForm(load: Load): AppointmentForm {
  const existing = load.terminalAppointment
  return {
    terminal: existing?.terminal ?? TERMINALS.find((terminal) => terminal.code === load.terminal)?.appointmentLabel ?? TERMINALS.find((terminal) => terminal.code === load.terminal)?.name ?? terminals[0],
    moveType: existing?.moveType ?? defaultEmodalMoveType(load.type),
    container: existing?.container ?? load.container,
    billOfLading: existing?.billOfLading ?? load.billOfLading ?? '',
    seal: existing?.seal ?? load.seal,
    chassis: existing?.chassis ?? load.chassis,
    driverName: existing?.driverName ?? load.driver ?? '',
    licensePlate: existing?.licensePlate ?? '',
    date: existing?.date ?? getTodayLocal(),
    timeSlot: existing?.timeSlot ?? timeSlots[0],
  }
}

function createEmptyForm(): AppointmentForm {
  return { terminal: terminals[0], moveType: EMODAL_MOVE_TYPES[0], container: '', billOfLading: '', seal: '', chassis: '', driverName: '', licensePlate: '', date: getTodayLocal(), timeSlot: timeSlots[0] }
}

function createGatePin(terminal: string) {
  const region = terminal.includes('Seattle') ? 'SEA' : 'TAC'
  const values = new Uint32Array(1)
  crypto.getRandomValues(values)
  return `EP-${region}-${String(values[0] % 90000 + 10000)}`
}

function getTodayLocal() {
  const today = new Date()
  const month = String(today.getMonth() + 1).padStart(2, '0')
  const day = String(today.getDate()).padStart(2, '0')
  return `${today.getFullYear()}-${month}-${day}`
}

function formatAppointmentDate(date: string) {
  if (!date) return '—'
  return new Intl.DateTimeFormat('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(`${date}T12:00:00`))
}

function formatHour(hour: number) {
  const normalized = hour % 24
  const suffix = normalized >= 12 ? 'PM' : 'AM'
  const displayHour = normalized % 12 || 12
  return `${String(displayHour).padStart(2, '0')}:00 ${suffix}`
}
