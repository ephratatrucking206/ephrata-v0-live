export function PageHeader({
  title,
  subtitle,
  children,
}: {
  title: string
  subtitle: string
  children?: React.ReactNode
}) {
  return (
    <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-card px-4 py-3">
      <div className="min-w-0">
        <h1 className="text-base font-semibold tracking-tight text-foreground">{title}</h1>
        <p className="font-mono text-[11px] text-muted-foreground">{subtitle}</p>
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </header>
  )
}
