'use client'

import { useEffect, useState } from 'react'
import { X } from 'lucide-react'
import { createDeliveryReceiptPdf } from '@/lib/delivery-documents'
import type { Load, PodReceiptDetails } from '@/lib/tms-data'

export function DeliveryReceiptPreview({
  load,
  receipt,
  signedAt,
  onClose,
}: {
  load: Load
  receipt: PodReceiptDetails
  signedAt: Date
  onClose: () => void
}) {
  const [pdfUrl, setPdfUrl] = useState<string | null>(null)

  useEffect(() => {
    const { blob } = createDeliveryReceiptPdf(load, receipt, signedAt)
    const url = URL.createObjectURL(blob)
    setPdfUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [load, receipt, signedAt])

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handleEscape)
    return () => window.removeEventListener('keydown', handleEscape)
  }, [onClose])

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/70 p-3 sm:p-6" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section role="dialog" aria-modal="true" aria-labelledby="pod-preview-title" className="flex max-h-[95vh] w-full max-w-4xl flex-col overflow-hidden rounded-xl border border-border bg-background shadow-2xl">
        <header className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div className="min-w-0">
            <h2 id="pod-preview-title" className="font-semibold">Signed POD · {load.container}</h2>
            <p className="mt-0.5 text-xs text-muted-foreground">{receipt.receiverName} · {receipt.confirmationCode ?? load.podConfirmationCode}</p>
          </div>
          <button type="button" autoFocus onClick={onClose} aria-label="Close receipt preview" className="inline-flex size-10 shrink-0 items-center justify-center rounded-md border border-border hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
            <X className="size-4" aria-hidden />
          </button>
        </header>
        {pdfUrl ? <iframe title={`Signed proof of delivery for container ${load.container}`} src={pdfUrl} className="min-h-[65vh] w-full flex-1 bg-muted" /> : <div role="status" className="grid min-h-[65vh] place-items-center text-sm text-muted-foreground">Preparing receipt preview…</div>}
      </section>
    </div>
  )
}

