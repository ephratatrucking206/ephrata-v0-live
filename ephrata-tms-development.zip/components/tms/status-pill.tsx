import { cn } from '@/lib/utils'
import type { LoadStatus, QboStatus } from '@/lib/tms-data'

const STYLES: Record<LoadStatus | QboStatus, string> = {
  Unassigned: 'border-border bg-card text-muted-foreground',
  Dispatched: 'border-primary/25 bg-primary/5 text-primary',
  'At Terminal': 'border-primary/40 bg-primary/10 text-primary',
  'In Transit': 'border-primary bg-primary text-primary-foreground',
  'At Delivery': 'border-accent bg-accent/20 text-foreground',
  Delivered: 'border-success/40 bg-success/10 text-success',
  Hold: 'border-accent bg-accent text-accent-foreground',
  'Draft / Under Review': 'border-amber-400 bg-amber-50 text-amber-900',
  Syncing: 'border-accent bg-accent/20 text-foreground',
  Synced: 'border-success/40 bg-success/10 text-success',
  Sent: 'border-primary/25 bg-primary/5 text-primary',
  Paid: 'border-success bg-success text-success-foreground',
  Overdue: 'border-accent bg-accent text-accent-foreground',
}

export function StatusPill({ status, className }: { status: LoadStatus | QboStatus; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 whitespace-nowrap rounded-sm border px-1.5 py-px text-[11px] font-medium leading-4',
        STYLES[status],
        className,
      )}
    >
      {status === 'Syncing' && <span className="size-1.5 animate-pulse rounded-full bg-accent" aria-hidden />}
      {status}
    </span>
  )
}
