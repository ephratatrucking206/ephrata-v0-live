'use client'

import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react'
import { MessageCircle, Send, X } from 'lucide-react'
import { useTms } from './tms-store'

const quickMessages = [
  '📍 Arrived at Terminal Gate',
  '⏳ In Line / Gate Delay (>45 mins)',
  '📦 Cargo Spotted & Signed',
  '🔄 Empty Chassis Returned',
  '🚨 Urgent: Need Dispatch Assistance',
]

export function DriverDispatchChat({ variant }: { variant: 'driver' | 'dispatch' }) {
  const {
    loads,
    chatMessages,
    chatOpen,
    chatLoadId,
    closeDriverChat,
    sendDriverChatMessage,
  } = useTms()
  const [draft, setDraft] = useState('')
  const bottomRef = useRef<HTMLDivElement>(null)
  const messages = useMemo(
    () => chatMessages.filter((message) => message.loadId === chatLoadId),
    [chatMessages, chatLoadId],
  )
  const load = loads.find((candidate) => candidate.id === chatLoadId)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: 'end' })
  }, [messages])

  if (!chatOpen || !chatLoadId) return null

  const send = (text = draft) => {
    sendDriverChatMessage(text, variant === 'driver' ? 'driver' : 'dispatch', chatLoadId)
    setDraft('')
  }

  const onInputKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing && event.keyCode !== 229) {
      event.preventDefault()
      send()
    }
  }

  return (
    <div className={variant === 'driver' ? 'fixed inset-0 z-[70] flex bg-slate-950/45 p-2' : 'fixed inset-0 z-[70] flex justify-end bg-slate-950/45'}>
      <button type="button" tabIndex={-1} aria-label="Close chat overlay" onClick={closeDriverChat} className="absolute inset-0 cursor-default" />
      <section aria-labelledby="dispatcher-chat-title" className={`relative z-10 flex min-h-0 w-full flex-col overflow-hidden border border-border bg-background shadow-2xl ${variant === 'driver' ? 'mx-auto max-w-xl rounded-2xl' : 'h-full max-w-xl'}`}>
        <header className="flex shrink-0 items-center justify-between gap-3 border-b border-border bg-card px-4 py-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary"><MessageCircle className="size-4" aria-hidden /></span>
              <h2 id="dispatcher-chat-title" className="truncate text-sm font-semibold">Asmarew · Dispatch Desk</h2>
            </div>
            <p className="mt-1 pl-10 text-[11px] text-muted-foreground">Driver: {load?.driver || 'Unassigned'} · Load {load?.id ?? chatLoadId} · Container {load?.container ?? 'Active load'} · {load?.type === 'Empty Return' ? 'Return empty' : `Pick full${load?.type ? ` · ${load.type}` : ''}`}</p>
            <p className="mt-2 inline-flex max-w-full items-center gap-1.5 rounded-full border border-sky-200 bg-sky-50 px-2.5 py-1 text-[10px] font-semibold text-sky-900 dark:border-sky-800 dark:bg-sky-950/40 dark:text-sky-100"><MessageCircle className="size-3 shrink-0" aria-hidden /><span>Ephrata Operations Dispatch Channel · Current app session only</span></p>
          </div>
          <button type="button" aria-label="Close dispatcher chat" onClick={closeDriverChat} className="inline-flex size-11 shrink-0 items-center justify-center rounded-lg hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><X className="size-4" aria-hidden /></button>
        </header>

        <div role="log" aria-live="polite" aria-label="Driver and dispatcher messages" className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-muted/30 p-4">
          {messages.length === 0 ? <p className="py-8 text-center text-sm text-muted-foreground">No messages for this load yet. Send a message to start the thread.</p> : messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === 'driver' ? 'justify-end' : 'justify-start'}`}>
              <article className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 shadow-sm ${message.sender === 'driver' ? 'rounded-br-md bg-primary text-primary-foreground' : 'rounded-bl-md border border-border bg-card text-foreground'} ${message.urgent ? 'ring-2 ring-red-500' : ''}`}>
                <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide opacity-70">{message.sender === 'driver' ? `Driver ${load?.driver || 'Unassigned'}` : 'Asmarew · Dispatch'} · {message.sentAt}</p>
                <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.text}</p>
              </article>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <div className="shrink-0 border-t border-border bg-background p-3 sm:p-4">
          {variant === 'driver' && <div className="mb-3"><p className="mb-2 text-[11px] font-semibold text-muted-foreground">QUICK DRIVER UPDATES</p><div className="flex max-h-28 flex-wrap gap-1.5 overflow-y-auto">{quickMessages.map((message) => <button key={message} type="button" onClick={() => send(message)} className="min-h-10 rounded-full border border-border bg-card px-3 text-left text-[11px] font-medium leading-tight hover:border-primary/40 hover:bg-primary/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{message}</button>)}</div></div>}
          <form onSubmit={(event) => { event.preventDefault(); send() }} className="flex gap-2">
            <input value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={onInputKeyDown} aria-label="Chat message" placeholder={`Message ${variant === 'driver' ? 'Dispatch' : (load?.driver ?? 'driver')}…`} className="h-12 min-w-0 flex-1 rounded-xl border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" />
            <button type="submit" disabled={!draft.trim()} className="inline-flex min-h-12 shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"><Send className="size-4" aria-hidden /><span>Send</span></button>
          </form>
          <p className="mt-2 text-center text-[10px] text-muted-foreground">This load thread is shared in the current app session only. There is no server delivery, encryption, sign-in, or authorization enforcement in this preview.</p>
        </div>
      </section>
    </div>
  )
}

export function DriverChatLauncher({ loadId, label = 'Chat with Driver', compact = false }: { loadId: string; label?: string; compact?: boolean }) {
  const { openDriverChat, unreadByLoad, urgentUnreadLoadIds } = useTms()
  const unread = unreadByLoad[loadId] ?? 0
  const urgent = urgentUnreadLoadIds.includes(loadId)

  return (
    <button type="button" onClick={() => openDriverChat(loadId, 'dispatch')} aria-label={`${label} for load ${loadId}${unread ? `, ${unread} unread message${unread === 1 ? '' : 's'}` : ''}`} className={`relative inline-flex min-h-11 items-center justify-center gap-1.5 rounded-lg border px-2.5 font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${urgent ? 'border-red-500 bg-red-50 text-red-800 hover:bg-red-100 dark:bg-red-950/40 dark:text-red-200' : unread ? 'border-amber-500 bg-amber-50 text-amber-900 hover:bg-amber-100 dark:bg-amber-950/40 dark:text-amber-200' : 'border-primary/30 bg-primary/5 text-primary hover:bg-primary/10'} ${compact ? 'px-2 text-[10px]' : 'text-xs'}`}>
      <MessageCircle className="size-3.5 shrink-0" aria-hidden />
      <span>{label}</span>
      {unread > 0 && <span className={`inline-flex min-w-5 items-center justify-center rounded-full px-1 py-0.5 text-[9px] font-bold text-white ${urgent ? 'bg-red-600' : 'bg-amber-600'}`}>{unread}</span>}
    </button>
  )
}
