'use client'

import { FileInput, Globe2, LayoutGrid, Receipt, Settings, Smartphone } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useTms, type View } from './tms-store'

const NAV: { id: View; label: string; icon: typeof LayoutGrid; hint: string }[] = [
  { id: 'dispatch', label: 'Dispatch Board', icon: LayoutGrid, hint: 'Port drayage operations' },
  { id: 'inbound', label: 'Inbound Orders', icon: FileInput, hint: 'Parse broker PDFs' },
  { id: 'driver', label: 'Driver Mobile & DVIR', icon: Smartphone, hint: 'Jemal · #106381' },
  { id: 'billing', label: 'Commercial Billing & Accounts Receivable', icon: Receipt, hint: 'Freight billing · A/R' },
  { id: 'settings', label: 'Settings', icon: Settings, hint: 'Team access · Security' },
]

export function Sidebar() {
  const { view, setView, loads, invoices, openTracking } = useTms()
  const signatureLoad = loads.find((load) => load.id === '106381')
  const syncing = invoices.some((i) => i.status === 'Syncing')

  return (
    <aside className="flex shrink-0 flex-col bg-sidebar text-sidebar-foreground md:h-dvh md:w-60 md:border-r md:border-sidebar-border">
      <div className="flex items-center gap-3 border-b border-sidebar-border px-4 py-3 md:py-4">
        <div
          aria-hidden
          className="flex size-9 shrink-0 items-center justify-center rounded-md bg-sidebar-primary font-mono text-xs font-bold tracking-tight text-sidebar-primary-foreground"
        >
          AAA
        </div>
        <div className="min-w-0 leading-tight">
          <p className="truncate text-sm font-semibold">AAA Intermodal</p>
          <p className="text-[11px] leading-snug text-sidebar-foreground/60">Ephrata Trucking, LLC · Operations Hub (Kent, WA)</p>
        </div>
      </div>

      <nav aria-label="Primary" className="flex gap-1 overflow-x-auto p-2 md:flex-col md:gap-0.5 md:p-3">
        <p className="hidden px-2 pb-2 pt-1 font-mono text-[10px] uppercase tracking-widest text-sidebar-foreground/40 md:block">
          Operations
        </p>
        {NAV.map((item) => {
          const active = view === item.id
          const Icon = item.icon
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setView(item.id)}
              aria-current={active ? 'page' : undefined}
              className={cn(
                'group flex shrink-0 items-center gap-3 rounded-md px-2.5 py-2 text-left text-sm transition-colors',
                active
                  ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                  : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground',
              )}
            >
              <Icon className={cn('size-4 shrink-0', active && 'text-sidebar-primary')} aria-hidden />
              <span className="flex min-w-0 flex-col leading-tight">
                <span className="whitespace-normal break-words font-medium">{item.label}</span>
                <span className="hidden truncate text-[11px] text-sidebar-foreground/50 md:block">
                  {item.id === 'driver' ? `${signatureLoad?.driver ?? 'Driver'} · #${signatureLoad?.id ?? '106381'}` : item.hint}
                </span>
              </span>
              {item.id === 'billing' && syncing && (
                <span className="ml-auto size-2 shrink-0 animate-pulse rounded-full bg-sidebar-primary" aria-label="QuickBooks syncing" />
              )}
            </button>
          )
        })}
        <button
          type="button"
          onClick={() => openTracking('106381')}
          className="group flex shrink-0 items-center gap-3 rounded-md px-2.5 py-2 text-left text-sm text-sidebar-foreground/70 transition-colors hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
        >
          <Globe2 className="size-4 shrink-0 text-sidebar-primary" aria-hidden />
          <span className="flex min-w-0 flex-col leading-tight">
            <span className="truncate font-medium">Customer Tracking</span>
            <span className="hidden truncate text-[11px] text-sidebar-foreground/50 md:block">Public shipment portal</span>
          </span>
        </button>
      </nav>

      <div className="mt-auto hidden border-t border-sidebar-border p-4 md:block">
        <div className="flex items-center gap-2 text-xs">
          <span className="size-1.5 rounded-full bg-success" aria-hidden />
          <span className="text-sidebar-foreground/80">100% paperless</span>
        </div>
        <p className="mt-1 font-mono text-[11px] leading-relaxed text-sidebar-foreground/50">
          e-POD · e-BOL · QBO sync
          <br />
          USDOT 1839352 · MC 669162
        </p>
      </div>
    </aside>
  )
}
