'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, BadgeCheck, CalendarClock, Check, Circle, Clock3, Container, MapPin, Route, ShieldCheck, Truck, X, Zap } from 'lucide-react'
import { createSmartDrayagePreset, TERMINALS, type RouteChain } from '@/lib/tms-data'

const optimizerSteps = [
  { title: 'Customer priority', description: 'Golden Intl loads move to the top of dispatch priority.', detail: 'Customer match: Golden Intl · Priority rule: enabled' },
  { title: 'Deadline defense', description: 'Rank active work by nearest Last Free Day and appointment cutoff.', detail: 'Dispatch order: nearest LFD first, then earliest appointment' },
  { title: 'Live availability', description: 'Check customs clearance, freight release, and terminal PIN booking.', detail: 'Preview status: customs cleared · freight released · PIN booked' },
  { title: 'Equipment & location tracking', description: 'Match pickup and staging locations before building a port sequence.', detail: 'Cosentino · Ephrata Tacoma Staging Yard · Husky · WUT · PCT · Everport · T5 · T18' },
  { title: 'Equipment match', description: 'Validate container size against the assigned chassis configuration.', detail: 'Standard 20′ / 40′ · Heavy 4-axle / tri-axle' },
  { title: 'Connected dual-mission', description: 'On eligible port moves, chain a DROP EMPTY into a PICK FULL at the same terminal or facility.', detail: 'Same-port match required · preset chassis handoff: Tacoma Yard → Tacoma Yard' },
  { title: 'Bobtail minimizer', description: 'Flag unnecessary tractor-only miles between consecutive moves.', detail: 'Preset route: 0 empty bobtail miles' },
  { title: 'Shift destination', description: 'Confirm whether the chassis ends at the yard or consignee.', detail: 'Final chassis drop: Tacoma Staging Yard' },
  { title: 'Driver assignment', description: 'Assign a driver based on position and available hours of service.', detail: 'Asmarew · 8.0 HOS hours available (demo value)' },
]

export function RouteBuilderDialog({
  open,
  onClose,
  onBuildPreset,
  onOptimize,
  onOpenDriver,
  routeReady,
  goldenLoadCount,
}: {
  open: boolean
  onClose: () => void
  onBuildPreset: (route: RouteChain) => void
  onOptimize: () => void
  onOpenDriver: () => void
  routeReady: boolean
  goldenLoadCount: number
}) {
  const dialogRef = useRef<HTMLDialogElement>(null)
  const [activeStep, setActiveStep] = useState(0)
  const [completedSteps, setCompletedSteps] = useState<number[]>([])
  const currentStep = optimizerSteps[activeStep]

  useEffect(() => {
    const dialog = dialogRef.current
    if (!dialog) return
    if (open && !dialog.open) {
      setActiveStep(0)
      setCompletedSteps([])
      dialog.showModal()
    } else if (!open && dialog.open) {
      dialog.close()
    }
  }, [open])

  const confirmStep = () => {
    setCompletedSteps((current) => current.includes(activeStep) ? current : [...current, activeStep])
    if (activeStep < optimizerSteps.length - 1) {
      setActiveStep((step) => step + 1)
      return
    }
    onOptimize()
    onClose()
  }

  const buildPreset = () => {
    onBuildPreset(createSmartDrayagePreset())
    setCompletedSteps(optimizerSteps.map((_, index) => index))
  }

  return (
    <dialog
      ref={dialogRef}
      aria-labelledby="route-builder-title"
      onCancel={(event) => { event.preventDefault(); onClose() }}
      onClose={onClose}
      className="route-builder-dialog fixed inset-0 m-auto max-h-[92dvh] w-[min(96vw,68rem)] overflow-hidden rounded-2xl border border-border bg-background p-0 text-foreground shadow-2xl backdrop:bg-slate-950/65"
    >
      <div className="flex max-h-[92dvh] flex-col">
        <header className="flex shrink-0 items-start justify-between gap-4 border-b border-border bg-card px-5 py-4 sm:px-6">
          <div className="flex items-start gap-3">
            <span className="mt-0.5 inline-flex size-10 shrink-0 items-center justify-center rounded-xl bg-amber-400/15 text-amber-600 dark:text-amber-300"><Zap className="size-5" aria-hidden /></span>
            <div>
              <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Ephrata TMS · Dispatch optimization</p>
              <h2 id="route-builder-title" className="mt-1 text-lg font-bold sm:text-xl">9-Step Smart Route Builder</h2>
              <p className="mt-1 text-xs text-muted-foreground">Review each dispatch check or build the three-leg preset in one click.</p>
            </div>
          </div>
          <button type="button" onClick={onClose} aria-label="Close route builder" className="inline-flex size-10 shrink-0 items-center justify-center rounded-lg border border-border hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><X className="size-4" aria-hidden /></button>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="grid gap-5 lg:grid-cols-[17rem_minmax(0,1fr)]">
            <nav aria-label="Route optimization steps" className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-1">
              {optimizerSteps.map((step, index) => {
                const complete = completedSteps.includes(index)
                const active = activeStep === index
                return <button key={step.title} type="button" aria-current={active ? 'step' : undefined} disabled={index > completedSteps.length} onClick={() => setActiveStep(index)} className={`flex min-h-12 items-center gap-2 rounded-lg border px-3 py-2 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-55 ${active ? 'border-primary/40 bg-primary/5 text-foreground' : 'border-border bg-card hover:bg-muted/60'}`}>
                  <span className={`inline-flex size-6 shrink-0 items-center justify-center rounded-full font-mono text-[10px] font-bold ${complete ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300' : active ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>{complete ? <Check className="size-3.5" aria-hidden /> : String(index + 1).padStart(2, '0')}</span>
                  <span className="min-w-0 text-[11px] font-semibold leading-tight">{step.title}</span>
                </button>
              })}
            </nav>

            <section aria-live="polite" className="min-h-[25rem] rounded-xl border border-border bg-card p-4 sm:p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-[10px] font-semibold uppercase tracking-widest text-primary">Step {activeStep + 1} of 9</p>
                  <h3 className="mt-2 text-xl font-bold">{currentStep.title}</h3>
                  <p className="mt-1 max-w-xl text-sm text-muted-foreground">{currentStep.description}</p>
                </div>
                <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 font-mono text-[10px] font-semibold text-amber-800 dark:text-amber-200">Preview data</span>
              </div>

              <div className="mt-5 rounded-xl border border-border bg-background p-4">
                <p className="text-sm font-semibold">{currentStep.detail}</p>
                {activeStep === 0 && <p className="mt-2 text-xs text-muted-foreground">{goldenLoadCount} matching Golden Intl {goldenLoadCount === 1 ? 'load' : 'loads'} in the current dispatch list.</p>}
                {activeStep === 1 && <p className="mt-2 text-xs text-muted-foreground">When optimization is applied, active board rows are sorted by Golden Intl priority, then the nearest upcoming LFD.</p>}
                {activeStep === 2 && <div className="mt-4 grid gap-2 sm:grid-cols-3">{['Customs cleared', 'Freight released', 'PIN booked'].map((status) => <div key={status} className="flex items-center gap-2 rounded-lg border border-emerald-700/20 bg-emerald-500/5 px-3 py-2 text-xs font-medium"><ShieldCheck className="size-4 text-emerald-700 dark:text-emerald-300" aria-hidden />{status}<span className="ml-auto text-[9px] text-muted-foreground">demo</span></div>)}</div>}
                {activeStep === 3 && <div className="mt-4 flex flex-wrap gap-2">{['Cosentino', ...TERMINALS.map((terminal) => terminal.name)].map((location) => <span key={location} className="inline-flex items-center gap-1.5 rounded-full border border-border bg-muted/50 px-2.5 py-1.5 text-[10px] font-medium"><MapPin className="size-3 text-primary" aria-hidden />{location}</span>)}</div>}
                {activeStep === 4 && <div className="mt-4 grid gap-2 sm:grid-cols-2"><div className="rounded-lg border border-border p-3"><p className="text-xs font-semibold">Standard equipment</p><p className="mt-1 text-[11px] text-muted-foreground">20′ / 40′ chassis specifications</p></div><div className="rounded-lg border border-border p-3"><p className="text-xs font-semibold">Heavy equipment</p><p className="mt-1 text-[11px] text-muted-foreground">4-axle / tri-axle validation</p></div></div>}
                {activeStep === 5 && <div className="mt-4 flex items-center gap-3 rounded-lg border border-primary/20 bg-primary/5 p-3"><Route className="size-5 shrink-0 text-primary" aria-hidden /><p className="text-xs leading-relaxed">Only pair a DROP EMPTY with a PICK FULL when both share the same port or facility. This preset also connects the Tacoma Yard chassis drop to the next Tacoma Yard chassis pickup before the Husky full-container move.</p></div>}
                {activeStep === 6 && <div className="mt-4 flex items-center gap-3 rounded-lg border border-emerald-700/20 bg-emerald-500/5 p-3"><Truck className="size-5 shrink-0 text-emerald-700 dark:text-emerald-300" aria-hidden /><p className="text-xs font-semibold">0 empty bobtail miles in the preset route</p></div>}
                {activeStep === 7 && <div className="mt-4 grid grid-cols-2 gap-2"><div className="rounded-lg border border-border p-3"><p className="text-[10px] text-muted-foreground">Recommended drop</p><p className="mt-1 text-xs font-semibold">Tacoma Staging Yard</p></div><div className="rounded-lg border border-border p-3"><p className="text-[10px] text-muted-foreground">Alternative</p><p className="mt-1 text-xs font-semibold">Consignee spot</p></div></div>}
                {activeStep === 8 && <div className="mt-4 flex items-center gap-3 rounded-lg border border-border p-3"><Clock3 className="size-5 shrink-0 text-primary" aria-hidden /><div><p className="text-xs font-semibold">Asmarew · daily driver</p><p className="mt-1 text-[10px] text-muted-foreground">Location and 8.0 hours HOS are illustrative preview values.</p></div></div>}
              </div>

              <div className="mt-4 flex items-start gap-2 rounded-lg bg-muted/50 px-3 py-2.5 text-[10px] leading-relaxed text-muted-foreground"><Circle className="mt-0.5 size-3 shrink-0" aria-hidden /><p>Availability and driver hours are demo values; this preview is not connected to eModal or a live HOS system.</p></div>

              <div className="mt-5 flex flex-wrap items-center justify-between gap-2">
                <button type="button" onClick={() => setActiveStep((step) => Math.max(0, step - 1))} disabled={activeStep === 0} className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-border px-3 text-xs font-semibold hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"><ArrowLeft className="size-3.5" aria-hidden />Previous</button>
                <button type="button" onClick={confirmStep} className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-primary px-3.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90">{activeStep === optimizerSteps.length - 1 ? 'Run 9-step optimization' : 'Confirm step'}{activeStep === optimizerSteps.length - 1 ? <Zap className="size-3.5" aria-hidden /> : <ArrowRight className="size-3.5" aria-hidden />}</button>
              </div>
            </section>
          </div>

          <section className="mt-5 rounded-xl border border-amber-500/25 bg-amber-500/5 p-4 sm:p-5" aria-labelledby="route-preset-title">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="flex items-start gap-3"><span className="inline-flex size-9 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 text-amber-700 dark:text-amber-200"><CalendarClock className="size-4" aria-hidden /></span><div><h3 id="route-preset-title" className="text-sm font-bold">Today&apos;s 3-leg chained-load preset</h3><p className="mt-1 text-xs text-muted-foreground">Cosentino → Tacoma Yard → Husky → Tacoma Yard · MRSU5023427 · #9174</p></div></div>
              <button type="button" onClick={buildPreset} className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-amber-400 px-3.5 text-xs font-bold text-slate-950 hover:bg-amber-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"><Zap className="size-3.5" aria-hidden />{routeReady ? 'Rebuild chained load' : 'Build chained load'}</button>
            </div>
            <ol className="mt-4 grid gap-2 md:grid-cols-3">
              <PresetLeg number="1" title="Hook long chassis" route="Cosentino → Tacoma Staging Yard" equipment="Long chassis · empty" />
              <PresetLeg number="2" title="Hook 4-axle chassis" route="Tacoma Yard → Husky Terminal" equipment="4-Axle 40′ chassis · empty" />
              <PresetLeg number="3" title="In-gate + pull full" route="Husky → Tacoma Staging Yard" equipment="MRSU5023427 · #9174 · loaded" />
            </ol>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-amber-500/15 pt-3">
              <span className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-200"><BadgeCheck className="size-4" aria-hidden />Dual-Mission Verified · Zero Empty Bobtail</span>
              {routeReady && <button type="button" onClick={onOpenDriver} className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-primary/30 bg-background px-3 text-xs font-semibold text-primary hover:bg-primary/5"><Container className="size-4" aria-hidden />Open driver run</button>}
            </div>
          </section>
        </div>
      </div>
    </dialog>
  )
}

function PresetLeg({ number, title, route, equipment }: { number: string; title: string; route: string; equipment: string }) {
  return <li className="rounded-lg border border-border bg-card p-3"><div className="flex items-center gap-2"><span className="inline-flex size-6 items-center justify-center rounded-full bg-primary/10 font-mono text-[10px] font-bold text-primary">{number}</span><p className="text-xs font-semibold">{title}</p></div><p className="mt-2 text-[10px] text-muted-foreground">{route}</p><p className="mt-1 text-[10px] font-medium">{equipment}</p></li>
}
