'use client'

import { Sidebar } from './sidebar'
import { TmsProvider, useTms } from './tms-store'
import { DispatchBoard } from './dispatch-board'
import { DriverMobileView } from './driver-mobile-view'
import { BillingView } from './billing-view'
import { TrackingPortal } from './tracking-portal'
import { RevenueWidget } from './revenue-widget'
import { SettingsView } from './settings-view'
import { InboundOrders } from './inbound-orders'
import { DriverDispatchChat } from './driver-dispatch-chat'

export function AppShell() {
  return (
    <TmsProvider>
      <div className="flex h-dvh flex-col overflow-hidden md:flex-row">
        <Sidebar />
        <main className="flex min-h-0 min-w-0 flex-1 flex-col">
          <ActiveView />
        </main>
        <TrackingPortal />
        <RevenueWidget />
        <SharedDriverChat />
      </div>
    </TmsProvider>
  )
}

function SharedDriverChat() {
  const { view } = useTms()
  return <DriverDispatchChat variant={view === 'driver' ? 'driver' : 'dispatch'} />
}

function ActiveView() {
  const { view } = useTms()
  if (view === 'driver') return <DriverMobileView />
  if (view === 'billing') return <BillingView />
  if (view === 'inbound') return <InboundOrders />
  if (view === 'settings') return <SettingsView />
  return <DispatchBoard />
}
