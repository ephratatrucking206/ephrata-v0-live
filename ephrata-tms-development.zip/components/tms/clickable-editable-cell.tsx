'use client'

import { useEffect, useState } from 'react'
import { PencilLine } from 'lucide-react'
import { cn } from '@/lib/utils'

export function ClickableEditableCell({
  value,
  label,
  onCommit,
  onOpen,
  openLabel,
  className,
}: {
  value: string
  label: string
  onCommit: (value: string) => void
  onOpen: () => void
  openLabel: string
  className?: string
}) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(value)
  useEffect(() => setDraft(value), [value])

  const commit = () => {
    const nextValue = draft.trim()
    if (nextValue !== value) onCommit(nextValue)
    setEditing(false)
  }

  if (editing) {
    return (
      <input
        autoFocus
        aria-label={`Edit ${label}`}
        value={draft}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === 'Enter') {
            event.preventDefault()
            commit()
          }
          if (event.key === 'Escape') {
            setDraft(value)
            setEditing(false)
          }
        }}
        className={cn('min-w-16 max-w-full rounded-sm border border-primary/40 bg-background px-1 py-0.5 text-inherit outline-none ring-2 ring-ring/30', className)}
      />
    )
  }

  return (
    <span className="inline-flex max-w-full items-center gap-1">
      <button type="button" aria-label={openLabel} title={openLabel} onClick={onOpen} className={cn('cursor-pointer rounded-sm text-left font-mono font-semibold text-primary underline decoration-dotted underline-offset-2 hover:bg-accent/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring', className)}>
        {value || '—'}
      </button>
      <button type="button" aria-label={`Edit ${label}`} title={`Edit ${label}`} onClick={() => setEditing(true)} className="rounded-sm p-0.5 text-muted-foreground hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
        <PencilLine className="size-3" aria-hidden />
      </button>
    </span>
  )
}

