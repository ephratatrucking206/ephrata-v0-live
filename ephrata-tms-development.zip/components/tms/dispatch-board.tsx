'use client'

import { useEffect, useMemo, useState } from 'react'
import { AlertTriangle, ChevronDown, Eye, FileCheck2, FileDown, Search, Smartphone, Globe2, Mail, ShieldCheck, CalendarDays, Zap, BadgeCheck } from 'lucide-react'
import { cn } from '@/lib/utils'
import { calculateDaysPastLfd, defaultDispatchMoveType, DEMURRAGE_RATE_BY_TERMINAL, DISPATCH_MOVE_TYPE_OPTIONS, formatLfdCutoff, formatUsd, loadReferences, TERMINALS, type Load, type Terminal } from '@/lib/tms-data'
import { useTms } from './tms-store'
import { EditableCell } from './editable-cell'
import { ClickableEditableCell } from './clickable-editable-cell'
import { ReportExportToolbar } from './report-export-toolbar'
import { PageHeader } from './page-header'
import { PcsInvoiceForm } from './pcs-invoice-form'
import { EmailClientPackage } from './email-client-package'
import { DriverChatLauncher } from './driver-dispatch-chat'
import { DeliveryReceiptPreview } from './delivery-receipt-preview'
import { RouteBuilderDialog } from './route-builder-dialog'
import { EmodalAppointmentModal } from './emodal-appointment-modal'

type Filter = Terminal | 'All'

export function DispatchBoard() {
  const { loads, setView, updateLoad, openTracking, podAlertLoadId, dismissPodAlert, accessRole, setAccessRole, podAuditLog, recordPodAudit, voidPod, activeRouteChain, setActiveRouteChain, saveTerminalAppointment } = useTms()
  const [filter, setFilter] = useState<Filter>('All')
  const [routeBuilderOpen, setRouteBuilderOpen] = useState(false)
  const [appointmentLoadId, setAppointmentLoadId] = useState<string | null>(null)
  const [optimizedLoadOrder, setOptimizedLoadOrder] = useState(false)
  const [query, setQuery] = useState('')
  const [reportStartDate, setReportStartDate] = useState('')
  const [reportEndDate, setReportEndDate] = useState('')
  const [emailLoadId, setEmailLoadId] = useState<string | null>(null)
  const [now, setNow] = useState(() => new Date())

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 60_000)
    return () => window.clearInterval(timer)
  }, [])

  const counts = useMemo(() => {
    const c: Record<string, number> = { All: loads.length }
    for (const l of loads) c[l.terminal] = (c[l.terminal] ?? 0) + 1
    return c
  }, [loads])

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase()
    const filtered = loads.filter((l) => {
      if (filter !== 'All' && l.terminal !== filter) return false
      if (!q) return true
      const refs = loadReferences(l)
      return [l.id, l.container, refs.billOfLading, refs.deliveryOrder, refs.poNumber, l.customer, l.driver ?? '', l.line].some((v) => v.toLowerCase().includes(q))
    })
    if (!optimizedLoadOrder) return filtered
    return filtered.sort((a, b) => {
      const customerPriority = Number(/golden\s+intl/i.test(b.customer)) - Number(/golden\s+intl/i.test(a.customer))
      return customerPriority || getNextLfdTimestamp(a.lfd, now) - getNextLfdTimestamp(b.lfd, now) || getNextAppointmentTimestamp(a.terminalAppointment?.timeSlot ?? a.appt, now, a.terminalAppointment?.date ?? a.appointmentDate) - getNextAppointmentTimestamp(b.terminalAppointment?.timeSlot ?? b.appt, now, b.terminalAppointment?.date ?? b.appointmentDate)
    })
  }, [loads, filter, query, optimizedLoadOrder, now])

  const activeCount = loads.filter((l) => l.status !== 'Delivered').length
  const criticalCount = loads.filter((load) => load.status !== 'Delivered' && isWithinLfdWindow(load.lfd, now)).length
  const podAlert = loads.find((load) => load.id === podAlertLoadId && load.podSigned)
  const emailLoad = loads.find((load) => load.id === emailLoadId)
  const appointmentLoad = loads.find((load) => load.id === appointmentLoadId)
  const [invoiceLoadId, setInvoiceLoadId] = useState<string | null>(null)
  const invoiceLoad = loads.find((load) => load.id === invoiceLoadId)
  const [podPreviewLoadId, setPodPreviewLoadId] = useState<string | null>(null)
  const podPreviewLoad = loads.find((load) => load.id === podPreviewLoadId)
  const reportHeaders = ['Load #', 'POD Date', 'Status', 'B/L #', 'Container #', 'Size/Type', 'DO #', 'PO #', 'Port Terminal', 'Chassis #', 'Driver', 'Customer / Facility', 'Linehaul Rate', 'Fuel Surcharge', 'Accessorials', 'Total Rate', 'Last Free Day Cutoff', 'Days Past Free Time', 'Receiver Print Name', 'Receiving Company / Facility', 'POD Date & Time (ISO)']
  const reportRows = useMemo(() => loads.map((load) => {
    const refs = loadReferences(load)
    const linehaul = load.charges.find((charge) => charge.label.toLowerCase().includes('linehaul'))?.amount ?? 0
    const fuel = load.charges.find((charge) => charge.label.toLowerCase().includes('fuel'))?.amount ?? 0
    const accessorials = load.charges.filter((charge) => !/linehaul|fuel/i.test(charge.label)).reduce((sum, charge) => sum + charge.amount, 0)
    const cutoff = formatLfdCutoff(load.lfd, now)
    const demurrageDays = calculateDaysPastLfd(load.lfd, load.podSignedAtIso ? new Date(load.podSignedAtIso) : now)
    const demurrage = demurrageDays * DEMURRAGE_RATE_BY_TERMINAL[load.terminal]
    const accessorialTotal = accessorials + demurrage
    const date = load.podSignedAtIso ? new Date(load.podSignedAtIso).toISOString().slice(0, 10) : now.toISOString().slice(0, 10)
    return [load.id, date, load.status, refs.billOfLading, load.container, `${load.size} ${load.type}`, refs.deliveryOrder, refs.poNumber, load.terminal, load.chassis, load.driver ?? '', load.customer, formatUsd(linehaul), formatUsd(fuel), formatUsd(accessorialTotal), formatUsd(linehaul + fuel + accessorialTotal), cutoff, demurrageDays, load.podReceipt?.receiverName ?? '', load.podReceipt?.companyName ?? '', load.podSignedAtIso ?? '']
  }), [loads, now])
  const filteredReportRows = useMemo(() => reportRows.filter((row) => {
    const reportDate = String(row[1] ?? '')
    return (!reportStartDate || reportDate >= reportStartDate) && (!reportEndDate || reportDate <= reportEndDate)
  }), [reportRows, reportStartDate, reportEndDate])

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <PageHeader
        title="Dispatch Board & Port Terminals"
        subtitle={`${now.toLocaleDateString('en-US', { weekday: 'short', month: '2-digit', day: '2-digit', year: '2-digit' })} · ${activeCount} active container moves · ${criticalCount} approaching demurrage cutoff`}
      >
        <button type="button" onClick={() => setRouteBuilderOpen(true)} className="inline-flex min-h-9 items-center gap-2 rounded-md bg-amber-400 px-3 text-xs font-bold text-slate-950 shadow-sm transition-colors hover:bg-amber-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"><Zap className="size-4" aria-hidden />9-Step Smart Route Builder</button>
        <label className="flex items-center gap-2 text-[10px] text-muted-foreground"><span className="sr-only">Preview role</span><ShieldCheck className="size-3.5" aria-hidden /><select aria-label="Preview role (not an authenticated permission)" value={accessRole} onChange={(event) => setAccessRole(event.target.value as typeof accessRole)} className="h-9 rounded-md border border-input bg-background px-2 text-xs font-medium text-foreground"><option>Dispatcher</option><option>Admin / Owner</option><option>Driver</option></select></label>
      </PageHeader>

      {podAlert && podAlert.podReceipt && podAlert.podSignedAtIso && <section role="alert" aria-live="assertive" className="mx-3 mt-3 rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-4 shadow-md">
        <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="flex items-center gap-2 font-bold text-emerald-900 dark:text-emerald-100"><span className="size-2 animate-pulse rounded-full bg-emerald-500" aria-hidden />🔔 New Signed POD Received: Container {podAlert.container} · Signed by {podAlert.podReceipt.receiverName}</p><p className="mt-1 text-sm">Driver: {podAlert.driver ?? 'Unassigned'} · Time: {podAlert.podSignedAt}</p><p className="mt-1 font-mono text-xs font-semibold text-emerald-800 dark:text-emerald-200">Confirmation Code: {podAlert.podConfirmationCode}</p></div><button type="button" onClick={dismissPodAlert} className="min-h-10 rounded-md border border-border bg-background px-3 text-xs font-semibold hover:bg-muted">Dismiss Alert</button></div>
        <div className="mt-3 flex flex-wrap gap-2"><button type="button" onClick={() => setPodPreviewLoadId(podAlert.id)} className="inline-flex min-h-10 items-center gap-2 rounded-md bg-primary px-3 text-xs font-semibold text-primary-foreground hover:bg-primary/90"><Eye className="size-4" aria-hidden />View Signed POD</button><button type="button" onClick={() => setView('billing')} className="min-h-10 rounded-md border border-primary/30 bg-background px-3 text-xs font-semibold text-primary hover:bg-primary/5">Open Load in Billing Review</button></div>
      </section>}
      <p className="border-b border-amber-300/60 bg-amber-50 px-4 py-1.5 text-[10px] text-amber-950 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-100">Preview role is a UI demonstration only; authentication, server authorization, encryption, and durable audit storage are not connected.</p>
      {podAuditLog.length > 0 && <details className="border-b border-border px-4 py-2"><summary className="cursor-pointer text-xs font-semibold">Admin override audit log ({podAuditLog.length})</summary><ul className="mt-2 space-y-1 text-[10px] text-muted-foreground">{podAuditLog.map((entry) => <li key={entry.id}>{entry.at} · {entry.actor} · Load {entry.loadId} · {entry.action} · Reason: {entry.reason}</li>)}</ul></details>}

      <div className="border-b border-border bg-muted/30 px-4 py-1.5">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Tacoma Staging Yard · Off-Dock Storage &amp; Pre-Pull</p>
      </div>

      <section aria-label="Port terminal filters" className="grid grid-cols-2 gap-px border-b border-border lg:grid-cols-4 xl:grid-cols-8">
        <TerminalTile
          label="All"
          sub="Seattle + Tacoma"
          count={counts.All}
          active={filter === 'All'}
          onClick={() => setFilter('All')}
        />
        {TERMINALS.map((t) => (
          <TerminalTile
            key={t.code}
            label={t.code}
            sub={`${t.name}`}
            count={counts[t.code] ?? 0}
            gate={t.gate}
            turnMin={t.turnMin}
            active={filter === t.code}
            onClick={() => setFilter(t.code)}
          />
        ))}
      </section>

      {activeRouteChain && <section aria-label="Active chained route" className="flex flex-wrap items-center justify-between gap-3 border-b border-emerald-700/20 bg-emerald-500/5 px-4 py-2.5"><div className="flex items-center gap-2"><BadgeCheck className="size-4 text-emerald-700 dark:text-emerald-300" aria-hidden /><p className="text-xs font-semibold">Dual-Mission Verified · Zero Empty Bobtail</p><p className="hidden text-[10px] text-muted-foreground sm:block">{activeRouteChain.container} · Driver {activeRouteChain.driver} · 3 legs</p></div><button type="button" onClick={() => setRouteBuilderOpen(true)} className="min-h-9 rounded-md border border-primary/30 px-3 text-xs font-semibold text-primary hover:bg-primary/5">View chained route</button></section>}

      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-card px-4 py-2">
        <label className="relative flex min-w-56 flex-1 items-center md:max-w-xs">
          <span className="sr-only">Search loads</span>
          <Search className="pointer-events-none absolute left-2 size-3.5 text-muted-foreground" aria-hidden />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Load #, container, customer, driver"
            className="h-8 w-full rounded-md border border-input bg-background pl-7 pr-2 text-xs outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </label>
        <p className="font-mono text-[11px] text-muted-foreground">
          {rows.length} of {loads.length} loads · {filter === 'All' ? 'all terminals' : filter}
        </p>
      </div>

      <div className="border-b border-border bg-muted/30 px-3 py-2">
        <div className="mb-2 flex flex-wrap items-end gap-3 rounded-md border border-border bg-card px-3 py-2">
          <div className="mr-auto flex items-center gap-2">
            <CalendarDays className="size-4 text-primary" aria-hidden />
            <div>
              <p className="text-xs font-semibold">Report date range</p>
              <p className="text-[10px] text-muted-foreground">Filters the dispatch report by POD date · {filteredReportRows.length} of {reportRows.length} rows</p>
            </div>
          </div>
          <label className="grid gap-1 text-[10px] font-medium text-muted-foreground">From
            <input aria-label="Report start date" type="date" value={reportStartDate} max={reportEndDate || undefined} onChange={(event) => setReportStartDate(event.target.value)} className="h-8 rounded-md border border-input bg-background px-2 text-xs text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" />
          </label>
          <label className="grid gap-1 text-[10px] font-medium text-muted-foreground">To
            <input aria-label="Report end date" type="date" value={reportEndDate} min={reportStartDate || undefined} onChange={(event) => setReportEndDate(event.target.value)} className="h-8 rounded-md border border-input bg-background px-2 text-xs text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" />
          </label>
          {(reportStartDate || reportEndDate) && <button type="button" onClick={() => { setReportStartDate(''); setReportEndDate('') }} className="h-8 rounded-md border border-border px-2.5 text-xs font-medium hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">Clear range</button>}
        </div>
        <ReportExportToolbar
          fileName="ephrata-weekly-dispatch"
          sheetName="Port Drayage Dispatch"
          reportTitle="Commercial Port Drayage Dispatch & Terminal Report"
          headers={reportHeaders}
          rows={filteredReportRows}
          excelLabel="Download Weekly Dispatch Excel"
        />
      </div>

      <div className="min-h-0 flex-1 overflow-auto bg-card">
        <table className="w-full min-w-[1120px] border-collapse text-xs">
          <thead className="sticky top-0 z-10 bg-muted text-left">
            <tr className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              {['Load #', 'Container / B/L', 'DO #', 'PO #', 'Size', 'Type', 'Port Terminal', 'SSL', 'Customer / Delivery', 'Driver', 'Chat', 'Truck · Chassis', 'Appointment', 'Last Free Day (LFD) Demurrage Cutoff', 'Days Past Free Time', 'Weight', 'Status', 'POD', 'Track', 'Email package', 'Admin controls'].map(
                (h) => (
                  <th key={h} scope="col" className="whitespace-nowrap border-b border-border px-2.5 py-2 font-medium">
                    {h}
                  </th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {rows.map((l) => {
              const lfdRisk = l.status !== 'Delivered' && isWithinLfdWindow(l.lfd, now)
              const refs = loadReferences(l)
              const daysPastFreeTime = calculateDaysPastLfd(l.lfd, l.podSignedAtIso ? new Date(l.podSignedAtIso) : now)
              const isSignatureLoad = l.id === '106381'
              return (
                <tr
                  key={l.id}
                  className={cn(
                    'border-b border-border/70 transition-colors hover:bg-muted/60',
                    lfdRisk && 'bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/35',
                    !lfdRisk && isSignatureLoad && !l.podSigned && 'bg-accent/10',
                    podAlertLoadId === l.id && 'animate-pulse bg-emerald-100/80 dark:bg-emerald-950/40',
                  )}
                >
                  <LoadCell load={l} field="id" value={l.id} onOpen={() => { setEmailLoadId(null); setInvoiceLoadId(l.id) }} className="whitespace-nowrap font-mono font-semibold text-foreground" />
                  <td className="whitespace-nowrap px-2.5 py-1.5 font-mono">
                    {l.podSigned ? <span className="block font-semibold">{l.container}</span> : <EditableCell value={l.container} label={`Load ${l.id} container`} onCommit={(value) => updateLoad(l.id, 'container', value)} className="block font-semibold" />}
                    <span className="text-[10px] text-muted-foreground">B/L: </span>
                    {l.podSigned ? <span className="text-[10px] text-muted-foreground">{refs.billOfLading}</span> : <EditableCell value={refs.billOfLading} label={`Load ${l.id} bill of lading`} onCommit={(value) => updateLoad(l.id, 'billOfLading', value)} className="text-[10px] text-muted-foreground" />}
                  </td>
                  <LoadCell load={l} field="deliveryOrder" value={refs.deliveryOrder} className="font-mono" />
                  <LoadCell load={l} field="poNumber" value={refs.poNumber} className="font-mono" />
                  <LoadCell load={l} field="size" value={l.size} className="font-mono text-muted-foreground" />
                  <td className="whitespace-nowrap px-2.5 py-1.5">
                    <label className="relative inline-flex max-w-full items-center">
                      <span className="sr-only">Move type for load {l.id}</span>
                      <select
                        aria-label={`Move type for load ${l.id}`}
                        value={l.moveType ?? defaultDispatchMoveType(l.type)}
                        onChange={(event) => updateLoad(l.id, 'moveType', event.target.value)}
                        className="min-h-8 max-w-full cursor-pointer appearance-none rounded-full border border-primary/25 bg-primary/5 py-1 pl-2.5 pr-7 text-[10px] font-semibold text-primary outline-none hover:bg-primary/10 focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        {DISPATCH_MOVE_TYPE_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.value}</option>)}
                      </select>
                      <ChevronDown className="pointer-events-none absolute right-2 size-3 text-primary" aria-hidden />
                    </label>
                  </td>
                  <LoadCell load={l} field="terminal" value={l.terminal} className="font-mono font-semibold text-primary" />
                  <LoadCell load={l} field="line" value={l.line} className="whitespace-nowrap text-muted-foreground" />
                  <td className="max-w-64 px-2.5 py-1.5">
                    {l.podSigned ? <span className="block truncate font-medium text-foreground">{l.customer}</span> : <EditableCell value={l.customer} label={`Load ${l.id} customer`} onCommit={(value) => updateLoad(l.id, 'customer', value)} className="truncate font-medium text-foreground" />}
                    {l.podSigned ? <span className="block truncate text-[11px] text-muted-foreground">{l.destination}</span> : <EditableCell value={l.destination} label={`Load ${l.id} delivery address`} onCommit={(value) => updateLoad(l.id, 'destination', value)} className="block truncate text-[11px] text-muted-foreground" />}
                  </td>
                  <LoadCell load={l} field="driver" value={l.driver ?? ''} className="whitespace-nowrap" />
                  <td className="whitespace-nowrap px-2.5 py-1.5">{l.driver ? <DriverChatLauncher loadId={l.id} compact /> : <span className="text-[10px] text-muted-foreground">—</span>}</td>
                  <td className="whitespace-nowrap px-2.5 py-1.5 font-mono text-[11px] text-muted-foreground">
                    {l.podSigned ? <span>{l.truck ?? '—'}</span> : <EditableCell value={l.truck ?? ''} label={`Load ${l.id} truck`} onCommit={(value) => updateLoad(l.id, 'truck', value)} />}
                    <span aria-hidden> · </span>
                    {l.podSigned ? <span>{l.chassis}</span> : <EditableCell value={l.chassis} label={`Load ${l.id} chassis`} onCommit={(value) => updateLoad(l.id, 'chassis', value)} />}
                  </td>
                  <td className="whitespace-nowrap px-2.5 py-1.5">
                    <span className="block font-mono text-[11px]">{l.terminalAppointment ? `${l.terminalAppointment.date} · ${l.terminalAppointment.timeSlot}` : l.appt}</span>
                    {l.appointmentWindow && !/\(Window:/i.test(l.appt) && <span className="mt-1 block text-[10px] text-muted-foreground">Window: {l.appointmentWindow}</span>}
                    {l.dispatchNotes && <span className="mt-1 block max-w-56 whitespace-normal text-[10px] font-medium text-amber-800 dark:text-amber-200">{l.dispatchNotes}</span>}
                    {l.terminalAppointment && <span className="mt-1 block max-w-48 truncate text-[10px] text-muted-foreground" title={`${l.terminalAppointment.moveType} · ${l.terminalAppointment.terminal}`}>{l.terminalAppointment.moveType} · {l.terminalAppointment.terminal}</span>}
                    {l.terminalAppointment && <span className="mt-1 inline-flex items-center rounded bg-amber-500/10 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-amber-900 dark:text-amber-200">Preview PIN {l.terminalAppointment.pin}</span>}
                    <button type="button" onClick={() => setAppointmentLoadId(l.id)} className="mt-1 block min-h-8 rounded border border-primary/30 px-2 text-[10px] font-semibold text-primary hover:bg-primary/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{l.terminalAppointment ? 'Edit appointment preview' : 'Open eModal preview'}</button>
                  </td>
                  <td className="whitespace-nowrap px-2.5 py-1.5">
                    {l.podSigned ? <span className={cn('font-mono', lfdRisk && 'font-semibold text-red-900 dark:text-red-200')}>{l.lfd}</span> : <EditableCell value={l.lfd} label={`Load ${l.id} Last Free Day (LFD) Demurrage Cutoff`} onCommit={(value) => updateLoad(l.id, 'lfd', value)} className={cn('font-mono', lfdRisk && 'font-semibold text-red-900 dark:text-red-200')} />}
                    {lfdRisk && <span className="mt-1 flex w-fit animate-pulse items-center gap-1 rounded-sm border border-red-300 bg-red-100 px-1.5 py-1 font-mono text-[9px] font-bold leading-tight text-red-900 dark:border-red-800 dark:bg-red-950 dark:text-red-100">⚠️ LAST FREE DAY (LFD) CUTOFF APPROACHING (&lt; 24 HRS) · DEMURRAGE RISK</span>}
                  </td>
                  <td className="whitespace-nowrap px-2.5 py-1.5 text-right font-mono text-muted-foreground" aria-label={`${daysPastFreeTime} days past free time`}>
                    {daysPastFreeTime}
                  </td>
                  <td className="whitespace-nowrap px-2.5 py-1.5 text-right font-mono text-muted-foreground">
                    {l.podSigned ? <span>{l.weightLbs.toLocaleString()}</span> : <EditableCell value={l.weightLbs.toLocaleString()} label={`Load ${l.id} weight in pounds`} align="right" onCommit={(value) => updateLoad(l.id, 'weightLbs', value)} />}
                  </td>
                  {l.podSigned ? <td className="whitespace-nowrap px-2.5 py-1.5"><span className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">🟢 Delivered &amp; Signed</span></td> : <LoadCell load={l} field="status" value={l.status} className="whitespace-nowrap font-medium" />}
                  <td className="whitespace-nowrap px-2.5 py-1.5">
                    {l.podSigned ? (
                      <div className="flex flex-col items-start gap-1">
                        <span className="inline-flex items-center gap-1 text-success">
                          <FileCheck2 className="size-3.5" aria-hidden />
                          <span className="font-mono text-[11px]">e-POD {l.podSignedAt}</span>
                        </span>
                        {l.podReceipt && <span className="max-w-40 truncate text-[9px] text-muted-foreground" title={`${l.podReceipt.receiverName} · ${l.podReceipt.companyName}`}>{l.podReceipt.receiverName} · {l.podReceipt.companyName}</span>}
                        {l.podConfirmationCode && <span className="inline-flex items-center gap-1 font-mono text-[9px] font-semibold text-emerald-700 dark:text-emerald-300"><FileDown className="size-3" aria-hidden />{l.podConfirmationCode}</span>}
                        <button type="button" onClick={() => setPodPreviewLoadId(l.id)} aria-label={`View signed POD for load ${l.id}`} className="inline-flex cursor-pointer items-center gap-1 rounded-sm bg-emerald-100 px-1.5 py-1 text-[9px] font-semibold text-emerald-800 hover:bg-emerald-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring dark:bg-emerald-950/50 dark:text-emerald-200 dark:hover:bg-emerald-900/60"><Eye className="size-3" aria-hidden />📄 View Signed POD</button>
                        <span className="inline-flex items-center gap-1 text-[9px] font-semibold text-emerald-700 dark:text-emerald-300"><Mail className="size-3" aria-hidden />POD attached · Ready to Invoice</span>
                      </div>
                    ) : isSignatureLoad ? (
                      <button
                        type="button"
                        onClick={() => setView('driver')}
                        className="inline-flex items-center gap-1 rounded-sm border border-primary/30 px-1.5 py-px text-[11px] font-medium text-primary hover:bg-primary/5"
                      >
                        <Smartphone className="size-3" aria-hidden />
                        Awaiting sign
                      </button>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-2.5 py-1.5">
                    <button type="button" onClick={() => openTracking(l.id)} className="inline-flex items-center gap-1 rounded-sm border border-primary/30 px-1.5 py-px text-[11px] font-medium text-primary hover:bg-primary/5">
                      <Globe2 className="size-3" aria-hidden /> Track
                    </button>
                  </td>
                  <td className="whitespace-nowrap px-2.5 py-1.5">
                    {l.podSigned ? (
                      <button type="button" onClick={() => { setInvoiceLoadId(null); setEmailLoadId(l.id) }} aria-label={`Prepare signed POD email for load ${l.id}`} className="inline-flex items-center gap-1 rounded-sm bg-[#1b4d89] px-2 py-1 text-[10px] font-semibold text-white hover:bg-[#153a67] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                        <Mail className="size-3" aria-hidden /> Email signed POD
                      </button>
                    ) : <span className="text-[10px] text-muted-foreground">Awaiting signed POD</span>}
                  </td>
                  <td className="whitespace-nowrap px-2.5 py-1.5"><AdminPodControls load={l} /></td>
                </tr>
              )
            })}
            {rows.length === 0 && (
              <tr>
                <td colSpan={21} className="px-3 py-10 text-center text-muted-foreground">
                  No loads match this filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {emailLoad && <EmailClientPackage key={`email-${emailLoad.id}`} load={emailLoad} onClose={() => setEmailLoadId(null)} />}
      {podPreviewLoad?.podReceipt && podPreviewLoad.podSignedAtIso && <DeliveryReceiptPreview load={podPreviewLoad} receipt={podPreviewLoad.podReceipt} signedAt={new Date(podPreviewLoad.podSignedAtIso)} onClose={() => setPodPreviewLoadId(null)} />}
      {invoiceLoad && <PcsInvoiceForm key={`invoice-${invoiceLoad.id}`} load={invoiceLoad} onClose={() => setInvoiceLoadId(null)} />}
      {appointmentLoad && <EmodalAppointmentModal key={`appointment-${appointmentLoad.id}`} loads={loads} initialLoadId={appointmentLoad.id} onSave={saveTerminalAppointment} onClose={() => setAppointmentLoadId(null)} />}
      <RouteBuilderDialog
        open={routeBuilderOpen}
        onClose={() => setRouteBuilderOpen(false)}
        onBuildPreset={(route) => { setActiveRouteChain(route); setOptimizedLoadOrder(true) }}
        onOptimize={() => setOptimizedLoadOrder(true)}
        onOpenDriver={() => { setRouteBuilderOpen(false); setView('driver') }}
        routeReady={Boolean(activeRouteChain)}
        goldenLoadCount={loads.filter((load) => /golden\s+intl/i.test(load.customer)).length}
      />
    </div>
  )
}

function AdminPodControls({ load }: { load: Load }) {
  const { accessRole, updateLoad, recordPodAudit, voidPod } = useTms()
  if (accessRole !== 'Admin / Owner') return <span className="text-[10px] text-muted-foreground">Admin / Owner only</span>

  const editDetails = () => {
    const reason = window.prompt('Admin override reason (required):')?.trim()
    if (!reason) return
    const customer = window.prompt('Update consignee / customer:', load.customer)
    if (customer === null) return
    const destination = window.prompt('Update delivery destination:', load.destination)
    if (destination === null) return
    const seal = window.prompt('Update seal number:', load.seal)
    if (seal === null) return
    updateLoad(load.id, 'customer', customer)
    updateLoad(load.id, 'destination', destination)
    updateLoad(load.id, 'seal', seal)
    recordPodAudit(load.id, 'Edited delivery details', reason)
  }

  const voidRecord = () => {
    const reason = window.prompt('Admin override reason for void (required):')?.trim()
    if (!reason || !window.confirm(`Place load ${load.id} on hold and mark its POD void? The archived record will be retained.`)) return
    voidPod(load.id, reason)
  }

  return <div className="flex flex-col items-start gap-1"><button type="button" onClick={editDetails} className="min-h-8 rounded border border-primary/30 px-2 text-[10px] font-semibold text-primary hover:bg-primary/5">Edit Delivery Details</button><button type="button" onClick={voidRecord} disabled={load.podVoided} className="min-h-8 rounded border border-destructive/30 px-2 text-[10px] font-semibold text-destructive hover:bg-destructive/5 disabled:opacity-50">{load.podVoided ? 'Voided / on hold' : 'Delete / Void Record'}</button></div>
}

function getNextLfdTimestamp(lfd: string, now: Date) {
  const match = /^(\d{2})\/(\d{2})$/.exec(lfd)
  if (!match) return Number.POSITIVE_INFINITY
  let cutoff = new Date(now.getFullYear(), Number(match[1]) - 1, Number(match[2]), 17, 0, 0).getTime()
  if (cutoff < now.getTime() - 183 * 24 * 60 * 60 * 1000) cutoff = new Date(now.getFullYear() + 1, Number(match[1]) - 1, Number(match[2]), 17, 0, 0).getTime()
  return cutoff
}

function getNextAppointmentTimestamp(appointment: string, now: Date, date?: string) {
  const match = /(\d{1,2}):(\d{2})(?:\s*(AM|PM))?/i.exec(appointment.trim())
  if (!match) return Number.POSITIVE_INFINITY
  let hour = Number(match[1])
  const minute = Number(match[2])
  if (match[3]) hour = hour % 12 + (match[3].toUpperCase() === 'PM' ? 12 : 0)
  if (hour > 23 || minute > 59) return Number.POSITIVE_INFINITY
  const dateMatch = date?.match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?$/)
  const dateYear = dateMatch?.[3] ? Number(dateMatch[3].length === 2 ? `20${dateMatch[3]}` : dateMatch[3]) : now.getFullYear()
  const baseDate = dateMatch
    ? new Date(dateYear, Number(dateMatch[1]) - 1, Number(dateMatch[2]))
    : date ? new Date(date) : now
  if (Number.isNaN(baseDate.getTime())) return Number.POSITIVE_INFINITY
  const cutoff = new Date(baseDate.getFullYear(), baseDate.getMonth(), baseDate.getDate(), hour, minute).getTime()
  if (date) return cutoff
  return cutoff >= now.getTime() ? cutoff : cutoff + 24 * 60 * 60 * 1000
}

function isWithinLfdWindow(lfd: string, now: Date) {
  const match = /^(\d{2})\/(\d{2})$/.exec(lfd)
  if (!match) return false
  const month = Number(match[1])
  const day = Number(match[2])
  let cutoff = new Date(now.getFullYear(), month - 1, day, 17, 0, 0)
  if (cutoff.getTime() < now.getTime() - 183 * 24 * 60 * 60 * 1000) {
    cutoff = new Date(now.getFullYear() + 1, month - 1, day, 17, 0, 0)
  }
  return cutoff.getTime() - now.getTime() <= 24 * 60 * 60 * 1000
}

function LoadCell({ load, field, value, onOpen, className = '' }: { load: Load; field: keyof Load; value: string; onOpen?: () => void; className?: string }) {
  const { updateLoad } = useTms()
  const locked = load.podSigned
  return (
    <td className={cn('whitespace-nowrap px-2.5 py-1.5', className)}>
      {locked ? onOpen ? <button type="button" onClick={onOpen} className="font-mono font-semibold text-foreground underline decoration-dotted underline-offset-2">{value}</button> : <span>{value || '—'}</span> : onOpen ? (
        <ClickableEditableCell value={value} label={`Load ${load.id}`} openLabel={`Open invoice for load ${load.id}`} onOpen={onOpen} onCommit={(nextValue) => updateLoad(load.id, field, nextValue)} />
      ) : (
        <EditableCell value={value} label={`Load ${load.id} ${String(field)}`} onCommit={(nextValue) => updateLoad(load.id, field, nextValue)} />
      )}
    </td>
  )
}

function TerminalTile({
  label,
  sub,
  count,
  gate,
  turnMin,
  active,
  onClick,
}: {
  label: string
  sub: string
  count: number
  gate?: 'Open' | 'Congested' | 'Closed'
  turnMin?: number
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'flex flex-col gap-1 px-4 py-2.5 text-left transition-colors',
        active ? 'bg-primary text-primary-foreground' : 'bg-card hover:bg-muted',
      )}
    >
      <span className="flex items-baseline justify-between gap-2">
        <span className="font-mono text-sm font-bold">{label}</span>
        <span className="font-mono text-sm tabular-nums">{count}</span>
      </span>
      <span className={cn('truncate text-[11px]', active ? 'text-primary-foreground/70' : 'text-muted-foreground')}>
        {sub}
      </span>
      {gate && (
        <span className={cn('flex items-center gap-1.5 font-mono text-[10px]', active ? 'text-primary-foreground/80' : 'text-muted-foreground')}>
          <span
            className={cn('size-1.5 rounded-full', gate === 'Open' ? 'bg-success' : 'bg-accent')}
            aria-hidden
          />
          Gate {gate.toLowerCase()} · {turnMin}m turn
        </span>
      )}
    </button>
  )
}
