'use client'

import { Check, Clipboard, FileCheck2, MapPin, Truck, X } from 'lucide-react'
import { useState } from 'react'
import { formatUsd, loadTotal } from '@/lib/tms-data'
import { useTms } from './tms-store'

export function TrackingPortal() {
  const { loads, trackingLoadId, closeTracking } = useTms()
  const [copied, setCopied] = useState(false)
  const load = loads.find((item) => item.id === trackingLoadId)

  if (!trackingLoadId || !load) return null

  const delivered = load.status === 'Delivered' || load.podSigned
  const milestones = [
    { label: 'Dispatched from Kent yard', time: '10:05 AM', complete: true },
    { label: `Out-gated ${load.terminal}`, time: '11:48 AM', complete: true },
    { label: `En route to ${load.customer}`, time: '12:16 PM', complete: true },
    { label: 'Delivered · proof of delivery', time: load.podSignedAt ?? 'Pending', complete: delivered },
  ]

  const copyTrackingLink = async () => {
    try {
      await navigator.clipboard.writeText(load.id)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    } catch {
      setCopied(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/65 p-3 backdrop-blur-sm" onMouseDown={(event) => event.target === event.currentTarget && closeTracking()}>
      <section role="dialog" aria-modal="true" aria-labelledby="tracking-title" className="my-auto w-full max-w-xl overflow-hidden rounded-lg border border-border bg-card shadow-2xl">
        <header className="flex items-start justify-between gap-4 bg-sidebar px-5 py-4 text-sidebar-foreground">
          <div>
            <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-sidebar-primary">AAA Intermodal · Customer portal</p>
            <h2 id="tracking-title" className="mt-1 text-lg font-semibold">Shipment tracking</h2>
            <p className="mt-0.5 font-mono text-xs text-sidebar-foreground/70">Load #{load.id} · {load.container}</p>
          </div>
          <button type="button" aria-label="Close tracking portal" onClick={closeTracking} className="rounded p-1 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring">
            <X className="size-4" aria-hidden />
          </button>
        </header>

        <div className="grid gap-4 p-5 sm:grid-cols-[1fr_0.8fr]">
          <div>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[10px] font-medium uppercase tracking-widest text-muted-foreground">Current status</p>
                <p className="mt-1 text-sm font-semibold">{delivered ? 'Delivered' : load.status}</p>
              </div>
              <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium ${delivered ? 'bg-success/10 text-success' : 'bg-accent/20 text-foreground'}`}>
                <span className={`size-1.5 rounded-full ${delivered ? 'bg-success' : 'bg-accent'}`} aria-hidden />
                {delivered ? 'Complete' : 'In progress'}
              </span>
            </div>

            <ol className="mt-5 space-y-0" aria-label="Shipment milestones">
              {milestones.map((milestone, index) => (
                <li key={milestone.label} className="relative flex gap-3 pb-5 last:pb-0">
                  {index < milestones.length - 1 && <span className={`absolute left-[7px] top-4 h-full w-px ${milestone.complete ? 'bg-success/40' : 'bg-border'}`} aria-hidden />}
                  <span className={`relative z-10 mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-full border ${milestone.complete ? 'border-success bg-success text-success-foreground' : 'border-border bg-background text-muted-foreground'}`}>
                    {milestone.complete ? <Check className="size-2.5" aria-hidden /> : <span className="size-1 rounded-full bg-current" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-xs font-medium">{milestone.label}</span>
                    <span className="mt-0.5 block font-mono text-[10px] text-muted-foreground">{milestone.time}</span>
                  </span>
                </li>
              ))}
            </ol>
          </div>

          <aside className="rounded-md border border-border bg-muted/40 p-3.5">
            <p className="font-mono text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Shipment details</p>
            <dl className="mt-3 space-y-3 text-xs">
              <div className="flex gap-2"><Truck className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" aria-hidden /><div><dt className="text-[10px] text-muted-foreground">Equipment</dt><dd className="font-mono font-medium">{load.size} · {load.container}</dd></div></div>
              <div className="flex gap-2"><MapPin className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" aria-hidden /><div><dt className="text-[10px] text-muted-foreground">Delivery</dt><dd className="font-medium">{load.destination}</dd></div></div>
              <div><dt className="text-[10px] text-muted-foreground">Customer</dt><dd className="mt-0.5 font-medium">{load.customer}</dd></div>
              <div><dt className="text-[10px] text-muted-foreground">Driver</dt><dd className="mt-0.5 font-medium">{load.driver ?? 'Dispatch will assign a driver'}</dd></div>
              <div><dt className="text-[10px] text-muted-foreground">Freight total</dt><dd className="mt-0.5 font-mono font-semibold">{formatUsd(loadTotal(load))}</dd></div>
            </dl>
          </aside>
        </div>

        <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-border bg-muted/30 px-5 py-3">
          <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <FileCheck2 className="size-3.5" aria-hidden />
            {load.podSigned ? `e-POD signed ${load.podSignedAt ?? ''}` : 'e-POD available after delivery'}
          </span>
          <div className="flex items-center gap-2">
            <button type="button" onClick={copyTrackingLink} className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              {copied ? <Check className="size-3.5 text-success" aria-hidden /> : <Clipboard className="size-3.5" aria-hidden />}
              {copied ? 'Reference copied' : 'Copy load reference'}
            </button>
            <button type="button" onClick={closeTracking} className="inline-flex items-center gap-1.5 rounded-md bg-primary px-2.5 py-1.5 text-xs font-medium text-primary-foreground hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              Close
            </button>
          </div>
        </footer>
      </section>
    </div>
  )
}

