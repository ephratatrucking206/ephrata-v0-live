'use client'

import { useEffect, useRef, useState, type KeyboardEvent, type PointerEvent } from 'react'
import { ArrowLeft, CalendarDays, Check, CheckCircle2, ClipboardCheck, Clock3, Container, Copy, Download, Eraser, Eye, FileCheck2, FileSignature, LockKeyhole, Mail, MapPin, MessageCircle, PenLine, PhoneCall, RotateCcw, Share2, Signal, Wifi } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useTms } from './tms-store'
import { PageHeader } from './page-header'
import { DriverDailyDispatch, DriverDotLog } from './driver-paperwork'
import { createDeliveryReceiptPdf, downloadDeliveryReceiptPdf } from '@/lib/delivery-documents'
import { DeliveryReceiptPreview } from './delivery-receipt-preview'
import { defaultDispatchMoveType, defaultEmodalMoveType, DISPATCH_MOVE_TYPE_OPTIONS, dispatchMoveTypeLabel, EVERPORT_TERMINAL_NAME, SIGNATURE_LOAD_ID, type Load, type PodReceiptDetails, type RouteChain } from '@/lib/tms-data'

type DriverTab = 'active' | 'dvir' | 'dot'

const issuedPodCodes = new Set<string>()

const tabs: { id: DriverTab; label: string; shortLabel: string; icon: typeof MapPin }[] = [
  { id: 'active', label: 'Consignee Delivery Receipt & Proof of Delivery', shortLabel: 'e-POD', icon: MapPin },
  { id: 'dvir', label: '📋 Driver DVIR & Trip Sheet', shortLabel: 'DVIR', icon: ClipboardCheck },
  { id: 'dot', label: 'FMCSA 24-Hour Record of Duty Status (RODS - Form 613-MP)', shortLabel: 'RODS', icon: Clock3 },
]

export function DriverMobileView() {
  const { setView, loads, signPod, resetDemo, openDriverChat, updateLoad, activeRouteChain } = useTms()
  const activeLoad = loads.find((load) => load.id === SIGNATURE_LOAD_ID)
  const [activeTab, setActiveTab] = useState<DriverTab>('active')
  const [signatureOpen, setSignatureOpen] = useState(false)
  const [signatureCaptured, setSignatureCaptured] = useState(false)
  const [signatureImage, setSignatureImage] = useState<string | null>(activeLoad?.podReceipt?.signatureDataUrl ?? null)
  const [signedAt, setSignedAt] = useState<Date | null>(activeLoad?.podSignedAtIso ? new Date(activeLoad.podSignedAtIso) : null)
  const [podCode, setPodCode] = useState(activeLoad?.podConfirmationCode ?? '')
  const [clockNow, setClockNow] = useState(() => new Date())
  const [timeIn, setTimeIn] = useState<Date | null>(null)
  const [receiverCompany, setReceiverCompany] = useState(activeLoad ? `${activeLoad.customer} - ${activeLoad.destination}` : '')
  const [receiverName, setReceiverName] = useState('')
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const tabRefs = useRef<Array<HTMLButtonElement | null>>([])

  useEffect(() => {
    const timer = window.setInterval(() => setClockNow(new Date()), 1000)
    return () => window.clearInterval(timer)
  }, [])

  const completePod = () => {
    const canvas = canvasRef.current
    if (!canvas || !activeLoad || !signatureCaptured || !receiverCompany.trim() || !receiverName.trim()) return
    const completedAt = new Date()
    const completionTime = formatTime(completedAt)
    const confirmationCode = createPodConfirmationCode(completedAt, activeLoad.id === SIGNATURE_LOAD_ID ? '94821' : undefined)
    const receipt: PodReceiptDetails = {
      moveType: activeLoad.moveType ?? defaultDispatchMoveType(activeLoad.type),
      timeIn: formatTime(timeIn ?? completedAt),
      timeOut: completionTime,
      receiverName: receiverName.trim(),
      companyName: receiverCompany.trim(),
      dropStatus: 'Stay With',
      signatureDataUrl: canvas.toDataURL('image/png'),
      confirmationCode,
    }
    signPod(activeLoad.id, receipt, completedAt, confirmationCode)
    setPodCode(confirmationCode)
    setSignatureImage(receipt.signatureDataUrl)
    setSignedAt(completedAt)
    setSignatureOpen(false)
  }

  const pointOnCanvas = (event: PointerEvent<HTMLCanvasElement>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    return { x: (event.clientX - rect.left) * (event.currentTarget.width / rect.width), y: (event.clientY - rect.top) * (event.currentTarget.height / rect.height) }
  }

  const startSignature = (event: PointerEvent<HTMLCanvasElement>) => {
    const canvas = event.currentTarget
    const context = canvas.getContext('2d')
    if (!context) return
    canvas.setPointerCapture(event.pointerId)
    const point = pointOnCanvas(event)
    context.beginPath()
    context.moveTo(point.x, point.y)
    context.lineWidth = 4
    context.lineCap = 'round'
    context.lineJoin = 'round'
    context.strokeStyle = '#17365d'
  }

  const drawSignature = (event: PointerEvent<HTMLCanvasElement>) => {
    if (!event.currentTarget.hasPointerCapture(event.pointerId)) return
    const context = event.currentTarget.getContext('2d')
    if (!context) return
    const point = pointOnCanvas(event)
    context.lineTo(point.x, point.y)
    context.stroke()
    setSignatureCaptured(true)
  }

  const clearSignature = () => {
    const canvas = canvasRef.current
    const context = canvas?.getContext('2d')
    if (!canvas || !context) return
    context.clearRect(0, 0, canvas.width, canvas.height)
    setSignatureCaptured(false)
  }

  const handleTabKeyDown = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    const next = event.key === 'ArrowRight' ? (index + 1) % tabs.length : event.key === 'ArrowLeft' ? (index - 1 + tabs.length) % tabs.length : event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : -1
    if (next < 0) return
    event.preventDefault()
    tabRefs.current[next]?.focus()
    setActiveTab(tabs[next].id)
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <PageHeader title="Driver Mobile & DVIR" subtitle="Ephrata Trucking, LLC · Consignee receipts · FMCSA RODS">
        <button type="button" onClick={() => { resetDemo(); setActiveTab('active'); setSignatureOpen(false); setSignatureCaptured(false); setSignatureImage(null); setSignedAt(null); setPodCode(''); setReceiverName(''); setReceiverCompany(activeLoad ? `${activeLoad.customer} - ${activeLoad.destination}` : ''); setTimeIn(null); clearSignature() }} className="inline-flex h-9 items-center gap-2 rounded-md border border-border bg-card px-3 text-xs font-medium hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <RotateCcw className="size-3.5" aria-hidden />Reset demo
        </button>
      </PageHeader>

      <div className="flex min-h-0 flex-1 justify-center overflow-hidden p-2 sm:p-4">
        <section aria-label="Driver paperwork phone" className="flex min-h-0 w-full max-w-4xl flex-col rounded-[2.5rem] border-[9px] border-slate-900 bg-slate-950 p-1.5 shadow-2xl ring-1 ring-border sm:border-[12px] sm:p-2">
          <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-[1.8rem] bg-background">
            <div className="flex h-9 shrink-0 items-center justify-between bg-slate-950 px-5 font-mono text-[11px] text-white">
              <span>{formatTime(signedAt ?? clockNow)}</span>
              <span className="flex items-center gap-1.5"><Signal className="size-3" aria-hidden /><Wifi className="size-3" aria-hidden /><span className="ml-1 inline-flex h-2.5 w-5 rounded-sm border border-white/70 p-px"><span className="h-full w-3/4 rounded-[1px] bg-white" /></span></span>
            </div>

            <header className="sticky top-0 z-30 flex shrink-0 flex-wrap items-center justify-between gap-2 border-b border-border bg-background px-3 py-2 shadow-sm">
              <button type="button" onClick={() => setView('dispatch')} className="inline-flex min-h-11 items-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-sm transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                <ArrowLeft className="size-4" aria-hidden />Back to Dispatch / Home
              </button>
              <div className="grid w-full grid-cols-3 gap-2 md:w-auto">
                <a href="tel:+12063728570" className="inline-flex min-h-12 items-center justify-center gap-1.5 rounded-md border border-red-500/40 bg-red-500/10 px-2.5 text-center text-[11px] font-bold text-red-700 hover:bg-red-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring dark:text-red-300"><PhoneCall className="size-4 shrink-0" aria-hidden />Urgent Call Dispatch</a>
                <a href={`sms:+12063728570?body=${encodeURIComponent(`Driver ${activeLoad?.driver ?? 'Asmarew'} | ${activeLoad?.truck ?? 'Unit 387'} | Load Update: `)}`} className="inline-flex min-h-12 items-center justify-center gap-1.5 rounded-md border border-border bg-card px-2.5 text-center text-[11px] font-semibold hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><MessageCircle className="size-4 shrink-0" aria-hidden />SMS Dispatcher</a>
                <button type="button" onClick={() => activeLoad && openDriverChat(activeLoad.id, 'driver')} className="inline-flex min-h-12 items-center justify-center gap-1.5 rounded-md border border-primary/30 bg-primary/5 px-2.5 text-center text-[11px] font-semibold text-primary hover:bg-primary/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><MessageCircle className="size-4 shrink-0" aria-hidden />Dispatch Chat (Live)</button>
              </div>
            </header>

            <div role="tablist" aria-label="Driver paperwork" className="sticky top-0 z-20 grid shrink-0 grid-cols-3 border-b border-border bg-background shadow-sm">
              {tabs.map(({ id, label, shortLabel, icon: Icon }, index) => <button key={id} ref={(element) => { tabRefs.current[index] = element }} id={`driver-tab-${id}`} type="button" role="tab" aria-label={label} aria-selected={activeTab === id} aria-controls={`driver-panel-${id}`} tabIndex={activeTab === id ? 0 : -1} onClick={() => setActiveTab(id)} onKeyDown={(event) => handleTabKeyDown(event, index)} className={cn('flex min-h-[58px] min-w-0 flex-col items-center justify-center gap-1 border-b-2 px-1 text-center text-[10px] font-semibold leading-tight transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring sm:flex-row sm:gap-2 sm:px-3 sm:text-xs', activeTab === id ? 'border-primary bg-primary/5 text-primary' : 'border-transparent text-muted-foreground hover:bg-muted/60 hover:text-foreground')}>
                <Icon className="size-4 shrink-0" aria-hidden /><span className="sm:hidden">{shortLabel}</span><span className="hidden sm:inline">{label}</span>
              </button>)}
            </div>

            <div id="driver-panel-active" role="tabpanel" aria-labelledby="driver-tab-active" hidden={activeTab !== 'active'} className="min-h-0 flex-1 overflow-y-auto">
              <ActiveRunPanel load={activeLoad} routeChain={activeRouteChain} updateLoad={updateLoad} signatureOpen={signatureOpen} setSignatureOpen={setSignatureOpen} signatureCaptured={signatureCaptured} setSignatureCaptured={setSignatureCaptured} signatureImage={signatureImage} signedAt={signedAt} podCode={podCode} clockNow={clockNow} timeIn={timeIn} setTimeIn={setTimeIn} receiverCompany={receiverCompany} setReceiverCompany={setReceiverCompany} receiverName={receiverName} setReceiverName={setReceiverName} onCompletePod={completePod} canvasRef={canvasRef} startSignature={startSignature} drawSignature={drawSignature} clearSignature={clearSignature} />
            </div>
            <div id="driver-panel-dvir" role="tabpanel" aria-labelledby="driver-tab-dvir" hidden={activeTab !== 'dvir'} className="min-h-0 flex-1 overflow-y-auto">
              <DriverDailyDispatch />
            </div>
            <div id="driver-panel-dot" role="tabpanel" aria-labelledby="driver-tab-dot" hidden={activeTab !== 'dot'} className="min-h-0 flex-1 overflow-y-auto">
              <DriverDotLog />
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

function ActiveRunPanel({
  load,
  routeChain,
  updateLoad,
  signatureOpen,
  setSignatureOpen,
  signatureCaptured,
  setSignatureCaptured,
  signatureImage,
  signedAt,
  podCode,
  clockNow,
  timeIn,
  setTimeIn,
  receiverCompany,
  setReceiverCompany,
  receiverName,
  setReceiverName,
  onCompletePod,
  canvasRef,
  startSignature,
  drawSignature,
  clearSignature,
}: {
  load: Load | undefined
  routeChain: RouteChain | null
  updateLoad: (loadId: string, field: keyof Load, value: string) => void
  signatureOpen: boolean
  setSignatureOpen: (open: boolean) => void
  signatureCaptured: boolean
  setSignatureCaptured: (captured: boolean) => void
  signatureImage: string | null
  signedAt: Date | null
  podCode: string
  clockNow: Date
  timeIn: Date | null
  setTimeIn: (time: Date | null) => void
  receiverCompany: string
  setReceiverCompany: (company: string) => void
  receiverName: string
  setReceiverName: (name: string) => void
  onCompletePod: () => void
  canvasRef: React.RefObject<HTMLCanvasElement | null>
  startSignature: (event: PointerEvent<HTMLCanvasElement>) => void
  drawSignature: (event: PointerEvent<HTMLCanvasElement>) => void
  clearSignature: () => void
}) {
  const { loads } = useTms()
  const archivedLoads = loads.filter((candidate) => candidate.podSigned && candidate.podReceipt && candidate.podSignedAtIso)
  const dispatchAppointmentUpdates = loads.filter((candidate) => candidate.appointmentDate || candidate.dispatchNotes)
  const timestamp = signedAt ? formatDateTime(signedAt) : formatDateTime(clockNow)
  const equipmentLocked = Boolean(load?.podSigned || signedAt)

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-4 p-4 sm:p-6">
      {routeChain && <ChainedDriverRun route={routeChain} />}
      <header className="rounded-2xl bg-primary p-5 text-primary-foreground shadow-sm">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground/70">Ephrata Trucking, LLC · Consignee delivery</p>
        <h2 className="mt-2 text-xl font-bold">Consignee Delivery Receipt &amp; Proof of Delivery</h2>
        <p className="mt-1 text-sm text-primary-foreground/80">Document equipment delivery, consignee acceptance, and proof of delivery.</p>
      </header>

      {dispatchAppointmentUpdates.length > 0 && <section aria-label="Dispatch appointment updates" className="rounded-2xl border border-primary/20 bg-primary/5 p-4 shadow-sm"><div className="mb-3 flex items-center gap-2"><CalendarDays className="size-4 text-primary" aria-hidden /><h3 className="font-semibold">Dispatch appointment updates</h3></div><div className="flex flex-col gap-3">{dispatchAppointmentUpdates.map((update) => <article key={update.id} className="rounded-xl border border-border bg-card p-3"><div className="flex flex-wrap items-start justify-between gap-2"><div><p className="font-mono text-sm font-semibold">{update.container}</p><p className="mt-0.5 text-xs text-muted-foreground">{update.customer}</p></div><span className="rounded-full bg-muted px-2 py-1 text-[10px] font-medium text-muted-foreground">{update.status}</span></div><p className="mt-2 font-mono text-xs">{update.appt}</p>{update.appointmentWindow && !/\(Window:/i.test(update.appt) && <p className="mt-1 text-xs text-muted-foreground">Delivery window: {update.appointmentWindow}</p>}{update.dispatchNotes && <p className="mt-2 rounded-lg bg-amber-500/10 px-3 py-2 text-xs font-medium text-amber-900 dark:text-amber-100">{update.dispatchNotes}</p>}</article>)}</div></section>}

      {(load?.terminal === 'Everport' || load?.terminalAppointment?.terminal === EVERPORT_TERMINAL_NAME) && <section aria-label="Everport terminal gate pass" className="rounded-2xl border border-amber-500/40 bg-amber-500/10 p-4 shadow-sm"><p className="text-xs font-bold uppercase tracking-wide text-amber-950 dark:text-amber-100">TERMINAL GATE PASS · {EVERPORT_TERMINAL_NAME.toUpperCase()}</p><div className="mt-3 flex flex-wrap items-center justify-between gap-3"><p className="text-sm font-bold">{load?.terminalAppointment?.terminal === EVERPORT_TERMINAL_NAME ? load.terminalAppointment.moveType : defaultEmodalMoveType(load?.type ?? 'Import')}</p><div className="rounded-lg border border-amber-500/30 bg-background px-3 py-2 text-right"><span className="block text-[9px] font-medium text-muted-foreground">Appointment PIN</span><code className="font-mono text-base font-bold text-amber-900 dark:text-amber-200">{load?.terminalAppointment?.terminal === EVERPORT_TERMINAL_NAME ? load.terminalAppointment.pin : 'Not booked'}</code></div></div></section>}

      {load?.terminalAppointment && <section aria-label="Saved eModal appointment" className="rounded-2xl border border-emerald-700/20 bg-emerald-500/5 p-4 shadow-sm"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="inline-flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide text-amber-800 dark:text-amber-200"><CalendarDays className="size-3.5" aria-hidden />eModal appointment preview</p><p className="mt-1 text-sm font-bold">{load.terminalAppointment.terminal}</p><p className="mt-1 text-xs text-muted-foreground">{load.terminalAppointment.date} · {load.terminalAppointment.timeSlot} · {load.terminalAppointment.moveType}</p><p className="mt-1 text-[10px] text-muted-foreground">{load.terminalAppointment.driverName} · {load.terminalAppointment.container}</p></div><div className="rounded-lg border border-emerald-700/20 bg-background px-3 py-2 text-right"><span className="block text-[9px] font-medium text-muted-foreground">Preview PIN</span><code className="font-mono text-base font-bold text-emerald-800 dark:text-emerald-200">{load.terminalAppointment.pin}</code></div></div></section>}

      <section className="rounded-2xl border border-border bg-card p-4 shadow-sm" aria-labelledby="active-equipment-title">
        <div className="flex items-center gap-2"><Container className="size-5 text-primary" aria-hidden /><h3 id="active-equipment-title" className="font-semibold">Equipment on this run</h3></div>
        <dl className="mt-4 grid grid-cols-2 gap-3">
          {([
            { label: 'Container #', field: 'container', value: load?.container ?? '' },
            { label: 'Chassis #', field: 'chassis', value: load?.chassis ?? '' },
            { label: 'Seal #', field: 'seal', value: load?.seal ?? '' },
            { label: 'B/L #', field: 'billOfLading', value: load?.billOfLading ?? '' },
          ] as const).map(({ label, field, value }) => {
            const locked = equipmentLocked
            return <div key={field} className="min-w-0 rounded-xl bg-muted/50 p-3">
              <dt className="text-xs text-muted-foreground"><label htmlFor={`equipment-${field}`}>{label}</label></dt>
              <dd className="mt-1.5 flex min-w-0 items-center gap-2">
                <input id={`equipment-${field}`} aria-label={label} value={value} onChange={(event) => load && updateLoad(load.id, field, event.currentTarget.value)} readOnly={locked || !load} placeholder="Not recorded" className="h-10 min-w-0 flex-1 rounded-md border border-input bg-background px-2 font-mono text-sm font-semibold text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring read-only:bg-muted/60" />
                <span className={cn('inline-flex shrink-0 items-center gap-1 text-[10px] font-semibold', locked ? 'text-muted-foreground' : 'text-primary')}>
                  {locked ? <><LockKeyhole className="size-3" aria-hidden />Locked</> : <><PenLine className="size-3" aria-hidden />Edit</>}
                </span>
              </dd>
            </div>
          })}
          <div className="col-span-2 min-w-0 rounded-xl bg-muted/50 p-3">
          <dt className="text-xs text-muted-foreground"><label htmlFor="equipment-moveType">Move Type</label></dt>
          <dd className="mt-1.5 flex min-w-0 items-center gap-2">
            <select
              id="equipment-moveType"
              aria-label="Move Type"
              value={load ? load.moveType ?? defaultDispatchMoveType(load.type) : ''}
              onChange={(event) => load && updateLoad(load.id, 'moveType', event.currentTarget.value)}
              disabled={equipmentLocked || !load}
              className="h-10 min-w-0 flex-1 rounded-md border border-input bg-background px-2 text-sm font-semibold text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:bg-muted/60"
            >
              {DISPATCH_MOVE_TYPE_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
            </select>
            <span className={cn('inline-flex shrink-0 items-center gap-1 text-[10px] font-semibold', equipmentLocked ? 'text-muted-foreground' : 'text-primary')}>
              {equipmentLocked ? <><LockKeyhole className="size-3" aria-hidden />Locked</> : <><PenLine className="size-3" aria-hidden />Edit</>}
            </span>
          </dd>
          </div>
        </dl>
        <p className="mt-3 text-xs text-muted-foreground">{load?.podSigned || signedAt ? 'Certified equipment details are locked after e-POD sign-off.' : 'Equipment details can be corrected before delivery sign-off.'}</p>
      </section>

      <section className="rounded-2xl border border-border bg-card p-4 shadow-sm">
        <div className="flex items-start gap-3"><span className="mt-0.5 inline-flex size-9 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"><MapPin className="size-4" aria-hidden /></span><div><p className="font-semibold">Delivery confirmation</p><p className="mt-1 text-sm text-muted-foreground">Review the equipment details, then collect the receiver&apos;s signature.</p></div></div>
        <div className="mt-4 flex items-center justify-between gap-3 rounded-xl bg-muted/50 px-3 py-3 text-sm"><span className="text-muted-foreground">e-POD status</span><span role="status" className={cn('inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold', signedAt ? 'bg-emerald-500/15 text-emerald-800 dark:text-emerald-300' : 'bg-muted text-foreground')}>{signedAt ? <><Check className="size-3.5" aria-hidden />Signed {formatTime(signedAt)}</> : 'Ready to sign'}</span></div>
      </section>

      {!signedAt && !signatureOpen && <button type="button" onClick={() => { setSignatureCaptured(false); setTimeIn(new Date()); setSignatureOpen(true) }} className="inline-flex min-h-14 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-base font-semibold text-primary-foreground shadow-sm transition hover:bg-primary/90 active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><PenLine className="size-5" aria-hidden />Tap to sign POD</button>}

      {signatureOpen && !signedAt && <section className="rounded-2xl border border-primary/30 bg-card p-4 shadow-sm" aria-labelledby="pod-signature-heading">
        <div className="flex items-start justify-between gap-3"><div><h3 id="pod-signature-heading" className="font-semibold">Consignee Acceptance &amp; Receiver Signature</h3><p className="mt-1 rounded-lg border border-primary/15 bg-primary/5 px-3 py-2 font-mono text-xs font-semibold text-primary" aria-live="polite">{timestamp}</p><p className="mt-2 text-xs text-muted-foreground">Sign in the box using touch, stylus, or mouse to verify cargo acceptance.</p></div><button type="button" onClick={clearSignature} disabled={!signatureCaptured} className="inline-flex min-h-10 shrink-0 items-center gap-1.5 rounded-md px-2 text-xs font-medium text-muted-foreground hover:bg-muted disabled:opacity-40"><Eraser className="size-3.5" aria-hidden />Clear</button></div>
        <div className="mt-4 rounded-xl border border-border bg-muted/40 p-3" aria-live="polite">
          <p className="text-xs font-semibold text-foreground">Equipment details to be certified</p>
          <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-2 text-xs sm:grid-cols-4">
            <div><dt className="text-muted-foreground">Container</dt><dd className="break-all font-mono font-semibold">{load?.container || '—'}</dd></div>
            <div><dt className="text-muted-foreground">Chassis</dt><dd className="break-all font-mono font-semibold">{load?.chassis || '—'}</dd></div>
            <div><dt className="text-muted-foreground">Seal</dt><dd className="break-all font-mono font-semibold">{load?.seal || '—'}</dd></div>
            <div><dt className="text-muted-foreground">B/L</dt><dd className="break-all font-mono font-semibold">{load?.billOfLading || '—'}</dd></div>
            <div><dt className="text-muted-foreground">Move Type</dt><dd className="break-words font-semibold">{load ? dispatchMoveTypeLabel(load.moveType ?? defaultDispatchMoveType(load.type)) : '—'}</dd></div>
          </dl>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="grid gap-1.5 text-xs font-medium text-foreground">Receiving Company / Facility Name<input value={receiverCompany} onChange={(event) => setReceiverCompany(event.target.value)} placeholder="Company or facility name" autoComplete="organization" className="h-11 rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
          <label className="grid gap-1.5 text-xs font-medium text-foreground">Receiver Print Name<input value={receiverName} onChange={(event) => setReceiverName(event.target.value)} placeholder="e.g., Aaron Dixon-Wiseman" autoComplete="name" className="h-11 rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
        </div>
        <canvas ref={canvasRef} width={960} height={240} aria-label="POD signature drawing area" onPointerDown={startSignature} onPointerMove={drawSignature} onPointerUp={(event) => { if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId) }} onPointerCancel={(event) => { if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId) }} className="mt-3 h-32 w-full touch-none rounded-xl border border-dashed border-border bg-white" />
        <p className="mt-2 text-xs text-muted-foreground">{signatureCaptured ? 'Signature captured. Complete delivery to timestamp the e-POD.' : 'Signature required to complete delivery.'}</p>
        <div className="mt-4 flex gap-2"><button type="button" onClick={() => { setSignatureOpen(false); setSignatureCaptured(false); setTimeIn(null); clearSignature() }} className="min-h-11 flex-1 rounded-lg border border-border px-3 text-sm font-medium hover:bg-muted">Cancel</button><button type="button" disabled={!signatureCaptured || !receiverCompany.trim() || !receiverName.trim()} onClick={onCompletePod} className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-primary px-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"><FileSignature className="size-4" aria-hidden />Complete POD &amp; Certify Delivery · {formatTime(clockNow)}</button></div>
      </section>}

      {signedAt && load?.podReceipt && <section role="status" className="rounded-2xl border border-emerald-700/25 bg-emerald-500/10 p-5 text-emerald-950 shadow-sm dark:text-emerald-100">
        <div className="flex flex-col items-center text-center"><span className="inline-flex size-16 items-center justify-center rounded-full bg-emerald-600 text-white shadow-sm"><CheckCircle2 className="size-10" aria-hidden /></span><h3 className="mt-3 text-lg font-bold">Delivery Certified &amp; Sent to Dispatch</h3><p className="mt-1 text-sm opacity-85">Signed by {load.podReceipt.receiverName} at {formatTime(signedAt)}. Automatically transmitted to Dispatcher Asmarew.</p></div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-emerald-700/15 bg-background/70 px-3 py-2"><div><span className="block text-[10px] font-semibold uppercase tracking-wide opacity-70">Verification Code</span><code className="font-mono text-sm font-bold">{podCode || load.podConfirmationCode}</code></div><button type="button" onClick={() => void navigator.clipboard?.writeText(podCode || load.podConfirmationCode || '')} className="inline-flex min-h-10 items-center gap-1.5 rounded-md border border-border bg-card px-3 text-xs font-semibold hover:bg-muted"><Copy className="size-3.5" aria-hidden />Copy Code</button></div>
        {signatureImage && <img src={signatureImage} alt="Captured POD receiver signature" className="mt-3 h-20 w-full rounded-lg bg-white object-contain" />}
        <ReceiptShareActions load={load} receipt={load.podReceipt} signedAt={signedAt} />
      </section>}
      <details className="overflow-hidden rounded-xl border border-border bg-card">
        <summary className="cursor-pointer list-none px-4 py-3 text-sm font-semibold marker:hidden">Driver Completed POD Archive ({archivedLoads.length} Loads Saved)</summary>
        <div className="space-y-3 border-t border-border p-3">
          {archivedLoads.length === 0 ? <p className="py-3 text-center text-xs text-muted-foreground">Completed receipts for this session will appear here.</p> : archivedLoads.map((archivedLoad) => {
            const receipt = archivedLoad.podReceipt!
            const archivedAt = new Date(archivedLoad.podSignedAtIso!)
            return <article key={archivedLoad.id} className="rounded-lg border border-border p-3"><div className="flex flex-wrap items-start justify-between gap-2"><div><p className="font-semibold">Load {archivedLoad.id} · {archivedLoad.container}</p><p className="mt-1 text-[11px] text-muted-foreground">B/L {archivedLoad.billOfLading ?? '—'} · Seal {archivedLoad.seal} · {receipt.receiverName} · {formatDateTime(archivedAt)}</p><p className="mt-1 font-mono text-[10px] text-emerald-700 dark:text-emerald-300">{archivedLoad.podConfirmationCode}</p></div><FileCheck2 className="size-4 text-emerald-600" aria-label="Certified archived POD" /></div><dl className="mt-3 grid grid-cols-2 gap-2 text-[10px]"><div><dt className="text-muted-foreground">Receiving company</dt><dd className="font-medium">{receipt.companyName}</dd></div><div><dt className="text-muted-foreground">Time in / out</dt><dd className="font-mono">{receipt.timeIn} / {receipt.timeOut}</dd></div><div><dt className="text-muted-foreground">Drop status</dt><dd>{receipt.dropStatus}</dd></div><div><dt className="text-muted-foreground">Driver / unit</dt><dd>{archivedLoad.driver} · {archivedLoad.truck}</dd></div></dl>{receipt.signatureDataUrl && <img src={receipt.signatureDataUrl} alt={`Receiver signature for ${archivedLoad.container}`} className="mt-3 h-16 w-full rounded-lg bg-white object-contain" />}<ReceiptShareActions load={archivedLoad} receipt={receipt} signedAt={archivedAt} compact /></article>
          })}
        </div>
      </details>
    </div>
  )
}

function ChainedDriverRun({ route }: { route: RouteChain }) {
  return <section aria-labelledby="driver-chained-run-title" className="overflow-hidden rounded-2xl border border-primary/25 bg-card shadow-sm">
    <header className="flex flex-wrap items-start justify-between gap-3 border-b border-border bg-primary/5 p-4">
      <div><p className="font-mono text-[10px] font-semibold uppercase tracking-[0.16em] text-primary">Assigned chained run · {route.legs.length} legs</p><h2 id="driver-chained-run-title" className="mt-1 text-lg font-bold">Route {route.reference} · {route.container}</h2><p className="mt-1 text-xs text-muted-foreground">Driver {route.driver} · {route.hosHoursAvailable.toFixed(1)} HOS hrs available (demo)</p></div>
      {route.dualMissionVerified && <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-700/20 bg-emerald-500/10 px-2.5 py-1.5 text-[10px] font-semibold text-emerald-800 dark:text-emerald-200"><Check className="size-3.5" aria-hidden />Zero empty bobtail</span>}
    </header>
    <ol className="flex flex-col gap-3 p-3 sm:p-4">
      {route.legs.map((leg, index) => <li key={leg.id} className="rounded-xl border border-border bg-background p-3 sm:p-4">
        <div className="flex items-start gap-3"><span className="inline-flex min-h-7 shrink-0 items-center rounded-full bg-primary px-2.5 font-mono text-[10px] font-bold text-primary-foreground">Leg {index + 1}/{route.legs.length}</span><div className="min-w-0 flex-1"><p className="text-sm font-bold">{leg.action}</p><p className="mt-1 text-xs text-muted-foreground">{leg.origin} <span aria-hidden>→</span> {leg.destination}</p></div></div>
        <dl className="mt-3 grid gap-2 rounded-lg bg-muted/50 p-3 sm:grid-cols-2"><div><dt className="text-[10px] font-medium text-muted-foreground">Equipment required</dt><dd className="mt-0.5 text-xs font-semibold">{leg.equipmentRequired}</dd></div>{leg.appointment && <div><dt className="text-[10px] font-medium text-muted-foreground">Terminal appointment</dt><dd className="mt-0.5 text-xs font-semibold">{leg.appointment}</dd></div>}{leg.container && <div><dt className="text-[10px] font-medium text-muted-foreground">Container / reference</dt><dd className="mt-0.5 font-mono text-xs font-semibold">{leg.container} · {leg.reference}</dd></div>}</dl>
      </li>)}
    </ol>
    <p className="border-t border-border px-4 py-3 text-[10px] text-muted-foreground">Final chassis drop: <span className="font-semibold text-foreground">{route.finalChassisDrop}</span> · eModal and HOS details are preview data, not live system verification.</p>
  </section>
}

function ReceiptShareActions({ load, receipt, signedAt, compact = false }: { load: Load; receipt: PodReceiptDetails; signedAt: Date; compact?: boolean }) {
  const [shareOpen, setShareOpen] = useState(false)
  const [previewOpen, setPreviewOpen] = useState(false)
  const [notice, setNotice] = useState('')
  const shareText = `Ephrata Trucking delivery receipt · ${load.container} · ${receipt.confirmationCode ?? load.podConfirmationCode ?? ''}`
  const pageLink = typeof window === 'undefined' ? '' : window.location.href
  const encodedShare = encodeURIComponent(`${shareText} ${pageLink}`)

  const shareNativeFile = async () => {
    const { filename, blob } = createDeliveryReceiptPdf(load, receipt, signedAt)
    const file = new File([blob], filename, { type: 'application/pdf' })
    if (navigator.share && navigator.canShare?.({ files: [file] })) {
      try {
        await navigator.share({ title: `Delivery receipt · ${load.container}`, text: shareText, files: [file] })
        setNotice('Receipt shared from your device.')
      } catch (error) {
        if (error instanceof Error && error.name !== 'AbortError') setNotice('Device sharing was unavailable. Use Download PDF Receipt instead.')
      }
      return
    }
    setNotice('This device cannot attach PDF files through sharing. Use Email Copy to Receiver or the optional manual download.')
  }

  const copyPreviewLink = async () => {
    await navigator.clipboard?.writeText(pageLink)
    setNotice('Copied this preview page URL. It is not a hosted receipt or secure public link.')
  }

  const emailCopy = async () => {
    const subject = `Signed delivery receipt · ${load.container}`
    const body = `Signed POD for ${load.container}\nReceiver: ${receipt.receiverName}\nSigned: ${formatDateTime(signedAt)}\nVerification: ${receipt.confirmationCode ?? load.podConfirmationCode ?? ''}`
    const { filename, blob } = createDeliveryReceiptPdf(load, receipt, signedAt)
    const file = new File([blob], filename, { type: 'application/pdf' })
    if (navigator.share && navigator.canShare?.({ files: [file] })) {
      try {
        await navigator.share({ title: subject, text: body, files: [file] })
      } catch (error) {
        if (error instanceof Error && error.name !== 'AbortError') setNotice('Could not open the device email/share sheet.')
      }
      return
    }
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    setNotice('Email draft opened. Enter the receiver email; attach the PDF manually only if needed.')
  }

  return <div className="mt-3">
    {previewOpen && <DeliveryReceiptPreview load={load} receipt={receipt} signedAt={signedAt} onClose={() => setPreviewOpen(false)} />}
    <div className="flex flex-wrap gap-2">
      <button type="button" onClick={() => setPreviewOpen(true)} className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-border bg-background px-3.5 text-xs font-semibold hover:bg-muted"><Eye className="size-4" aria-hidden />{compact ? 'Preview Receipt' : 'View Receipt (Preview)'}</button>
      <button type="button" onClick={() => void emailCopy()} className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-primary/30 bg-primary/5 px-3.5 text-xs font-semibold text-primary hover:bg-primary/10"><Mail className="size-4" aria-hidden />{compact ? 'Email Copy' : 'Email Copy to Receiver'}</button>
      <button type="button" onClick={() => downloadDeliveryReceiptPdf(load, receipt, signedAt)} className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-border bg-background px-3.5 text-xs font-semibold hover:bg-muted"><Download className="size-4" aria-hidden />{compact ? 'Download PDF' : 'Download PDF Receipt'}</button>
    </div>
    {notice && <p role="status" className="mt-2 text-xs text-muted-foreground">{notice}</p>}
    {shareOpen && <div className="fixed inset-0 z-[90] flex items-center justify-center bg-slate-950/60 p-4" onMouseDown={(event) => event.target === event.currentTarget && setShareOpen(false)}><section role="dialog" aria-modal="true" aria-labelledby="pod-share-title" className="w-full max-w-md rounded-2xl border border-border bg-background p-5 shadow-2xl"><header className="flex items-center justify-between gap-3"><div><h3 id="pod-share-title" className="font-semibold">Share delivery receipt</h3><p className="mt-1 text-xs text-muted-foreground">{load.container} · {receipt.confirmationCode ?? load.podConfirmationCode}</p></div><button type="button" onClick={() => setShareOpen(false)} aria-label="Close share options" className="rounded-md p-2 hover:bg-muted">×</button></header><div className="mt-4 grid gap-2"><button type="button" onClick={() => void shareNativeFile()} className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-primary px-3 text-sm font-semibold text-primary-foreground"><Share2 className="size-4" aria-hidden />Share PDF file with device…</button><a href={`https://wa.me/?text=${encodedShare}`} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center rounded-lg border border-border px-3 text-sm font-medium hover:bg-muted">WhatsApp (receipt reference)</a><a href={`https://t.me/share/url?url=${encodeURIComponent(pageLink)}&text=${encodeURIComponent(shareText)}`} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center rounded-lg border border-border px-3 text-sm font-medium hover:bg-muted">Telegram (receipt reference)</a><a href={`mailto:?subject=${encodeURIComponent(`Delivery receipt · ${load.container}`)}&body=${encodedShare}`} className="inline-flex min-h-11 items-center rounded-lg border border-border px-3 text-sm font-medium hover:bg-muted">Email receipt details</a><button type="button" onClick={() => void copyPreviewLink()} className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-border px-3 text-left text-sm font-medium hover:bg-muted"><Copy className="size-4" aria-hidden />Copy preview page link</button></div>{notice && <p role="status" className="mt-3 rounded-lg bg-muted p-2.5 text-xs">{notice}</p>}<p className="mt-3 rounded-lg border border-amber-300/70 bg-amber-50 p-3 text-xs leading-relaxed text-amber-950 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-100">Preview only: external options share receipt details or this page URL, not an authenticated PDF link. Use device file sharing or download the PDF to attach it. No secure hosted link is configured.</p></section></div>}
  </div>
}

function createPodConfirmationCode(date: Date, preferredSuffix?: string) {
  const prefix = `POD-CONF-${date.getFullYear()}`
  const preferredCode = preferredSuffix ? `${prefix}-${preferredSuffix}` : ''
  if (preferredCode && !issuedPodCodes.has(preferredCode)) {
    issuedPodCodes.add(preferredCode)
    return preferredCode
  }

  let code = ''
  do {
    const values = new Uint32Array(1)
    crypto.getRandomValues(values)
    code = `${prefix}-${String(values[0] % 100000).padStart(5, '0')}`
  } while (issuedPodCodes.has(code))
  issuedPodCodes.add(code)
  return code
}

function formatTime(date: Date) {
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
}

function formatDateTime(date: Date) {
  return `Date: ${date.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })} · Time: ${formatTime(date)}`
}

