'use client'

import { useTms } from './tms-store'

const DEMO_REVENUE = {
  total: 48_650,
  invoiced: 39_210,
  pending: 9_440,
}

export function RevenueWidget() {
  const { view } = useTms()
  const formatUsd = (amount: number) => amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' })

  if (view === 'driver') return null

  return (
    <aside aria-label="This month total revenue" className="pointer-events-none fixed bottom-2 right-2 z-[40] w-[min(24rem,calc(100vw-1rem))] rounded-md border border-blue-300 bg-[#153a67] px-3 py-2.5 text-white shadow-xl sm:bottom-4 sm:right-4">
      <div className="flex items-baseline justify-between gap-3">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-wider text-blue-100">This Month Total Revenue</p>
        <p className="font-mono text-base font-bold tabular-nums">{formatUsd(DEMO_REVENUE.total)}</p>
      </div>
      <div className="mt-1 flex flex-wrap justify-between gap-x-3 gap-y-1 border-t border-white/15 pt-1.5 font-mono text-[10px] text-blue-100">
        <span>Month-to-Date Revenue: {formatUsd(DEMO_REVENUE.total)}</span>
        <span>Invoiced: {formatUsd(DEMO_REVENUE.invoiced)}</span>
        <span>Pending: {formatUsd(DEMO_REVENUE.pending)}</span>
      </div>
    </aside>
  )
}
