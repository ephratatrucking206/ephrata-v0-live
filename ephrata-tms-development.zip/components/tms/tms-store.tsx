'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import {
  INITIAL_INVOICES,
  INITIAL_LOADS,
  type Invoice,
  type InvoiceDraftDetails,
  type Load,
  type PodReceiptDetails,
  type RouteChain,
  type TerminalAppointment,
  type DispatchMoveType,
  dispatchMoveTypeLabel,
  defaultDispatchMoveType,
  loadTypeLabel,
  loadTotal,
} from '@/lib/tms-data'

export type View = 'dispatch' | 'inbound' | 'driver' | 'billing' | 'settings'
export interface InboundOrderDetails {
  container: string
  billOfLading: string
  terminal: Load['terminal']
  consignee: string
  consigneeAddress: string
  consigneeContact: string
  linehaulRate: number
  containerSize: Load['size']
  loadType: Load['type']
  weightLbs: number
  seal: string
  lfd: string
  orderDate: string
  vesselVoyage: string
  appointment?: string
  appointmentDate?: string
  appointmentWindow?: string
  dispatchNotes?: string
  poNumber?: string
}
export type ChatSender = 'driver' | 'dispatch'
export type AccessRole = 'Admin / Owner' | 'Dispatcher' | 'Driver'
export interface DriverChatMessage {
  id: string
  loadId: string
  sender: ChatSender
  text: string
  sentAt: string
  urgent: boolean
}

const initialChatMessages: DriverChatMessage[] = [
  { id: 'seed-driver-1', loadId: '106381', sender: 'driver', text: '📍 Arrived at Terminal Gate', sentAt: '11:18 AM', urgent: false },
  { id: 'seed-dispatch-1', loadId: '106381', sender: 'dispatch', text: 'Copy. We are monitoring the gate. Send an update if the line gets longer.', sentAt: '11:21 AM', urgent: false },
]

interface TmsContextValue {
  view: View
  setView: (v: View) => void
  loads: Load[]
  invoices: Invoice[]
  newInvoiceId: string | null
  activeRouteChain: RouteChain | null
  setActiveRouteChain: (route: RouteChain | null) => void
  trackingLoadId: string | null
  openTracking: (loadId: string) => void
  closeTracking: () => void
  chatMessages: DriverChatMessage[]
  chatOpen: boolean
  chatLoadId: string | null
  chatSender: ChatSender
  unreadByLoad: Record<string, number>
  urgentUnreadLoadIds: string[]
  podAlertLoadId: string | null
  dismissPodAlert: () => void
  accessRole: AccessRole
  setAccessRole: (role: AccessRole) => void
  podAuditLog: { id: string; loadId: string; action: string; reason: string; actor: string; at: string }[]
  recordPodAudit: (loadId: string, action: string, reason: string) => void
  voidPod: (loadId: string, reason: string) => void
  openDriverChat: (loadId: string, sender: ChatSender) => void
  closeDriverChat: () => void
  setChatSender: (sender: ChatSender) => void
  sendDriverChatMessage: (text: string, sender: ChatSender, loadId: string) => void
  updateLoad: (loadId: string, field: keyof Load, value: string) => void
  saveTerminalAppointment: (loadId: string, appointment: TerminalAppointment) => void
  addInboundOrder: (order: InboundOrderDetails) => void
  addInboundOrders: (orders: InboundOrderDetails[]) => void
  updateInvoice: (invoiceId: string, field: keyof Invoice, value: string) => void
  saveInvoiceDraft: (load: Load, amount: number, details: InvoiceDraftDetails) => void
  approveInvoice: (load: Load, amount: number, dispatcherName: string, details: InvoiceDraftDetails) => void
  releaseFridayBatch: () => void
  signPod: (loadId: string, receipt: PodReceiptDetails, signedAt: Date, confirmationCode: string) => Invoice | null
  resetDemo: () => void
}

const certifiedEquipmentFields = new Set<keyof Load>(['container', 'chassis', 'seal', 'billOfLading', 'moveType'])

const TmsContext = createContext<TmsContextValue | null>(null)

export function TmsProvider({ children }: { children: React.ReactNode }) {
  const [view, setView] = useState<View>('dispatch')
  const [loads, setLoads] = useState<Load[]>(INITIAL_LOADS)
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES)
  const [activeRouteChain, setActiveRouteChain] = useState<RouteChain | null>(null)
  const [newInvoiceId, setNewInvoiceId] = useState<string | null>(null)
  const [trackingLoadId, setTrackingLoadId] = useState<string | null>(null)
  const [chatMessages, setChatMessages] = useState<DriverChatMessage[]>(initialChatMessages)
  const [chatOpen, setChatOpen] = useState(false)
  const [chatLoadId, setChatLoadId] = useState<string | null>(null)
  const [chatSender, setChatSender] = useState<ChatSender>('driver')
  const [unreadByLoad, setUnreadByLoad] = useState<Record<string, number>>({})
  const [urgentUnreadLoadIds, setUrgentUnreadLoadIds] = useState<string[]>([])
  const [podAlertLoadId, setPodAlertLoadId] = useState<string | null>(null)
  const [accessRole, setAccessRole] = useState<AccessRole>('Dispatcher')
  const [podAuditLog, setPodAuditLog] = useState<{ id: string; loadId: string; action: string; reason: string; actor: string; at: string }[]>([])
  const dismissPodAlert = useCallback(() => setPodAlertLoadId(null), [])
  const recordPodAudit = useCallback((loadId: string, action: string, reason: string) => {
    if (accessRole !== 'Admin / Owner' || !reason.trim()) return
    setPodAuditLog((current) => [{ id: `${Date.now()}-${Math.random()}`, loadId, action, reason: reason.trim(), actor: 'Demo Admin / Owner', at: new Date().toLocaleString('en-US') }, ...current])
  }, [accessRole])
  const voidPod = useCallback((loadId: string, reason: string) => {
    if (accessRole !== 'Admin / Owner' || !reason.trim()) return
    setLoads((current) => current.map((load) => load.id === loadId ? { ...load, podVoided: true, podVoidReason: reason.trim(), status: 'Hold' } : load))
    recordPodAudit(loadId, 'Voided / placed on hold', reason)
  }, [accessRole, recordPodAudit])
  const openTracking = useCallback((loadId: string) => setTrackingLoadId(loadId), [])
  const closeTracking = useCallback(() => setTrackingLoadId(null), [])
  const openDriverChat = useCallback((loadId: string, sender: ChatSender) => {
    setChatLoadId(loadId)
    setChatSender(sender)
    setChatOpen(true)
    if (sender === 'dispatch') {
      setUnreadByLoad((current) => ({ ...current, [loadId]: 0 }))
      setUrgentUnreadLoadIds((current) => current.filter((id) => id !== loadId))
    }
  }, [])
  const closeDriverChat = useCallback(() => setChatOpen(false), [])
  const sendDriverChatMessage = useCallback((text: string, sender: ChatSender, loadId: string) => {
    const trimmed = text.trim()
    if (!trimmed) return
    const urgent = /urgent|🚨/i.test(trimmed)
    setChatMessages((current) => [...current, {
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      loadId,
      sender,
      text: trimmed,
      sentAt: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      urgent,
    }])
    if (sender === 'driver') {
      setUnreadByLoad((current) => ({ ...current, [loadId]: (current[loadId] ?? 0) + 1 }))
      if (urgent) setUrgentUnreadLoadIds((current) => current.includes(loadId) ? current : [...current, loadId])
    }
  }, [])

  const updateLoad = useCallback((loadId: string, field: keyof Load, value: string) => {
    setLoads((current) => current.map((load) => {
      if (load.id !== loadId) return load
      if (load.podSigned && (certifiedEquipmentFields.has(field) || accessRole !== 'Admin / Owner')) return load
      if (field === 'moveType') {
        const nextMoveType = value as DispatchMoveType
        if (!['⬆️ PICK FULL', '⬇️ DROP FULL', '⬆️ PICK EMPTY', '⬇️ DROP EMPTY', 'Yard Staging'].includes(nextMoveType) || nextMoveType === load.moveType) return load
        const updateNote = `Driver update: Move type changed to ${dispatchMoveTypeLabel(nextMoveType)}.`
        return {
          ...load,
          moveType: nextMoveType,
          status: load.status === 'Unassigned' ? 'Dispatched' : load.status,
          dispatchNotes: [load.dispatchNotes, updateNote].filter(Boolean).join(' · '),
        }
      }
      if (field === 'type') {
        const nextType = value as Load['type']
        if (!['Import', 'Export', 'Empty Return', 'Yard Staging'].includes(nextType) || nextType === load.type) return load
        const updateNote = `Dispatch update: Move type changed to ${loadTypeLabel(nextType)}.`
        return {
          ...load,
          type: nextType,
          moveType: defaultDispatchMoveType(nextType),
          status: load.status === 'Unassigned' ? 'Dispatched' : load.status,
          dispatchNotes: [load.dispatchNotes, updateNote].filter(Boolean).join(' · '),
        }
      }
      if (field === 'weightLbs') {
        const weightLbs = Number(value.replace(/[, ]/g, ''))
        return Number.isFinite(weightLbs) ? { ...load, weightLbs } : load
      }
      if (field === 'podSigned') return { ...load, podSigned: value.toLowerCase() === 'true' }
      return { ...load, [field]: value } as Load
    }))
  }, [accessRole])

  const saveTerminalAppointment = useCallback((loadId: string, appointment: TerminalAppointment) => {
    setLoads((current) => current.map((load) => load.id === loadId ? { ...load, terminalAppointment: appointment } : load))
  }, [])

  const addInboundOrders = useCallback((orders: InboundOrderDetails[]) => {
    if (!orders.length) return
    const timestamp = Date.now()
    const newLoads = orders.map((order, index): Load => {
      const id = `IN-${timestamp}-${index + 1}-${Math.random().toString(36).slice(2, 7)}`
      const linehaulRate = Math.round(order.linehaulRate * 100) / 100
      return {
        id,
        container: order.container.trim().toUpperCase(),
        billOfLading: order.billOfLading.trim(),
        consigneeAddress: order.consigneeAddress.trim(),
        consigneeContact: order.consigneeContact.trim(),
        vesselVoyage: order.vesselVoyage.trim(),
        orderDate: order.orderDate.trim(),
        poNumber: order.poNumber?.trim(),
        size: order.containerSize,
        type: order.loadType,
        terminal: order.terminal,
        line: 'Not specified',
        customer: order.consignee.trim(),
        destination: order.consigneeAddress.trim() || order.consignee.trim(),
        driver: null,
        truck: null,
        chassis: '',
        status: 'Unassigned',
        appt: order.appointment?.trim() || 'Not scheduled',
        appointmentDate: order.appointmentDate,
        appointmentWindow: order.appointmentWindow,
        dispatchNotes: order.dispatchNotes?.trim(),
        lfd: order.lfd || 'Not recorded',
        weightLbs: order.weightLbs,
        seal: order.seal.trim(),
        charges: [{ label: 'Drayage linehaul', amount: linehaulRate }],
        podSigned: false,
      }
    })
    setLoads((current) => [...newLoads, ...current])
  }, [])
  const addInboundOrder = useCallback((order: InboundOrderDetails) => addInboundOrders([order]), [addInboundOrders])

  const updateInvoice = useCallback((invoiceId: string, field: keyof Invoice, value: string) => {
    setInvoices((current) => current.map((invoice) => {
      if (invoice.id !== invoiceId) return invoice
      if (field === 'status') {
        const nextStatus = value as Invoice['status']
        if (invoice.approvalStatus === 'Needs Review' && (nextStatus === 'Sent' || nextStatus === 'Paid')) return invoice
        return { ...invoice, status: nextStatus }
      }
      if (field === 'amount') {
        const amount = Number(value.replace(/[$, ]/g, ''))
        if (!Number.isFinite(amount) || invoice.approvalStatus === 'Billed / Sent') return invoice
        return { ...invoice, amount, lineItems: undefined, approvalStatus: 'Needs Review', approvedBy: undefined, approvedAt: undefined, status: 'Draft / Under Review' }
      }
      const invoiceDetails = new Set<keyof Invoice>(['id', 'loadId', 'customer', 'container', 'issued', 'due', 'terms'])
      if (invoiceDetails.has(field) && invoice.approvalStatus === 'Billed / Sent') return invoice
      const changed = { ...invoice, [field]: value } as Invoice
      return invoiceDetails.has(field)
        ? { ...changed, approvalStatus: 'Needs Review', approvedBy: undefined, approvedAt: undefined, status: 'Draft / Under Review' }
        : changed
    }))
  }, [])

  const saveInvoiceDraft = useCallback((load: Load, amount: number, details: InvoiceDraftDetails) => {
    setInvoices((current) => {
      const existing = current.find((invoice) => invoice.loadId === load.id)
      const savedDetails = {
        issued: details.issued,
        due: details.due,
        terms: details.terms,
        lineItems: details.lineItems,
        attention: details.attention,
        billingAddress: details.billingAddress,
        phone: details.phone,
        email: details.email,
      }
      if (!existing) return [{ ...createInvoiceRecord(load, amount, current), ...savedDetails }, ...current]
      if (existing.approvalStatus === 'Billed / Sent') return current
      const detailsChanged = existing.amount !== amount || existing.customer !== load.customer || existing.container !== load.container || existing.issued !== details.issued || existing.due !== details.due || existing.terms !== details.terms
      return current.map((invoice) => invoice.id !== existing.id ? invoice : {
        ...invoice,
        customer: load.customer,
        container: load.container,
        amount,
        ...savedDetails,
        status: 'Draft / Under Review',
        ...(detailsChanged
          ? { approvalStatus: 'Needs Review' as const, approvedBy: undefined, approvedAt: undefined }
          : {}),
      })
    })
  }, [])

  const approveInvoice = useCallback((load: Load, amount: number, dispatcherName: string, details: InvoiceDraftDetails) => {
    const approvedAt = new Date().toISOString()
    const approver = dispatcherName.trim() || 'Dispatcher'
    setInvoices((current) => {
      const existing = current.find((invoice) => invoice.loadId === load.id)
      if (existing?.approvalStatus === 'Billed / Sent' || existing?.status === 'Paid') return current
      const invoice = existing ?? createInvoiceRecord(load, amount, current)
      return [
        {
          ...invoice,
          amount,
          customer: load.customer,
          container: load.container,
          issued: details.issued,
          due: details.due,
          terms: details.terms,
          lineItems: details.lineItems,
          attention: details.attention,
          billingAddress: details.billingAddress,
          phone: details.phone,
          email: details.email,
          status: 'Draft / Under Review',
          approvalStatus: 'Approved for Friday Billing',
          approvedBy: approver,
          approvedAt,
        },
        ...current.filter((candidate) => candidate.id !== invoice.id),
      ]
    })
  }, [])

  const releaseFridayBatch = useCallback(() => {
    const completedLoadIds = new Set(loads.filter((load) => load.status === 'Delivered' || load.podSigned).map((load) => load.id))
    setInvoices((current) => current.map((invoice) =>
      invoice.approvalStatus === 'Approved for Friday Billing' && completedLoadIds.has(invoice.loadId)
        ? { ...invoice, approvalStatus: 'Billed / Sent', status: 'Sent' }
        : invoice,
    ))
  }, [loads])

  const signPod = useCallback(
    (loadId: string, receipt: PodReceiptDetails, signedAt: Date, confirmationCode: string) => {
      const load = loads.find((l) => l.id === loadId)
      if (!load || load.podSigned) return null

      const signedAtIso = signedAt.toISOString()
      const signedAtLabel = signedAt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
      const invoice: Invoice = {
        id: '750056',
        loadId: load.id,
        customer: load.customer,
        container: load.container,
        issued: signedAt.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit', timeZone: 'America/Los_Angeles' }),
        due: new Date(signedAt.getTime() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' }),
        terms: 'Net 30',
        amount: loadTotal(load),
        status: 'Draft / Under Review',
        approvalStatus: 'Needs Review',
        qboRef: 'QBO-18835',
      }

      setLoads((prev) =>
        prev.map((l) =>
          l.id === loadId
            ? { ...l, podSigned: true, podSignedAt: signedAtLabel, podSignedAtIso: signedAtIso, podReceipt: { ...receipt, confirmationCode }, podConfirmationCode: confirmationCode, status: 'Delivered' }
            : l,
        ),
      )
      setInvoices((prev) => [invoice, ...prev.filter((i) => i.id !== invoice.id)])
      setNewInvoiceId(invoice.id)
      setPodAlertLoadId(loadId)

      return invoice
    },
    [loads],
  )

  const resetDemo = useCallback(() => {
    setLoads(INITIAL_LOADS)
    setInvoices(INITIAL_INVOICES)
    setActiveRouteChain(null)
    setNewInvoiceId(null)
    setChatMessages(initialChatMessages)
    setUnreadByLoad({})
    setUrgentUnreadLoadIds([])
    setPodAlertLoadId(null)
    setPodAuditLog([])
    setAccessRole('Dispatcher')
    setChatOpen(false)
    setChatLoadId(null)
    setChatSender('driver')
  }, [])

  const value = useMemo(
    () => ({
      view,
      setView,
      loads,
      invoices,
      newInvoiceId,
      activeRouteChain,
      setActiveRouteChain,
      trackingLoadId,
      openTracking,
      closeTracking,
      chatMessages,
      chatOpen,
      chatLoadId,
      chatSender,
      unreadByLoad,
      urgentUnreadLoadIds,
      podAlertLoadId,
      dismissPodAlert,
      accessRole,
      setAccessRole,
      podAuditLog,
      recordPodAudit,
      voidPod,
      openDriverChat,
      closeDriverChat,
      setChatSender,
      sendDriverChatMessage,
      updateLoad,
  saveTerminalAppointment,
  addInboundOrder,
  addInboundOrders,
  updateInvoice,

      saveInvoiceDraft,
      approveInvoice,
      releaseFridayBatch,
      signPod,
      resetDemo,
    }),
    [view, loads, invoices, newInvoiceId, activeRouteChain, trackingLoadId, openTracking, closeTracking, chatMessages, chatOpen, chatLoadId, chatSender, unreadByLoad, urgentUnreadLoadIds, podAlertLoadId, dismissPodAlert, accessRole, podAuditLog, recordPodAudit, voidPod, openDriverChat, closeDriverChat, setChatSender, sendDriverChatMessage, updateLoad, saveTerminalAppointment, addInboundOrder, addInboundOrders, updateInvoice, saveInvoiceDraft, approveInvoice, releaseFridayBatch, signPod, resetDemo],
  )

  return <TmsContext.Provider value={value}>{children}</TmsContext.Provider>
}

export function useTms() {
  const ctx = useContext(TmsContext)
  if (!ctx) throw new Error('useTms must be used within TmsProvider')
  return ctx
}

function createInvoiceRecord(load: Load, amount: number, current: Invoice[]): Invoice {
  const nextNumber = Math.max(4471, ...current.map((invoice) => Number(invoice.id.match(/(\\d+)$/)?.[1] ?? 0))) + 1
  const issuedAt = new Date()
  const issued = issuedAt.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit', timeZone: 'America/Los_Angeles' })
  const dueAt = new Date(issuedAt.getTime() + 30 * 24 * 60 * 60 * 1000)
  const due = dueAt.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit', timeZone: 'America/Los_Angeles' })
  return {
    id: `AAA-26-${nextNumber}`,
    loadId: load.id,
    customer: load.customer,
    container: load.container,
    issued,
    due,
    terms: 'Net 30',
    amount,
    status: 'Draft / Under Review',
    approvalStatus: 'Needs Review',
    qboRef: `QBO-DRAFT-${load.id}`,
  }
}
