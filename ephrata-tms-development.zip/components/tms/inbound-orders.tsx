'use client'

import { useEffect, useRef, useState, type ChangeEvent, type DragEvent } from 'react'
import { Check, ClipboardPaste, FileText, Inbox, LoaderCircle, Mail, Upload, X, Zap } from 'lucide-react'
import { LOAD_TYPE_OPTIONS, TERMINALS, type Load, type Terminal } from '@/lib/tms-data'
import { parseDispatchAppointmentText, type ParsedAppointmentOrder } from '@/lib/inbound-order-text'

const agilocDeliveryOrderPreview: {
  container: string
  billOfLading: string
  originTerminal: Terminal
  consignee: string
  consigneeAddress: string
  consigneeContact: string
  linehaulRate: string
  containerSize: Load['size']
  loadType: Load['type']
  weightLbs: string
  seal: string
  lfd: string
  orderDate: string
  vesselVoyage: string
} = {
  container: 'AGLU4827193',
  billOfLading: 'AGLSEA94720518',
  originTerminal: 'Husky',
  consignee: 'Agiloc Distribution',
  consigneeAddress: '1450 Port Industrial Way, Tacoma, WA',
  consigneeContact: 'Agiloc Receiving · (253) 555-0148',
  linehaulRate: '875',
  containerSize: '40HC',
  loadType: 'Import',
  weightLbs: '18450',
  seal: 'AGL902841',
  lfd: '',
  orderDate: '',
  vesselVoyage: 'AGILOC VOYAGER / 026E',
}
import { useTms, type InboundOrderDetails } from './tms-store'
import { PageHeader } from './page-header'

type ParsedFields = {
  container: string
  billOfLading: string
  originTerminal: Terminal | ''
  consignee: string
  consigneeAddress: string
  consigneeContact: string
  linehaulRate: string
  containerSize: Load['size']
  loadType: Load['type']
  weightLbs: string
  seal: string
  lfd: string
  orderDate: string
  vesselVoyage: string
}

type AppointmentDraft = ParsedAppointmentOrder & {
  selected: boolean
  linehaulRate: string
  loadType: Load['type']
}

const appointmentPastePlaceholder = `Paste customer appointment emails, multi-container lists, or dispatch notes here...\nExample:\nEITU1966667 App: Del 9/22 at 1pm - 2pm   9/22 @ 1:30pm\nEGHU8222413 App: Del 9/23 at 7am  9/23 @ 7:30am\nEGHU9295625 App: Del 9/23 at 10am - 11am  9/23 @ 10:30am – crew is at lunch from 11 to 11:30\nEGHU8237389 App: Del 9/23 at 1pm - 2pm   9/23 @ 1pm - latest he could check in is 2pm`
const appointmentTerminalOptions: Terminal[] = ['Husky', 'Everport', 'T5']

class SupabaseInsertError extends Error {
  constructor(message: string, public readonly details: string) {
    super(message)
    this.name = 'SupabaseInsertError'
  }
}

async function saveInboundOrderToSupabase(order: InboundOrderDetails) {
  const response = await fetch('/api/inbound-orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(order),
  })
  const result = await response.json().catch(() => null) as {
    data?: unknown
    error?: { message?: string; details?: string | null; hint?: string | null; code?: string | null } | null
  } | null

  if (!response.ok || result?.error) {
    const databaseError = result?.error
    const details = [
      databaseError?.details,
      databaseError?.hint,
      databaseError?.code ? `Code: ${databaseError.code}` : '',
    ].filter(Boolean).join(' · ')

    throw new SupabaseInsertError(
      databaseError?.message ?? `Unable to save inbound order (HTTP ${response.status}).`,
      details || 'No additional error details were returned.',
    )
  }

  return result?.data
}

const emptyFields: ParsedFields = {
  container: '',
  billOfLading: '',
  originTerminal: '',
  consignee: '',
  consigneeAddress: '',
  consigneeContact: '',
  linehaulRate: '875',
  containerSize: '40HC',
  loadType: 'Import',
  weightLbs: '',
  seal: '',
  lfd: '',
  orderDate: '',
  vesselVoyage: '',
}

const sizeOptions: { value: Load['size']; label: string }[] = [
  { value: '20GP', label: "20'" },
  { value: '40GP', label: "40'" },
  { value: '40HC', label: "40' High Cube" },
  { value: '45HC', label: "45' High Cube" },
]

export function InboundOrders() {
  const fileInput = useRef<HTMLInputElement>(null)
  const pasteInput = useRef<HTMLTextAreaElement>(null)
  const mockParseTimer = useRef<number | null>(null)
  const saveRedirectTimer = useRef<number | null>(null)

  useEffect(() => () => {
    if (mockParseTimer.current !== null) window.clearTimeout(mockParseTimer.current)
    if (saveRedirectTimer.current !== null) window.clearTimeout(saveRedirectTimer.current)
  }, [])
  const { addInboundOrder, addInboundOrders, setView } = useTms()
  const [file, setFile] = useState<File | null>(null)
  const [fields, setFields] = useState<ParsedFields>(emptyFields)
  const [isDragging, setIsDragging] = useState(false)
  const [isParsing, setIsParsing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [saveSucceeded, setSaveSucceeded] = useState(false)
  const [error, setError] = useState('')
  const [parsedFilename, setParsedFilename] = useState('')
  const [inputMode, setInputMode] = useState<'pdf' | 'text'>('pdf')
  const [rawEmailText, setRawEmailText] = useState('')
  const [parsedAppointments, setParsedAppointments] = useState<AppointmentDraft[]>([])
  const [defaultConsignee, setDefaultConsignee] = useState('Golden Intl')
  const [defaultTerminal, setDefaultTerminal] = useState<Terminal>('Husky')
  const [defaultLinehaulRate, setDefaultLinehaulRate] = useState('875.00')
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false)
  const [emailCopied, setEmailCopied] = useState(false)
  const [copyError, setCopyError] = useState(false)

  const openEmailDialog = () => {
    setEmailCopied(false)
    setCopyError(false)
    setIsEmailDialogOpen(true)
  }

  const copyEmailAddress = async () => {
    try {
      await navigator.clipboard.writeText('seattletruck@gmail.com')
      setEmailCopied(true)
      window.setTimeout(() => setEmailCopied(false), 2200)
    } catch {
      setCopyError(true)
    }
  }

  const switchToTextPaste = () => {
    setInputMode('text')
    setIsEmailDialogOpen(false)
    window.requestAnimationFrame(() => {
      pasteInput.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      pasteInput.current?.focus()
    })
  }

  const chooseFile = (selected: File | null) => {
    if (!selected || isParsing) return
    setError('')
    setFields(emptyFields)
    setParsedFilename('')
    if (selected.type !== 'application/pdf' && !selected.name.toLowerCase().endsWith('.pdf')) {
      setFile(null)
      setError('Choose a PDF rate confirmation or delivery order.')
      return
    }
    if (selected.size > 15 * 1024 * 1024) {
      setFile(null)
      setError('PDFs must be 15 MB or smaller.')
      return
    }
    setFile(selected)
  }

  const uploadSelection = (event: ChangeEvent<HTMLInputElement>) => chooseFile(event.target.files?.[0] ?? null)

  const parseMockAgilocPdf = () => {
    const sampleFile = new File(['Mock Agiloc delivery order PDF preview'], 'Agiloc-Delivery-Order-AGLU4827193.pdf', { type: 'application/pdf' })
    setFile(sampleFile)
    setFields(emptyFields)
    setParsedFilename('')
    setError('')
    setIsParsing(true)
    if (mockParseTimer.current !== null) window.clearTimeout(mockParseTimer.current)
    mockParseTimer.current = window.setTimeout(() => {
      setFields(agilocDeliveryOrderPreview)
      setParsedFilename(sampleFile.name)
      setIsParsing(false)
      mockParseTimer.current = null
    }, 1400)
  }

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    setIsDragging(false)
    chooseFile(event.dataTransfer.files[0] ?? null)
  }

  const parsePdf = async () => {
    if (!file) {
      fileInput.current?.click()
      return
    }
    setIsParsing(true)
    setError('')
    try {
      const body = new FormData()
      body.set('file', file)
      const response = await fetch('/api/inbound-orders/parse', { method: 'POST', body })
      const result = await response.json() as {
        error?: string
        filename?: string
        fields?: {
          container?: string
          billOfLading?: string
          originTerminal?: Terminal | null
          consignee?: string
          consigneeAddress?: string
          consigneeContact?: string
          linehaulRate?: number | null
          containerSize?: Load['size']
          loadType?: Load['type']
          weightLbs?: number | null
          seal?: string
          lfd?: string
          orderDate?: string
          vesselVoyage?: string
        }
      }
      if (!response.ok || !result.fields) throw new Error(result.error || 'Could not parse this PDF order.')
      setFields({
        container: result.fields.container ?? '',
        billOfLading: result.fields.billOfLading ?? '',
        originTerminal: result.fields.originTerminal ?? '',
        consignee: result.fields.consignee ?? '',
        consigneeAddress: result.fields.consigneeAddress ?? '',
        consigneeContact: result.fields.consigneeContact ?? '',
        linehaulRate: String(result.fields.linehaulRate ?? 875),
        containerSize: result.fields.containerSize ?? '40HC',
        loadType: result.fields.loadType ?? 'Import',
        weightLbs: result.fields.weightLbs == null ? '' : String(result.fields.weightLbs),
        seal: result.fields.seal ?? '',
        lfd: result.fields.lfd ?? '',
        orderDate: result.fields.orderDate ?? '',
        vesselVoyage: result.fields.vesselVoyage ?? '',
      })
      setParsedFilename(result.filename ?? file.name)
    } catch (parseError) {
      setError(parseError instanceof Error ? parseError.message : 'Could not parse this PDF order.')
      setFields(emptyFields)
    } finally {
      setIsParsing(false)
    }
  }

  const updateField = <K extends keyof ParsedFields>(field: K, value: ParsedFields[K]) => setFields((current) => ({ ...current, [field]: value }))
  const updateAppointmentDraft = <K extends keyof AppointmentDraft>(id: string, field: K, value: AppointmentDraft[K]) => {
    setParsedAppointments((current) => current.map((row) => row.id === id ? { ...row, [field]: value } : row))
  }
  const updateAppointmentText = (id: string, value: string) => {
    const date = value.match(/\b\d{1,2}\/\d{1,2}\/\d{4}\b/)?.[0] ?? ''
    const [month, day, year] = date.split('/')
    const appointmentDate = date ? `${month.padStart(2, '0')}/${day.padStart(2, '0')}/${year}` : ''
    const appointmentWindow = value.match(/\(Window:\s*([^)]+)\)/i)?.[1] ?? ''
    setParsedAppointments((current) => current.map((row) => row.id === id ? { ...row, appointment: value, appointmentDate, appointmentWindow } : row))
  }
  const parseAppointmentText = () => {
    setError('')
    const extracted = parseDispatchAppointmentText(rawEmailText)
    if (!extracted.length) {
      setParsedAppointments([])
      setError('No container numbers found. Check that each container has a 4-letter prefix followed by 6 or 7 digits.')
      return
    }
    setParsedAppointments(extracted.map((order) => ({ ...order, selected: true, linehaulRate: defaultLinehaulRate })))
  }
  const selectedAppointments = parsedAppointments.filter((row) => row.selected)
  const canAddSelectedAppointments = Boolean(defaultConsignee.trim() && selectedAppointments.length && selectedAppointments.every((row) => {
    const rate = Number(row.linehaulRate.replace(/[$,\s]/g, ''))
    return /^[A-Z]{4}\d{6,7}$/i.test(row.container.trim()) && Number.isFinite(rate) && rate > 0
  }))
  const addSelectedAppointments = () => {
    if (!canAddSelectedAppointments) {
      setError('Enter a consignee, valid container numbers, and a positive linehaul rate for each selected load.')
      return
    }
    addInboundOrders(selectedAppointments.map((row) => ({
      container: row.container,
      billOfLading: '',
      terminal: defaultTerminal,
      consignee: defaultConsignee,
      consigneeAddress: '',
      consigneeContact: '',
      linehaulRate: Number(row.linehaulRate.replace(/[$,\s]/g, '')),
      containerSize: '40HC',
      loadType: row.loadType,
      weightLbs: 0,
      seal: '',
      lfd: '',
      orderDate: '',
      vesselVoyage: '',
      appointment: row.appointment.replace(/\s*\(Window:\s*[^)]+\)\s*$/i, ''),
      appointmentDate: row.appointmentDate,
      appointmentWindow: row.appointmentWindow,
      dispatchNotes: row.dispatchNotes,
    })))
    setView('dispatch')
  }
  const parsedRate = Number(fields.linehaulRate.replace(/[$,\s]/g, ''))
  const parsedWeight = Number(fields.weightLbs.replace(/[,\s]/g, ''))
  const canConfirm = Boolean(fields.container.trim() && fields.originTerminal && fields.consignee.trim() && Number.isFinite(parsedRate) && parsedRate > 0)

  const confirmOrder = async () => {
    if (!canConfirm || !fields.originTerminal || isSaving || saveSucceeded) return
    setError('')
    setIsSaving(true)

    const order: InboundOrderDetails = {
      container: fields.container,
      billOfLading: fields.billOfLading,
      terminal: fields.originTerminal,
      consignee: fields.consignee,
      consigneeAddress: fields.consigneeAddress,
      consigneeContact: fields.consigneeContact,
      linehaulRate: parsedRate,
      containerSize: fields.containerSize,
      loadType: fields.loadType,
      weightLbs: Number.isFinite(parsedWeight) ? parsedWeight : 0,
      seal: fields.seal,
      lfd: fields.lfd,
      orderDate: fields.orderDate,
      vesselVoyage: fields.vesselVoyage,
    }

    try {
      await saveInboundOrderToSupabase(order)
      addInboundOrder(order)
      setSaveSucceeded(true)
      saveRedirectTimer.current = window.setTimeout(() => {
        saveRedirectTimer.current = null
        setView('dispatch')
      }, 1800)
    } catch (saveError) {
      const message = saveError instanceof Error ? saveError.message : 'Unable to save this inbound order to Supabase.'
      const details = saveError instanceof SupabaseInsertError
        ? saveError.details
        : saveError && typeof saveError === 'object' && 'details' in saveError && typeof saveError.details === 'string'
          ? saveError.details
          : 'No additional error details were returned.'

      setError([message, details].filter(Boolean).join(' · '))
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <PageHeader title="Inbound Orders" subtitle="Parse broker rate confirmations and delivery orders into active dispatch" />
      <div className="min-h-0 flex-1 overflow-y-auto p-4 pb-28 sm:p-6">
        <div className="mx-auto max-w-5xl space-y-6">
          <div role="status" aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-6 z-50 flex justify-center px-4">
            {saveSucceeded && (
              <div className="pointer-events-auto flex items-center gap-3 rounded-xl border border-emerald-500/30 bg-card px-4 py-3 text-sm shadow-lg animate-in fade-in slide-in-from-bottom-2">
                <span className="flex size-7 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"><Check className="size-4" aria-hidden /></span>
                <div>
                  <p className="font-medium text-foreground">Order saved to Supabase successfully</p>
                  <p className="text-xs text-muted-foreground">Opening the dispatch board...</p>
                </div>
              </div>
            )}
          </div>
          {error && <p role="alert" aria-live="assertive" className="rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">{error}</p>}
          <div role="tablist" aria-label="Inbound order input method" className="inline-flex w-full rounded-xl border border-border bg-muted/40 p-1 sm:w-auto">
            <button type="button" role="tab" aria-selected={inputMode === 'pdf'} aria-controls="inbound-pdf-panel" onClick={() => setInputMode('pdf')} className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors sm:flex-none ${inputMode === 'pdf' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}><FileText className="mr-2 inline size-4" aria-hidden />Upload DO / PDF File</button>
            <button type="button" role="tab" aria-selected={inputMode === 'text'} aria-controls="inbound-text-panel" onClick={() => setInputMode('text')} className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors sm:flex-none ${inputMode === 'text' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}><ClipboardPaste className="mr-2 inline size-4" aria-hidden />Paste Raw Email / Text</button>
          </div>
          {inputMode === 'pdf' && <section id="inbound-pdf-panel" role="tabpanel" className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-7">
            <div className="mb-5 flex items-start gap-3">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"><Inbox className="size-5" aria-hidden /></span>
              <div><h2 className="text-lg font-semibold">Upload Delivery Order (PDF)</h2><p className="mt-1 text-sm text-muted-foreground">Drop an Agiloc delivery order here or choose a PDF to review and add as a new inbound order.</p></div>
            </div>

            <div
              aria-busy={isParsing}
              onDragEnter={(event) => { event.preventDefault(); if (!isParsing) setIsDragging(true) }}
              onDragOver={(event) => event.preventDefault()}
              onDragLeave={(event) => { if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setIsDragging(false) }}
              onDrop={handleDrop}
              aria-label="Upload Delivery Order PDF"
              aria-describedby="delivery-order-upload-help"
              className={`rounded-xl border-2 border-dashed px-5 py-9 text-center transition-colors ${isDragging ? 'border-primary bg-primary/5' : 'border-border bg-muted/20 hover:border-primary/50'}`}
            >
              <input ref={fileInput} type="file" accept="application/pdf,.pdf" onChange={uploadSelection} className="sr-only" aria-label="Choose a delivery order PDF" />
              <span className="mx-auto flex size-12 items-center justify-center rounded-2xl bg-background text-primary shadow-sm"><Upload className="size-5" aria-hidden /></span>
              <p className="mt-4 font-semibold">Drop your delivery order PDF here</p>
              <p id="delivery-order-upload-help" className="mt-1 text-sm text-muted-foreground">Agiloc PDFs · or choose a file from your device · max 15 MB</p>
              {file && <p className="mx-auto mt-4 flex w-fit items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm"><FileText className="size-4 text-primary" aria-hidden /><span className="max-w-64 truncate">{file.name}</span><button type="button" disabled={isParsing} onClick={() => { if (mockParseTimer.current !== null) window.clearTimeout(mockParseTimer.current); mockParseTimer.current = null; setIsParsing(false); setFile(null); setFields(emptyFields); setParsedFilename('') }} aria-label="Remove selected PDF" className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50"><X className="size-4" aria-hidden /></button></p>}
              <div className="mt-5 flex flex-wrap justify-center gap-3">
                <button type="button" onClick={() => fileInput.current?.click()} disabled={isParsing} className="inline-flex h-10 items-center gap-2 rounded-lg border border-border bg-background px-4 text-sm font-semibold hover:bg-muted disabled:cursor-not-allowed disabled:opacity-60"><FileText className="size-4" aria-hidden />Choose PDF</button>
                <button type="button" onClick={parsePdf} disabled={isParsing} className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-60">{isParsing ? <LoaderCircle className="size-4 animate-spin" aria-hidden /> : <Upload className="size-4" aria-hidden />}{isParsing ? 'Parsing PDF…' : 'Upload & Parse PDF Order'}</button>
                <button type="button" onClick={parseMockAgilocPdf} disabled={isParsing} className="inline-flex h-10 items-center gap-2 rounded-lg border border-primary/30 bg-primary/5 px-4 text-sm font-semibold text-primary hover:bg-primary/10 disabled:cursor-not-allowed disabled:opacity-60"><Zap className="size-4" aria-hidden />Try Agiloc sample</button>
              </div>
              {isParsing && <p role="status" aria-live="polite" className="mt-4 text-sm font-medium text-primary">{file?.name.startsWith('Agiloc-') ? 'Reading Agiloc delivery order and extracting order details…' : 'Parsing delivery order PDF…'}</p>}
            </div>

          </section>}

          {inputMode === 'text' && <section id="inbound-text-panel" role="tabpanel" aria-labelledby="paste-email-heading" className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-7">
            <div className="mb-4 flex items-start gap-3">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"><Mail className="size-5" aria-hidden /></span>
              <div><h2 id="paste-email-heading" className="text-lg font-semibold">Paste customer appointment details</h2><p className="mt-1 text-sm text-muted-foreground">Extract container numbers, delivery appointments, time windows, and dispatch notes.</p></div>
            </div>
            <label htmlFor="raw-inbound-email" className="sr-only">Raw customer appointment email or dispatch notes</label>
            <textarea ref={pasteInput} id="raw-inbound-email" value={rawEmailText} onChange={(event) => setRawEmailText(event.target.value)} rows={10} placeholder={appointmentPastePlaceholder} className="min-h-64 w-full resize-y rounded-xl border border-input bg-background px-4 py-3 font-mono text-sm leading-6 outline-none placeholder:font-sans placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring" />
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <button type="button" onClick={parseAppointmentText} disabled={!rawEmailText.trim()} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"><Zap className="size-4" aria-hidden />Parse Text &amp; Extract All Loads</button>
              <button type="button" onClick={() => { setRawEmailText(''); setParsedAppointments([]); setError('') }} className="inline-flex min-h-11 items-center justify-center rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-muted">Clear Box</button>
            </div>

            <div className="mt-6 grid gap-4 rounded-xl border border-border bg-muted/20 p-4 sm:grid-cols-3">
              <Field label="Default Consignee" value={defaultConsignee} onChange={setDefaultConsignee} placeholder="Golden Intl" />
              <label className="block"><span className="mb-1.5 block text-sm font-medium">Origin Terminal</span><select value={defaultTerminal} onChange={(event) => setDefaultTerminal(event.target.value as Terminal)} className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring">{appointmentTerminalOptions.map((terminal) => <option key={terminal} value={terminal}>{TERMINALS.find((item) => item.code === terminal)?.name ?? terminal}</option>)}</select></label>
              <Field label="Default Linehaul Rate ($)" value={defaultLinehaulRate} onChange={setDefaultLinehaulRate} placeholder="875.00" inputMode="decimal" />
            </div>


            {parsedAppointments.length > 0 && <div className="mt-6 rounded-xl border border-border">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3"><div><h3 className="font-semibold">Review extracted appointments</h3><p className="mt-0.5 text-xs text-muted-foreground">Edit any value before staging the selected loads.</p></div><span className="text-xs font-medium text-muted-foreground">{parsedAppointments.length} found · {selectedAppointments.length} selected</span></div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[920px] border-collapse text-left text-sm">
                  <thead><tr className="bg-muted/40 text-xs text-muted-foreground"><th scope="col" className="w-12 px-3 py-3 text-center">✓</th><th scope="col" className="min-w-40 px-3 py-3">Container #</th><th scope="col" className="min-w-64 px-3 py-3">Delivery Appt Date &amp; Time</th><th scope="col" className="min-w-64 px-3 py-3">Dispatch Notes</th><th scope="col" className="w-36 px-3 py-3">Linehaul ($)</th><th scope="col" className="w-40 px-3 py-3">Move Type</th></tr></thead>
                  <tbody>{parsedAppointments.map((row) => <tr key={row.id} className="border-t border-border align-top">
                    <td className="px-3 py-3 text-center"><input type="checkbox" checked={row.selected} onChange={(event) => updateAppointmentDraft(row.id, 'selected', event.target.checked)} aria-label={`Select ${row.container}`} className="size-4 accent-primary" /></td>
                    <td className="px-3 py-3"><input value={row.container} onChange={(event) => updateAppointmentDraft(row.id, 'container', event.target.value.toUpperCase())} aria-label={`${row.container} container number`} className="h-10 w-full rounded-lg border border-input bg-background px-3 font-mono text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" /></td>
                    <td className="px-3 py-3"><input value={row.appointment} onChange={(event) => updateAppointmentText(row.id, event.target.value)} aria-label={`${row.container} delivery appointment date and time`} placeholder="MM/DD/YYYY @ 1:30 PM" className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" /></td>
                    <td className="px-3 py-3"><textarea value={row.dispatchNotes} onChange={(event) => updateAppointmentDraft(row.id, 'dispatchNotes', event.target.value)} aria-label={`${row.container} dispatch notes`} rows={2} placeholder="Optional dispatch notes" className="min-h-10 w-full resize-y rounded-lg border border-input bg-background px-3 py-2 text-sm leading-5 outline-none focus-visible:ring-2 focus-visible:ring-ring" /></td>
                    <td className="px-3 py-3"><input value={row.linehaulRate} onChange={(event) => updateAppointmentDraft(row.id, 'linehaulRate', event.target.value)} aria-label={`${row.container} linehaul rate`} inputMode="decimal" className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" /></td>
                    <td className="px-3 py-3"><select value={row.loadType} onChange={(event) => updateAppointmentDraft(row.id, 'loadType', event.target.value as Load['type'])} aria-label={`${row.container} move type`} className="h-10 w-full rounded-lg border border-input bg-background px-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring">{LOAD_TYPE_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></td>
                  </tr>)}</tbody>
                </table>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-4"><p className="text-xs text-muted-foreground">Loads are added as unassigned on the active dispatch board.</p><button type="button" onClick={addSelectedAppointments} disabled={!canAddSelectedAppointments} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"><Check className="size-4" aria-hidden />{selectedAppointments.length === parsedAppointments.length ? 'Add All Extracted' : 'Add Selected'} ({selectedAppointments.length}) Loads to Dispatch Board</button></div>
            </div>}
          </section>}

          {parsedFilename && <section aria-labelledby="order-fields-heading" className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-7">
            <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
              <div><h2 id="order-fields-heading" className="text-lg font-semibold">Review extracted order fields</h2><p className="mt-1 text-sm text-muted-foreground">Check and edit the extracted values before adding this load.</p></div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-300"><Check className="size-3.5" aria-hidden />Parsed · {parsedFilename}</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Container #" value={fields.container} onChange={(value) => updateField('container', value.toUpperCase())} placeholder="e.g. MSCU1234567" />
              <Field label="B/L #" value={fields.billOfLading} onChange={(value) => updateField('billOfLading', value)} placeholder="Bill of lading number" />
              <label className="block"><span className="mb-1.5 block text-sm font-medium">Origin Terminal</span><select value={fields.originTerminal} onChange={(event) => updateField('originTerminal', event.target.value as Terminal | '')} className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"><option value="">Select origin terminal</option>{TERMINALS.map((terminal) => <option key={terminal.code} value={terminal.code}>{terminal.name}</option>)}</select></label>
              <Field label="Consignee" value={fields.consignee} onChange={(value) => updateField('consignee', value)} placeholder="Consignee" />
              <Field label="Delivery Address" value={fields.consigneeAddress} onChange={(value) => updateField('consigneeAddress', value)} placeholder="Street, city, state, ZIP" />
              <Field label="Delivery Contact" value={fields.consigneeContact} onChange={(value) => updateField('consigneeContact', value)} placeholder="Name and phone" />
              <label className="block"><span className="mb-1.5 block text-sm font-medium">Container Size</span><select value={fields.containerSize} onChange={(event) => updateField('containerSize', event.target.value as Load['size'])} className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring">{sizeOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
              <label className="block"><span className="mb-1.5 block text-sm font-medium">Type</span><select value={fields.loadType} onChange={(event) => updateField('loadType', event.target.value as Load['type'])} className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring">{LOAD_TYPE_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
              <Field label="Linehaul Rate ($)" value={fields.linehaulRate} onChange={(value) => updateField('linehaulRate', value)} placeholder="875.00" inputMode="decimal" />
              <Field label="Weight (LB)" value={fields.weightLbs} onChange={(value) => updateField('weightLbs', value)} placeholder="Weight in pounds" inputMode="decimal" />
              <Field label="Seal #" value={fields.seal} onChange={(value) => updateField('seal', value.toUpperCase())} placeholder="Seal number" />
              <Field label="Last Free Day (LFD)" value={fields.lfd} onChange={(value) => updateField('lfd', value)} placeholder="MM/DD/YYYY" />
              <Field label="Order Date" value={fields.orderDate} onChange={(value) => updateField('orderDate', value)} placeholder="MM/DD/YYYY" />
              <Field label="Vessel / Voyage" value={fields.vesselVoyage} onChange={(value) => updateField('vesselVoyage', value)} placeholder="Vessel and voyage" />
            </div>
            <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-5">
              <p className="text-xs text-muted-foreground">The new load will be created as unassigned. Driver, appointment, and other dispatch details can be completed on the board.</p>
              <button type="button" onClick={confirmOrder} disabled={!canConfirm || isSaving || saveSucceeded} aria-busy={isSaving} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50">{isSaving ? <LoaderCircle className="size-4 animate-spin" aria-hidden /> : <Check className="size-4" aria-hidden />}{isSaving ? 'Saving to Supabase…' : 'Confirm & Add to Active Dispatch Board'}</button>
            </div>
          </section>}

          <button type="button" onClick={openEmailDialog} className="flex w-full items-center gap-3 rounded-xl border border-border bg-card p-4 text-left text-sm shadow-sm transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground"><Mail className="size-4" aria-hidden /></span>
            <span className="min-w-0 flex-1"><span className="block font-medium">Forward by email</span><span className="block truncate text-muted-foreground">seattletruck@gmail.com</span></span>
            <span className="text-xs font-semibold text-primary">Email order</span>
          </button>
        </div>
      </div>
      {isEmailDialogOpen && <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/60 p-4 backdrop-blur-sm" onClick={(event) => { if (event.target === event.currentTarget) setIsEmailDialogOpen(false) }} onKeyDown={(event) => { if (event.key === 'Escape') setIsEmailDialogOpen(false) }}>
        <section role="dialog" aria-modal="true" aria-labelledby="email-dialog-title" aria-describedby="email-dialog-description" onKeyDown={(event) => {
          if (event.key !== 'Tab') return
          const focusable = event.currentTarget.querySelectorAll<HTMLElement>('a[href], button:not([disabled])')
          const first = focusable[0]
          const last = focusable[focusable.length - 1]
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault()
            last?.focus()
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault()
            first?.focus()
          }
        }} className="relative my-auto w-full max-w-xl rounded-2xl border border-border bg-card p-5 shadow-2xl sm:p-7">
          <button type="button" autoFocus onClick={() => setIsEmailDialogOpen(false)} aria-label="Close" className="absolute right-4 top-4 inline-flex size-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><X className="size-5" aria-hidden /></button>
          <div className="pr-12">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">Inbound order routing</p>
            <h2 id="email-dialog-title" className="mt-2 text-xl font-semibold leading-tight sm:text-2xl">📥 Automated Email Ingestion Desk</h2>
          </div>
          <p id="email-dialog-description" className="mt-4 text-sm leading-6 text-muted-foreground">Have customers, shippers, or brokers forward delivery orders, B/Ls, or rate confirmations directly to your operations inbox:</p>
          <div className="mt-5 rounded-xl border border-primary/20 bg-primary/5 p-4 text-center sm:p-5">
            <p className="break-all text-2xl font-bold tracking-tight text-foreground sm:text-3xl">seattletruck@gmail.com</p>
            <button type="button" onClick={copyEmailAddress} className="mt-4 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 sm:w-auto">{emailCopied ? '✓ Copied!' : '📋 Copy Email Address'}</button>
            {copyError && <p role="status" className="mt-2 text-xs text-destructive">Could not copy automatically. Select the address above to copy it.</p>}
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <a href="mailto:seattletruck@gmail.com?subject=New%20Delivery%20Order" target="_blank" rel="noopener noreferrer" className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-center text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">✉️ Open Default Email App</a>
            <button type="button" onClick={switchToTextPaste} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border border-border bg-background px-4 py-2.5 text-center text-sm font-semibold text-foreground transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">📋 Switch to Quick Text / Subject Paste</button>
          </div>
        </section>
      </div>}
    </div>
  )
}

function Field({ label, value, onChange, placeholder, inputMode }: { label: string; value: string; onChange: (value: string) => void; placeholder: string; inputMode?: 'decimal' }) {
  return <label className="block"><span className="mb-1.5 block text-sm font-medium">{label}</span><input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} inputMode={inputMode} className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
}
