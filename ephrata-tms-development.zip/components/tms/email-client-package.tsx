'use client'

import { Download, Mail, X } from 'lucide-react'
import { createDeliveryDocumentAttachments } from '@/lib/delivery-documents'
import { loadReferences, type Load, type PodReceiptDetails } from '@/lib/tms-data'

interface EmailClientPackageProps {
  load: Load
  onClose: () => void
}

export function EmailClientPackage({ load, onClose }: EmailClientPackageProps) {
  const refs = loadReferences(load)
  const recipient = load.billingEmail ?? 'accounting@client.com'
  const hasSignedReceipt = load.podSigned
  const signedAt = load.podSignedAtIso ? new Date(load.podSignedAtIso) : new Date()
  const receipt: PodReceiptDetails = load.podReceipt ?? {
    timeIn: '09:00 AM',
    timeOut: load.podSignedAt ?? '09:12 AM',
    receiverName: 'Consignee',
    companyName: `${load.customer} - ${load.destination}`,
    dropStatus: 'Stay With',
    signatureDataUrl: '',
  }
  const subject = safeHeader(`DELIVERY CONFIRMATION: Container ${load.container} | B/L ${refs.billOfLading}`)
  const message = [
    `Hello ${load.customer},`,
    '',
    'Your delivery is complete. The signed e-POD and Port EIR gate ticket are attached.',
    'Your invoice is queued for the approved Friday billing run.',
    `Container: ${load.container}`,
    `B/L #: ${refs.billOfLading}`,
    `DO #: ${refs.deliveryOrder}`,
    '',
    'Thank you,',
    'Ephrata TMS · dba AAA Intermodal',
  ].join('\n')

  const stageEmail = () => {
    if (!hasSignedReceipt) return
    const attachments = createDeliveryDocumentAttachments(load, receipt, signedAt)
    const boundary = `----AAA-${crypto.randomUUID()}`
    const sections = [
      `From: seattletruck@gmail.com (Ephrata Dispatch & Billing Desk)`,
      `To: ${recipient}`,
      `Subject: ${subject}`,
      'MIME-Version: 1.0',
      `Content-Type: multipart/mixed; boundary="${boundary}"`,
      '',
      `--${boundary}`,
      'Content-Type: text/plain; charset="utf-8"',
      'Content-Transfer-Encoding: 8bit',
      '',
      message,
      ...attachments.flatMap(({ filename, bytes }) => [
        `--${boundary}`,
        `Content-Type: application/pdf; name="${filename}"`,
        'Content-Transfer-Encoding: base64',
        `Content-Disposition: attachment; filename="${filename}"`,
        '',
        wrapBase64(toBase64(bytes)),
      ]),
      `--${boundary}--`,
      '',
    ]
    const eml = new Blob([sections.join('\r\n')], { type: 'message/rfc822' })
    const url = URL.createObjectURL(eml)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `AAA-delivery-package-${safeFilename(load.container)}.eml`
    document.body.append(anchor)
    anchor.click()
    anchor.remove()
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/65 p-3 backdrop-blur-sm" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section role="dialog" aria-modal="true" aria-labelledby="email-package-title" className="w-full max-w-xl overflow-hidden rounded-md border border-slate-300 bg-white text-slate-900 shadow-2xl">
        <header className="flex items-center justify-between bg-[#1b4d89] px-4 py-3 text-white">
          <div className="flex items-center gap-2"><Mail className="size-4" aria-hidden /><h2 id="email-package-title" className="text-sm font-semibold">Email Delivery Package</h2></div>
          <button type="button" aria-label="Close email package" onClick={onClose} className="rounded p-1 hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"><X className="size-4" aria-hidden /></button>
        </header>
        <div className="grid gap-3 p-4 text-xs">
          <div className="grid gap-1"><span className="font-semibold text-slate-700">To</span><p className="rounded-sm border border-slate-200 bg-slate-50 px-2 py-2">{recipient}</p></div>
          <div className="grid gap-1"><span className="font-semibold text-slate-700">From</span><p className="rounded-sm border border-slate-200 bg-slate-50 px-2 py-2">seattletruck@gmail.com (Ephrata Dispatch &amp; Billing Desk)</p></div>
          <div className="grid gap-1"><span className="font-semibold text-slate-700">Subject</span><p className="rounded-sm border border-slate-200 bg-slate-50 px-2 py-2">{subject}</p></div>
          <div className="grid gap-1"><span className="font-semibold text-slate-700">Attachments</span>
            <ul className="grid gap-1">
              <li className="rounded-sm border border-emerald-200 bg-emerald-50 px-2 py-1.5 text-[10px] text-emerald-900">Equipment Delivery Receipt · e-POD signed {load.podSignedAt ?? '09:12'}</li>
              <li className="rounded-sm border border-emerald-200 bg-emerald-50 px-2 py-1.5 text-[10px] text-emerald-900">Port EIR Gate Ticket · generated for load {load.id}</li>
            </ul>
          </div>
          <div role="status" className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2.5 text-emerald-900">
            <p className="font-semibold">{hasSignedReceipt ? 'Simulated Email Sent Successfully via Ephrata Dispatch Mailer' : 'Delivery email is queued until the e-POD is signed.'}</p>
            <p className="mt-1 text-[10px] text-emerald-800">This is a local simulation; no external email provider is connected.</p>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 pt-3">
            <p className="max-w-xs text-[10px] leading-relaxed text-slate-500">The downloaded .eml includes the delivery receipt and Port EIR PDFs for your mail client.</p>
            <button type="button" disabled={!hasSignedReceipt} onClick={stageEmail} className="inline-flex items-center gap-1.5 rounded-sm bg-[#1b4d89] px-3 py-2 text-xs font-semibold text-white hover:bg-[#153a67] disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1b4d89]"><Download className="size-3.5" aria-hidden /> Download email package (.eml)</button>
          </div>
        </div>
      </section>
    </div>
  )
}

function makePdf(title: string, lines: string[]) {
  const printable = [title, ...lines].map((line) => line.replace(/[^\x20-\x7e]/g, ' ').replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)'))
  const commands = ['BT', '/F1 14 Tf', '50 760 Td', `(${printable[0]}) Tj`, '/F1 10 Tf', ...printable.slice(1).flatMap((line) => ['0 -22 Td', `(${line}) Tj`]), 'ET'].join('\n')
  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>',
    `<< /Length ${commands.length} >>\nstream\n${commands}\nendstream`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
  ]
  let document = '%PDF-1.4\n'
  const offsets = [0]
  objects.forEach((object, index) => {
    offsets.push(document.length)
    document += `${index + 1} 0 obj\n${object}\nendobj\n`
  })
  const xrefOffset = document.length
  document += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`
  offsets.slice(1).forEach((offset) => { document += `${String(offset).padStart(10, '0')} 00000 n \n` })
  document += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`
  const filename = `${safeFilename(title)}.pdf`
  return { filename, bytes: new TextEncoder().encode(document) }
}

function toBase64(bytes: Uint8Array) {
  let binary = ''
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000))
  }
  return btoa(binary)
}

function wrapBase64(value: string) {
  return value.match(/.{1,76}/g)?.join('\r\n') ?? ''
}

function safeHeader(value: string) {
  return value.replace(/[\r\n]+/g, ' ').trim()
}

function safeFilename(value: string) {
  return value.replace(/[^a-z0-9-]+/gi, '-')
}
