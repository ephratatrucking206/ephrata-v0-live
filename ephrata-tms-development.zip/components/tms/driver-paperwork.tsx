'use client'

import { useRef, useState, type PointerEvent } from 'react'
import { ArrowLeft, CirclePlus, ClipboardCheck, Clock3, Eraser, MapPin, RotateCcw, ShieldCheck, Trash2, Truck } from 'lucide-react'
import { SIGNATURE_LOAD_ID } from '@/lib/tms-data'
import { cn } from '@/lib/utils'
import { ReportExportToolbar } from './report-export-toolbar'
import { useTms } from './tms-store'

const dutyStatuses = [
  { id: 'off', label: '1. Off Duty', short: 'OFF', color: 'bg-slate-400' },
  { id: 'sleeper', label: '2. Sleeper', short: 'SB', color: 'bg-violet-500' },
  { id: 'driving', label: '3. Driving', short: 'D', color: 'bg-sky-600' },
  { id: 'on', label: '4. On Duty', short: 'ON', color: 'bg-amber-500' },
] as const

type DutyStatus = typeof dutyStatuses[number]['id']
type InspectionStatus = 'pass' | 'defect' | ''
type Stop = {
  job: string
  pickup: string
  delivery: string
  container: string
  chassis: string
  commodity: string
  hazmat: boolean
  timeIn: string
  timeOut: string
}

const inspectionItems = ['Brakes', 'Lights', 'Coupling', 'Steering', 'Tires', 'Oil', 'Water']
const dispatchHeaders = [
  'Driver Name', 'Date', 'Truck #', 'Pre-Trip Location', 'Start Time', 'Fuel Gallons',
  'Beginning Mileage', 'Ending Mileage', 'Total Mileage', 'Job #', 'P/U At', 'Del To',
  'Container #', 'Chassis #', 'Commodity', 'Hazmat', 'In Time', 'Out Time', 'DVIR Condition', 'Inspection Items',
]

function dateLabel(date: string) {
  const [year, month, day] = date.split('-')
  return year && month && day ? `${month}/${day}/${year}` : date
}

function parseOdometer(value: string) {
  const normalized = value.replace(/[\s,]/g, '')
  if (!normalized) return null
  const parsed = Number(normalized)
  return Number.isFinite(parsed) ? parsed : null
}

export function DriverDailyDispatch() {
  const { loads, updateLoad } = useTms()
  const assignedLoad = loads.find((load) => load.id === SIGNATURE_LOAD_ID)
  const driver = assignedLoad?.driver ?? 'Dependes'
  const setDriver = (value: string) => {
    if (assignedLoad) updateLoad(assignedLoad.id, 'driver', value)
    setSaved(false)
    setNotice('')
  }
  const [date, setDate] = useState('2026-09-17')
  const [truck, setTruck] = useState('387')
  const [location, setLocation] = useState('Tacoma, WA')
  const [startTime, setStartTime] = useState('3:00 AM')
  const [fuelGallons, setFuelGallons] = useState('')
  const [beginningMiles, setBeginningMiles] = useState('')
  const [endingMiles, setEndingMiles] = useState('')
  const [stops, setStops] = useState<Stop[]>([{ job: '1', pickup: 'Tacoma, WA', delivery: 'Tillamook, OR', container: 'SEGU5357474', chassis: 'EPHZ-14', commodity: '', hazmat: false, timeIn: '', timeOut: '' }])
  const [openLegActions, setOpenLegActions] = useState<number | null>(null)
  const legRefs = useRef<Array<HTMLElement | null>>([])
  const containerBeforeEditRef = useRef<Record<number, string>>({})
  const [checks, setChecks] = useState<Record<string, InspectionStatus>>({})
  const [condition, setCondition] = useState(false)
  const [signatureCaptured, setSignatureCaptured] = useState(false)
  const [saved, setSaved] = useState(false)
  const [completedTripRecord, setCompletedTripRecord] = useState<{ reportRows: Array<Array<string | number>>; totalMiles: number; certifiedAt: string } | null>(null)
  const [notice, setNotice] = useState('')

  const beginningOdometer = parseOdometer(beginningMiles)
  const endingOdometer = parseOdometer(endingMiles)
  const mileageInputsComplete = beginningOdometer !== null && endingOdometer !== null
  const mileageIsReversed = mileageInputsComplete && endingOdometer < beginningOdometer
  const totalMiles = mileageInputsComplete ? Math.max(0, endingOdometer - beginningOdometer) : 0
  const inspectionComplete = inspectionItems.every((item) => Boolean(checks[item]))
  const inspectionStatus = inspectionItems.every((item) => checks[item] === 'pass') ? 'Pass / Satisfactory' : Object.values(checks).includes('defect') ? 'Defect reported' : 'Incomplete'
  const inspectionSummary = inspectionItems.map((item) => `${item}: ${checks[item] === 'pass' ? 'Pass' : checks[item] === 'defect' ? 'Defect' : 'Not checked'}`).join('; ')
  const reportRows = stops.map((stop) => [
    driver, dateLabel(date), truck, location, startTime, fuelGallons || '—', beginningMiles || '—', endingMiles || '—', totalMiles,
    stop.job, stop.pickup, stop.delivery, stop.container, stop.chassis, stop.commodity || '—', stop.hazmat ? 'Yes' : 'No',
    stop.timeIn || '—', stop.timeOut || '—', condition ? inspectionStatus : 'Condition not certified', inspectionSummary,
  ])
  const setValue = (setter: (value: string) => void) => (value: string) => {
    setter(value)
    setSaved(false)
    setNotice('')
  }
  const updateStop = (index: number, field: keyof Stop, value: string | boolean) => {
    setStops((items) => items.map((stop, itemIndex) => itemIndex === index ? { ...stop, [field]: value } : stop))
    setSaved(false)
    setNotice('')
  }

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 p-4 sm:p-6 print:max-w-none print:p-0">
      <header className="rounded-xl border-2 border-primary/25 bg-card p-4 shadow-sm sm:p-5 print:rounded-none print:shadow-none">
        <p className="text-center text-sm font-extrabold tracking-wide sm:text-base">Ephrata Trucking, LLC</p>
        <p className="mt-2 text-center text-[10px] leading-relaxed text-muted-foreground sm:text-xs">EPHRATA TRUCKING, LLC • 10105 SE 212TH ST, KENT, WA 98032<br />Office: (206) 866-4720 | Cell: (206) 372-8570 | Email: seattletruck@gmail.com</p>
      </header>

      <ReportExportToolbar
title="Daily Driver Dispatch Manifest & Vehicle Inspection (DVIR) · export"
        fileName="ephrata-daily-dispatch-dvir"
        sheetName="Daily Driver Dispatch Manifest"
        reportTitle="Ephrata Trucking, LLC · Daily Driver Dispatch Manifest & Vehicle Inspection (DVIR)"
        headers={dispatchHeaders}
        rows={completedTripRecord?.reportRows ?? reportRows}
      />

      <section className="rounded-xl border border-border bg-card p-4 shadow-sm sm:p-5 print:break-inside-avoid print:shadow-none">
        <div className="mb-4 flex items-center gap-2"><Truck className="size-5 text-primary" aria-hidden /><div><h2 className="font-semibold">Shift &amp; equipment</h2><p className="mt-1 text-xs text-muted-foreground">Complete the daily dispatch header and mileage strip.</p></div></div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <div><FormField label="Driver Name" value={driver} onChange={setValue(setDriver)} /><p className="mt-1 text-[10px] text-muted-foreground">Editable per run; updates this load&apos;s dispatch assignment and chat.</p></div>
          <FormField label="Date" value={date} onChange={setValue(setDate)} type="date" />
          <FormField label="Truck #" value={truck} onChange={setValue(setTruck)} />
          <FormField label="Pre-Trip Location" value={location} onChange={setValue(setLocation)} />
          <FormField label="Start" value={startTime} onChange={setValue(setStartTime)} />
          <FormField label="Fuel Gallons (ST)" value={fuelGallons} onChange={setValue(setFuelGallons)} type="number" placeholder="Enter gallons" />
        </div>
        <fieldset className="mt-4 rounded-lg border border-border p-3">
          <legend className="px-1 text-sm font-semibold">Mileage strip</legend>
          <div className="grid gap-3 sm:grid-cols-3">
            <FormField label="Beginning Mileage" value={beginningMiles} onChange={setValue(setBeginningMiles)} inputMode="decimal" placeholder="e.g. 145,200" />
            <FormField label="Ending Mileage" value={endingMiles} onChange={setValue(setEndingMiles)} inputMode="decimal" placeholder="e.g. 145,342" />
            <div className="flex min-h-10 flex-col justify-center rounded-lg bg-muted/60 px-3 py-2"><span className="text-xs text-muted-foreground">Total Mileage</span><output aria-live="polite" aria-atomic="true" className="font-mono text-sm font-semibold">{totalMiles.toLocaleString()} mi</output>{mileageIsReversed && <p className="mt-1 text-xs text-amber-700 dark:text-amber-300">⚠️ Ending mileage is lower than beginning mileage</p>}</div>
          </div>
        </fieldset>
      </section>

      <section className="rounded-xl border border-border bg-card p-4 shadow-sm sm:p-5 print:break-inside-avoid print:shadow-none">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div><h2 className="font-semibold">Dispatch stops · multi-leg container log</h2><p className="mt-1 text-xs text-muted-foreground">Record each pickup, delivery, and gate time for the run.</p></div>
          <button type="button" onClick={() => { setStops((items) => [...items, { job: String(items.length + 1), pickup: '', delivery: '', container: '', chassis: '', commodity: '', hazmat: false, timeIn: '', timeOut: '' }]); setSaved(false); setNotice('') }} className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-border px-3 text-sm font-medium hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><CirclePlus className="size-4" aria-hidden />Add Leg / Stop</button>
        </div>
        <div className="grid gap-3">
          {stops.map((stop, index) => {
            const legNumber = index + 1
            const isEmptyLeg = !stop.pickup && !stop.delivery && !stop.container && !stop.chassis && !stop.commodity && !stop.timeIn && !stop.timeOut && !stop.hazmat
            const hasContainerRevert = Object.prototype.hasOwnProperty.call(containerBeforeEditRef.current, index) && containerBeforeEditRef.current[index] !== stop.container

            return (
              <article key={index} ref={(element) => { legRefs.current[index] = element }} className="rounded-lg border border-border bg-background p-3">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2">
                    <span className="shrink-0 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Leg {legNumber}</span>
                    <button type="button" aria-label={`Open actions for leg ${legNumber}`} aria-expanded={openLegActions === index} aria-controls={`leg-actions-${index}`} onClick={() => setOpenLegActions((current) => current === index ? null : index)} className="inline-flex min-h-11 cursor-pointer items-center gap-1.5 rounded-md border border-border bg-card px-2 text-[11px] font-semibold transition-colors hover:bg-muted active:bg-muted/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                      <ArrowLeft className="size-4 shrink-0" aria-hidden />Return / Revert Leg
                    </button>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <label className="flex min-h-11 cursor-pointer items-center gap-2 rounded-md px-2 text-xs transition-colors hover:bg-muted/70 active:bg-muted">
                      <input aria-label={`Leg ${legNumber} hazmat`} type="checkbox" checked={stop.hazmat} onChange={(event) => updateStop(index, 'hazmat', event.target.checked)} className="size-4 cursor-pointer accent-primary" />Hazmat
                    </label>
                    {index > 0 && <button type="button" aria-label={`Remove empty leg ${legNumber}`} title={isEmptyLeg ? 'Remove empty leg' : 'Clear this leg before removing it'} disabled={!isEmptyLeg} onClick={() => { setStops((items) => items.filter((_, itemIndex) => itemIndex !== index).map((item, itemIndex) => ({ ...item, job: String(itemIndex + 1) }))); containerBeforeEditRef.current = {}; setOpenLegActions(null); setSaved(false); setNotice('') }} className="inline-flex min-h-11 min-w-11 cursor-pointer items-center justify-center gap-1 rounded-md border border-destructive/30 px-2 text-destructive transition-colors hover:bg-destructive/10 active:bg-destructive/20 disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:min-w-0">
                      <Trash2 className="size-4" aria-hidden /><span className="hidden text-xs font-medium sm:inline">Remove</span>
                    </button>}
                  </div>
                </div>
                {openLegActions === index && <div id={`leg-actions-${index}`} className="mb-3 grid gap-2 rounded-lg border border-border bg-muted/30 p-2 sm:grid-cols-3">
                  <button type="button" disabled={index === 0} onClick={() => { legRefs.current[index - 1]?.scrollIntoView({ behavior: 'smooth', block: 'center' }); setOpenLegActions(null) }} className="inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-md border border-border bg-background px-3 text-left text-xs font-medium transition-colors hover:bg-muted active:bg-muted/70 disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><ArrowLeft className="size-4" aria-hidden />Return to Previous Stop</button>
                  <button type="button" disabled={!hasContainerRevert} onClick={() => { updateStop(index, 'container', containerBeforeEditRef.current[index]); delete containerBeforeEditRef.current[index]; setOpenLegActions(null) }} className="inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-md border border-border bg-background px-3 text-left text-xs font-medium transition-colors hover:bg-muted active:bg-muted/70 disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><RotateCcw className="size-4" aria-hidden />Revert Container Status</button>
                  <button type="button" onClick={() => { setStops((items) => items.map((item, itemIndex) => itemIndex === index ? { job: String(legNumber), pickup: '', delivery: '', container: '', chassis: '', commodity: '', hazmat: false, timeIn: '', timeOut: '' } : item)); delete containerBeforeEditRef.current[index]; setOpenLegActions(null); setSaved(false); setNotice('') }} className="inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-md border border-border bg-background px-3 text-left text-xs font-medium transition-colors hover:bg-muted active:bg-muted/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><Eraser className="size-4" aria-hidden />Clear / Reset Leg</button>
                </div>}
                <div className="grid grid-cols-[1fr_auto_1fr] items-end gap-2"><label className="min-w-0"><span className="mb-1 block text-[10px] text-muted-foreground">Pickup</span><CellInput ariaLabel={`Leg ${legNumber} pickup location`} value={stop.pickup} onChange={(value) => updateStop(index, 'pickup', value)} /></label><span className="pb-3 text-muted-foreground" aria-hidden>→</span><label className="min-w-0"><span className="mb-1 block text-[10px] text-muted-foreground">Delivery</span><CellInput ariaLabel={`Leg ${legNumber} delivery location`} value={stop.delivery} onChange={(value) => updateStop(index, 'delivery', value)} /></label></div>
                <div className="mt-3 grid grid-cols-2 gap-2"><label className="min-w-0"><span className="mb-1 block text-[10px] text-muted-foreground">Container</span><CellInput ariaLabel={`Leg ${legNumber} container number`} value={stop.container} onFocus={() => { containerBeforeEditRef.current[index] = stop.container }} onChange={(value) => updateStop(index, 'container', value)} /></label><label className="min-w-0"><span className="mb-1 block text-[10px] text-muted-foreground">Chassis</span><CellInput ariaLabel={`Leg ${legNumber} chassis number`} value={stop.chassis} onChange={(value) => updateStop(index, 'chassis', value)} /></label></div>
              </article>
            )
          })}
        </div>
      </section>

      <section className="rounded-xl border border-border bg-card p-4 shadow-sm sm:p-5 print:break-inside-avoid print:shadow-none">
        <div className="mb-4 flex items-center gap-2"><ClipboardCheck className="size-5 text-primary" aria-hidden /><div><h2 className="font-semibold">Post-Trip DVIR Inspection</h2><p className="mt-1 text-xs text-muted-foreground">Check each vehicle item after inspection.</p></div></div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {inspectionItems.map((item) => <label key={item} className="flex min-h-12 cursor-pointer items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm font-medium"><input type="checkbox" aria-label={`${item} inspected`} checked={checks[item] === 'pass'} onChange={(event) => { setChecks((current) => ({ ...current, [item]: event.target.checked ? 'pass' : '' })); setSaved(false); setNotice('') }} className="size-5 accent-primary" />{item}</label>)}
        </div>
        <label className="mt-4 flex min-h-12 cursor-pointer items-center gap-3 rounded-lg border border-border px-3 py-2 text-sm font-semibold"><input type="checkbox" checked={condition} onChange={(event) => { setCondition(event.target.checked); setSaved(false); setNotice('') }} className="size-5 accent-primary" />Condition of Vehicle is Satisfactory</label>
        <div className="mt-4"><SignaturePad title="Driver Digital Signature" onSignatureChange={(value) => { setSignatureCaptured(value); setSaved(false); setNotice('') }} /></div>
      </section>

      <div className="flex flex-col gap-3 rounded-xl border border-border bg-card px-4 py-3 sm:flex-row sm:items-center sm:justify-between print:hidden">
        <div><p role="status" aria-live="polite" className="text-xs text-muted-foreground">{notice || (saved ? 'Daily DVIR saved and certified in this session. Export a copy for your records.' : 'Complete every inspection item, confirm vehicle condition, and sign before certifying.')}</p>{completedTripRecord && <p className="mt-1 text-xs font-medium text-foreground">Completed Daily Trip Record: {completedTripRecord.totalMiles.toLocaleString()} mi</p>}</div>
        <button type="button" disabled={!inspectionComplete || !condition || !signatureCaptured} onClick={() => { setCompletedTripRecord({ reportRows, totalMiles, certifiedAt: new Date().toISOString() }); setSaved(true); setNotice('Daily DVIR saved and certified in this session.') }} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><ClipboardCheck className="size-4" aria-hidden />Save &amp; Certify Daily DVIR</button>
      </div>
    </div>
  )
}

export function DriverDotLog() {
  const [status, setStatus] = useState<DutyStatus>('driving')
  const [dutyByHour, setDutyByHour] = useState<DutyStatus[]>(() => Array.from({ length: 24 }, (_, hour) => hour >= 3 && hour < 9 ? 'driving' : hour >= 9 && hour < 11 ? 'on' : 'off'))
  const [date, setDate] = useState('2026-09-17')
  const [fields, setFields] = useState({ truck: '387', trailer: '7474', drivingMiles: '387', totalToday: '747', reference: 'MEDUST884910', from: 'Tacoma, WA', to: 'Tillamook, OR' })
  const [signature, setSignature] = useState('S. Singh')
  const [signatureCaptured, setSignatureCaptured] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [notice, setNotice] = useState('')
  const statusInfo = (id: DutyStatus) => dutyStatuses.find((option) => option.id === id)!
  const setField = (key: keyof typeof fields, value: string) => { setFields((current) => ({ ...current, [key]: value })); setSubmitted(false); setNotice('') }
  const hours = (id: DutyStatus) => dutyByHour.filter((hourStatus) => hourStatus === id).length
  const updateHour = (hour: number, nextStatus: DutyStatus) => {
    setStatus(nextStatus)
    setDutyByHour((current) => current.map((hourStatus, itemHour) => itemHour === hour ? nextStatus : hourStatus))
    setSubmitted(false)
    setNotice('')
  }
  const updateCurrentHour = (nextStatus: DutyStatus) => updateHour(new Date().getHours(), nextStatus)
  const timeline = dutyByHour.map((entry, hour) => `${String(hour).padStart(2, '0')}:00 ${statusInfo(entry).label}`).join(' | ')
  const logHeaders = ['Carrier', 'Date', 'Truck #', 'Trailer/Chassis', 'Total Driving Miles', 'Total Today', 'B/L or Manifest #', 'From', 'To', 'Off Duty Hours', 'Sleeper Berth Hours', 'Driving Hours', 'On Duty Hours', 'Duty Status by Hour', 'Driver Certification']
  const logRows = [[
    'Ephrata Trucking, LLC · Kent, WA', dateLabel(date), fields.truck, fields.trailer, fields.drivingMiles, fields.totalToday,
    fields.reference, fields.from, fields.to, hours('off'), hours('sleeper'), hours('driving'), hours('on'), timeline,
    signatureCaptured ? `Signed: ${signature}` : 'Signature not captured',
  ]]

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 p-4 sm:p-6 print:max-w-none print:p-0">
      <ReportExportToolbar title="FMCSA RODS · export" fileName="ephrata-dot-24-hour-log" sheetName="FMCSA RODS" reportTitle="Ephrata Trucking, LLC · FMCSA 24-Hour Record of Duty Status (RODS - Form 613-MP)" headers={logHeaders} rows={logRows} />
      <section className="rounded-xl border border-border bg-card p-4 shadow-sm sm:p-5 print:break-inside-avoid print:shadow-none">
        <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">J.J. Keller · 613-MP format</p><h2 className="mt-1 text-lg font-semibold">FMCSA 24-Hour Record of Duty Status (RODS - Form 613-MP)</h2><p className="mt-1 text-sm text-muted-foreground">Carrier: Ephrata Trucking, LLC · Kent, WA</p></div><span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1.5 text-xs"><Clock3 className="size-3.5" aria-hidden />Midnight to midnight</span></div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <FormField label="Date" value={date} onChange={(value) => { setDate(value); setSubmitted(false); setNotice('') }} type="date" />
          <FormField label="Truck #" value={fields.truck} onChange={(value) => setField('truck', value)} />
          <FormField label="Trailer / Chassis" value={fields.trailer} onChange={(value) => setField('trailer', value)} />
          <FormField label="Total Driving Miles" value={fields.drivingMiles} onChange={(value) => setField('drivingMiles', value)} type="number" />
          <FormField label="Total Today" value={fields.totalToday} onChange={(value) => setField('totalToday', value)} type="number" />
          <FormField label="Shipping Documents · B/L or Manifest #" value={fields.reference} onChange={(value) => setField('reference', value)} />
          <FormField label="Route · From" value={fields.from} onChange={(value) => setField('from', value)} />
          <FormField label="Route · To" value={fields.to} onChange={(value) => setField('to', value)} />
        </div>
      </section>

      <section className="rounded-xl border border-border bg-card p-4 shadow-sm sm:p-5 print:break-inside-avoid print:shadow-none">
        <div className="flex flex-wrap items-center justify-between gap-3"><div><h3 className="font-semibold">Quick-tap duty status</h3><p className="mt-1 text-xs text-muted-foreground">Select a status to record it in the current hour, or tap any hour block below to edit it.</p></div><span aria-live="polite" className="rounded-full bg-muted px-3 py-1.5 text-xs">Current: {statusInfo(status).label}</span></div>
        <div className="mt-3 grid grid-cols-2 gap-2 lg:grid-cols-4">{dutyStatuses.map((item) => <button key={item.id} type="button" aria-pressed={status === item.id} onClick={() => updateCurrentHour(item.id)} className={cn('min-h-12 rounded-lg border px-3 py-2 text-left text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring', status === item.id ? 'border-primary bg-primary text-primary-foreground ring-2 ring-primary/20' : 'border-border bg-background hover:bg-muted')}>{item.label}</button>)}</div>
        <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 text-xs">{dutyStatuses.map((item) => <span key={item.id} className="inline-flex items-center gap-1.5"><i className={cn('size-2.5 rounded-sm', item.color)} aria-hidden />{item.short}: {hours(item.id)}h</span>)}</div>
        <div className="mt-3 overflow-x-auto pb-2"><div className="min-w-[780px]"><div className="grid grid-cols-[116px_repeat(24,minmax(0,1fr))] items-center gap-1"><span className="text-xs text-muted-foreground">Duty status</span>{Array.from({ length: 24 }, (_, hour) => <span key={hour} className="text-center font-mono text-[9px] text-muted-foreground">{String(hour).padStart(2, '0')}</span>)}</div>
          {dutyStatuses.map((row) => <div key={row.id} className="mt-2 grid grid-cols-[116px_repeat(24,minmax(0,1fr))] items-center gap-1"><span className="truncate text-xs text-muted-foreground">{row.short} · {row.label}</span>{dutyByHour.map((hourStatus, hour) => <button key={hour} type="button" aria-label={`${String(hour).padStart(2, '0')}:00 ${row.label}${hourStatus === row.id ? ', logged' : ''}`} aria-pressed={hourStatus === row.id} onClick={() => updateHour(hour, row.id)} className={cn('h-7 rounded-sm border border-border/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring', hourStatus === row.id ? row.color : 'bg-muted/40 hover:bg-muted')} />)}</div>)}
          <div className="mt-1 grid grid-cols-[116px_repeat(24,minmax(0,1fr))] gap-1"><span />{Array.from({ length: 24 }, (_, hour) => <span key={hour} className="text-center font-mono text-[8px] text-muted-foreground">{hour % 2 === 0 ? `${String(hour).padStart(2, '0')}:00` : ''}</span>)}</div></div></div>
      </section>

      <section className="rounded-xl border border-border bg-card p-4 shadow-sm sm:p-5 print:break-inside-avoid print:shadow-none"><div className="mb-3 flex items-center gap-2"><ShieldCheck className="size-5 text-primary" aria-hidden /><div><h3 className="font-semibold">Driver certification</h3><p className="mt-1 text-sm text-muted-foreground">I certify these entries are true and correct.</p></div></div>
        <label className="mb-3 block max-w-sm"><span className="mb-1 block text-xs font-medium text-muted-foreground">Driver signature name</span><input value={signature} onChange={(event) => { setSignature(event.target.value); setSubmitted(false); setNotice('') }} className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
        <SignaturePad title="Capture driver signature" onSignatureChange={(value) => { setSignatureCaptured(value); setSubmitted(false); setNotice('') }} />
        <p className="mt-3 rounded-md border border-border bg-muted/40 px-3 py-2 text-xs">Signature line: {signatureCaptured ? `Signed: ${signature}` : `Signed: ${signature} · capture signature above to certify`}</p>
      </section>
      <div className="flex flex-col gap-3 rounded-xl border border-border bg-card px-4 py-3 sm:flex-row sm:items-center sm:justify-between print:hidden"><p role="status" aria-live="polite" className="text-xs text-muted-foreground">{notice || (submitted ? 'Certified DOT daily log saved in this session. Export a copy for your records.' : 'Review the duty grid and capture the driver signature before submission.')}</p><button type="button" disabled={!signature.trim() || !signatureCaptured} onClick={() => { setSubmitted(true); setNotice('Certified DOT daily log submitted in this session.') }} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><ShieldCheck className="size-4" aria-hidden />Submit Certified Daily DOT Log</button></div>
      <p className="text-center text-[11px] text-muted-foreground print:hidden">Interactive demo record. Exported files are generated locally and are not submitted to a carrier or compliance system.</p>
    </div>
  )
}

function FormField({ label, value, onChange, type = 'text', placeholder, inputMode }: { label: string; value: string; onChange: (value: string) => void; type?: string; placeholder?: string; inputMode?: 'decimal' | 'numeric' }) {
  return <label className="block min-w-0"><span className="mb-1 block text-xs font-medium text-muted-foreground">{label}</span><input type={type} inputMode={inputMode} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none transition focus-visible:ring-2 focus-visible:ring-ring" /></label>
}

function CellInput({ ariaLabel, value, onChange, onFocus, type = 'text' }: { ariaLabel: string; value: string; onChange: (value: string) => void; onFocus?: () => void; type?: string }) {
  return <input aria-label={ariaLabel} type={type} value={value} onFocus={onFocus} onChange={(event) => onChange(event.target.value)} className="h-11 w-full min-w-28 rounded-md border border-input bg-background px-2 text-xs outline-none focus-visible:ring-2 focus-visible:ring-ring" />
}

function SignaturePad({ title, onSignatureChange }: { title: string; onSignatureChange: (signed: boolean) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const drawingRef = useRef(false)
  const [hasSignature, setHasSignature] = useState(false)
  const position = (event: PointerEvent<HTMLCanvasElement>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    return { x: (event.clientX - rect.left) * (event.currentTarget.width / rect.width), y: (event.clientY - rect.top) * (event.currentTarget.height / rect.height) }
  }
  const begin = (event: PointerEvent<HTMLCanvasElement>) => {
    const context = event.currentTarget.getContext('2d')
    if (!context) return
    event.currentTarget.setPointerCapture(event.pointerId)
    drawingRef.current = true
    const point = position(event)
    context.beginPath()
    context.moveTo(point.x, point.y)
    context.lineWidth = 3
    context.lineCap = 'round'
    context.lineJoin = 'round'
    context.strokeStyle = '#172554'
  }
  const draw = (event: PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return
    const context = event.currentTarget.getContext('2d')
    if (!context) return
    const point = position(event)
    context.lineTo(point.x, point.y)
    context.stroke()
    if (!hasSignature) {
      setHasSignature(true)
      onSignatureChange(true)
    }
  }
  const finish = (event: PointerEvent<HTMLCanvasElement>) => {
    drawingRef.current = false
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId)
  }
  const clear = () => {
    const canvas = canvasRef.current
    const context = canvas?.getContext('2d')
    if (!canvas || !context) return
    context.clearRect(0, 0, canvas.width, canvas.height)
    drawingRef.current = false
    setHasSignature(false)
    onSignatureChange(false)
  }
  return <div><div className="mb-1 flex items-center justify-between gap-2"><span className="text-xs font-medium text-muted-foreground">{title}</span><button type="button" onClick={clear} disabled={!hasSignature} className="inline-flex min-h-10 items-center gap-1 rounded-md px-2 text-xs text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-40"><Eraser className="size-3.5" aria-hidden />Clear</button></div><canvas ref={canvasRef} width={960} height={180} aria-label={`${title} drawing area`} onPointerDown={begin} onPointerMove={draw} onPointerUp={finish} onPointerCancel={finish} className="h-28 w-full touch-none rounded-lg border border-dashed border-border bg-white" /><p className="mt-1 text-[11px] text-muted-foreground">{hasSignature ? 'Signature captured in this session.' : 'Sign above using touch, mouse, or stylus.'}</p></div>
}

export function DriverPaperworkTabs({ activeTab, onChange }: { activeTab: 'active' | 'dispatch' | 'log'; onChange: (tab: 'active' | 'dispatch' | 'log') => void }) {
  const tabRefs = useRef<Array<HTMLButtonElement | null>>([])
  const tabs = [
    { id: 'active' as const, label: 'Consignee Delivery Receipt & Proof of Delivery', icon: MapPin, panel: 'driver-tabpanel-active', tabId: 'driver-tab-active' },
    { id: 'dispatch' as const, label: 'Daily Driver Dispatch Manifest & Vehicle Inspection (DVIR)', icon: ClipboardCheck, panel: 'driver-tabpanel-dispatch', tabId: 'driver-tab-dispatch' },
    { id: 'log' as const, label: 'FMCSA 24-Hour Record of Duty Status (RODS - Form 613-MP)', icon: Clock3, panel: 'driver-tabpanel-log', tabId: 'driver-tab-log' },
  ]
  return <div role="tablist" aria-label="Driver mobile paperwork" className="sticky top-0 z-20 flex shrink-0 gap-1 overflow-x-auto border-b border-border bg-background/95 px-2 shadow-sm backdrop-blur sm:px-6">{tabs.map(({ id, label, icon: Icon, panel, tabId }, index) => <button key={id} ref={(element) => { tabRefs.current[index] = element }} id={tabId} type="button" role="tab" aria-selected={activeTab === id} aria-controls={panel} tabIndex={activeTab === id ? 0 : -1} onClick={() => onChange(id)} onKeyDown={(event) => {
    const nextIndex = event.key === 'ArrowRight' ? (index + 1) % tabs.length : event.key === 'ArrowLeft' ? (index - 1 + tabs.length) % tabs.length : event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : -1
    if (nextIndex < 0) return
    event.preventDefault()
    tabRefs.current[nextIndex]?.focus()
    onChange(tabs[nextIndex].id)
  }} className={cn('inline-flex min-h-12 shrink-0 items-center gap-2 border-b-2 px-3 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:text-sm', activeTab === id ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground')}><Icon className="size-4" aria-hidden />{label}</button>)}</div>
}

export function DriverPaperworkContent({ tab }: { tab: 'dispatch' | 'log' }) {
  return tab === 'dispatch' ? <DriverDailyDispatch /> : <DriverDotLog />
}

export function DriverDemoNotice() {
  return <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-300/60 bg-amber-100/70 px-2.5 py-1 text-[11px] font-medium text-amber-950 dark:border-amber-700 dark:bg-amber-950/30 dark:text-amber-100"><Clock3 className="size-3" aria-hidden />Session-only demo</span>
}
